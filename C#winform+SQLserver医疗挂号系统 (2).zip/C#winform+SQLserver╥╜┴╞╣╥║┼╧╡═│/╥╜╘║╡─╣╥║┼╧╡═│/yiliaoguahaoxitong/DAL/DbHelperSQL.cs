﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.Collections;

namespace DAL
{



    public class DbHelperSQL
    {
        private static string conStr = "Data Source=小颜\\SQLEXPRESS;Initial Catalog=guahaoxitong;Integrated Security=true";//获取连接字符串
        /// <summary>
        /// 执行sql
        /// </summary>
        /// <param name="sqlString"></param>
        /// <returns></returns>
        public static int ExecuteSql(string sqlString)
        {
            int i;
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(sqlString, connection))
                {
                    try
                    {
                        connection.Open();
                        return cmd.ExecuteNonQuery();
                    }
                    catch (SqlException E)
                    {
                        connection.Close();
                        throw new Exception(E.Message);
                    }
                    finally
                    {
                        cmd.Dispose();
                        connection.Close();
                    }
                }
            }
            return i;
        }
        /// <summary>
        /// 执行带参数得sql
        /// </summary>
        /// <param name="sqlString"></param>
        /// <param name="cmdParms"></param>
        /// <returns></returns>
        public static int ExecuteSql(string sqlString, params SqlParameter[] cmdParms)
        {
            int i;
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    try
                    {
                        PrepareCommand(cmd, connection, null, sqlString, cmdParms);
                        int rows = cmd.ExecuteNonQuery();
                        cmd.Parameters.Clear();
                        return rows;
                    }
                    catch (SqlException E)
                    {
                        throw new Exception(E.Message);
                    }
                    finally
                    {
                        cmd.Dispose();
                        connection.Close();
                    }
                }
            }
            return i;
        }
        /// <summary>
        /// 判断是否存在某数据
        /// </summary>
        /// <param name="sqlString"></param>
        /// <param name="cmdParms"></param>
        /// <returns></returns>
        public static bool Exists(string sqlString, params SqlParameter[] cmdParms)
        {
            int cmdResult;
            object obj = GetSingle(sqlString, cmdParms);
            if (object.Equals(obj, null) || object.Equals(obj, DBNull.Value))
            {
                cmdResult = 0;
            }
            else
            {
                cmdResult = int.Parse(obj.ToString());
            }
            if (cmdResult == 0)
            {
                return false;
            }
            return true;
        }
        /// <summary>
        /// 得到最大值
        /// </summary>
        /// <param name="fieldName"></param>
        /// <param name="tableName"></param>
        /// <returns></returns>
        public static int GetMaxID(string fieldName, string tableName)
        {
            object obj = GetSingle("select max(" + fieldName + ")+1 from " + tableName);
            if (obj == null)
            {
                return 1;
            }
            return int.Parse(obj.ToString());
        }
        /// <summary>
        /// 执行sql,并返回一个结果（add方法中使用执行添加后获取自动生成得id）
        /// </summary>
        /// <param name="sqlString"></param>
        /// <returns></returns>
        public static object GetSingle(string sqlString)
        {
            object o;
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(sqlString, connection))
                {
                    try
                    {
                        connection.Open();
                        object obj = cmd.ExecuteScalar();
                        if (object.Equals(obj, null) || object.Equals(obj, DBNull.Value))
                        {
                            return null;
                        }
                        return obj;
                    }
                    catch (SqlException e)
                    {
                        connection.Close();
                        throw new Exception(e.Message);
                    }
                    finally
                    {
                        cmd.Dispose();
                        connection.Close();
                    }
                }
            }
            return o;
        }
        /// <summary>
        /// 执行sql,并返回一个结果（add方法中使用执行添加后获取自动生成得id）
        /// </summary>
        /// <param name="sqlString"></param>
        /// <returns></returns>
        public static object GetSingle(string sqlString, params SqlParameter[] cmdParms)
        {
            object o;
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    try
                    {
                        PrepareCommand(cmd, connection, null, sqlString, cmdParms);
                        object obj = cmd.ExecuteScalar();
                        cmd.Parameters.Clear();
                        if (object.Equals(obj, null) || object.Equals(obj, DBNull.Value))
                        {
                            return null;
                        }
                        return obj;
                    }
                    catch (SqlException e)
                    {
                        throw new Exception(e.Message);
                    }
                    finally
                    {
                        cmd.Dispose();
                        connection.Close();
                    }
                }
            }
            return o;
        }
        /// <summary>
        /// 获取cmd得参数
        /// </summary>
        /// <param name="cmd"></param>
        /// <param name="conn"></param>
        /// <param name="trans"></param>
        /// <param name="cmdText"></param>
        /// <param name="cmdParms"></param>
        private static void PrepareCommand(SqlCommand cmd, SqlConnection conn, SqlTransaction trans, string cmdText, SqlParameter[] cmdParms)
        {
            if (conn.State != ConnectionState.Open)
            {
                conn.Open();
            }
            cmd.Connection = conn;
            cmd.CommandText = cmdText;
            if (trans != null)
            {
                cmd.Transaction = trans;
            }
            cmd.CommandType = CommandType.Text;
            if (cmdParms != null)
            {
                foreach (SqlParameter parm in cmdParms)
                {
                    cmd.Parameters.Add(parm);
                }
            }
        }
        /// <summary>
        /// 查询数据
        /// </summary>
        /// <param name="sqlString"></param>
        /// <returns></returns>
        public static DataSet Query(string sqlString)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                DataSet ds = new DataSet();
                try
                {
                    connection.Open();
                    new SqlDataAdapter(sqlString, connection).Fill(ds, "ds");
                }
                catch (SqlException ex)
                {
                    throw new Exception(ex.Message);
                }
                finally
                {
                    connection.Close();
                }
                return ds;
            }
        }
        /// <summary>
        /// 查询数据
        /// </summary>
        /// <param name="sqlString"></param>
        /// <param name="cmdParms"></param>
        /// <returns></returns>
        public static DataSet Query(string sqlString, params SqlParameter[] cmdParms)
        {
            DataSet dataSet;
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand();
                PrepareCommand(cmd, connection, null, sqlString, cmdParms);
                using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                {
                    DataSet ds = new DataSet();
                    try
                    {
                        da.Fill(ds, "ds");
                        cmd.Parameters.Clear();
                    }
                    catch (SqlException ex)
                    {
                        throw new Exception(ex.Message);
                    }
                    finally
                    {
                        cmd.Dispose();
                        connection.Close();
                    }
                    dataSet = ds;
                }
            }
            return dataSet;
        }


        public static SqlConnection Connection
        {
            get
            {
                SqlConnection conn = new SqlConnection(connectionString);
                if (conn == null)
                {
                    conn.Open();
                    return conn;
                }
                if (conn.State == ConnectionState.Closed)
                {
                    conn.Open();
                    return conn;
                }
                if (conn.State == ConnectionState.Broken)
                {
                    conn.Close();
                    conn.Open();
                }
                return conn;
            }
        }

        private static string connectionString
        {
            get
            {
             
                return conStr;
            }
        }
    }
}
