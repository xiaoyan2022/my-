﻿/** 
* 类 名： yisheng
*/
using System;
using System.Data;
using System.Text;
using System.Data.SqlClient;

namespace DAL
{
	/// <summary>
	/// 数据访问类:yisheng
	/// </summary>
	public partial class yisheng
	{
		public yisheng()
		{}
		#region  BasicMethod

		/// <summary>
		/// 得到最大ID
		/// </summary>
		public int GetMaxId()
		{
		return DbHelperSQL.GetMaxID("id", "yisheng"); 
		}

		/// <summary>
		/// 是否存在该记录
		/// </summary>
		public bool Exists(int id)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select count(1) from yisheng");
			strSql.Append(" where id=@id");
			SqlParameter[] parameters = {
					new SqlParameter("@id", SqlDbType.Int,4)
			};
			parameters[0].Value = id;

			return DbHelperSQL.Exists(strSql.ToString(),parameters);
		}


		/// <summary>
		/// 增加一条数据
		/// </summary>
		public int Add(Model.yisheng model)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("insert into yisheng(");
			strSql.Append("gonghao,xingming,zhiwei,jianjie,keshi,guahaofei)");
			strSql.Append(" values (");
			strSql.Append("@gonghao,@xingming,@zhiwei,@jianjie,@keshi,@guahaofei)");
			strSql.Append(";select @@IDENTITY");
			SqlParameter[] parameters = {
					new SqlParameter("@gonghao", SqlDbType.NVarChar,50),
					new SqlParameter("@xingming", SqlDbType.NVarChar,50),
					new SqlParameter("@zhiwei", SqlDbType.NVarChar,50),
					new SqlParameter("@jianjie", SqlDbType.NVarChar,50),
					new SqlParameter("@keshi", SqlDbType.Int,4),
					new SqlParameter("@guahaofei", SqlDbType.Decimal,9)};
			parameters[0].Value = model.gonghao;
			parameters[1].Value = model.xingming;
			parameters[2].Value = model.zhiwei;
			parameters[3].Value = model.jianjie;
			parameters[4].Value = model.keshi;
			parameters[5].Value = model.guahaofei;

			object obj = DbHelperSQL.GetSingle(strSql.ToString(),parameters);
			if (obj == null)
			{
				return 0;
			}
			else
			{
				return Convert.ToInt32(obj);
			}
		}
		/// <summary>
		/// 更新一条数据
		/// </summary>
		public bool Update(Model.yisheng model)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("update yisheng set ");
			strSql.Append("gonghao=@gonghao,");
			strSql.Append("xingming=@xingming,");
			strSql.Append("zhiwei=@zhiwei,");
			strSql.Append("jianjie=@jianjie,");
			strSql.Append("keshi=@keshi,");
			strSql.Append("guahaofei=@guahaofei");
			strSql.Append(" where id=@id");
			SqlParameter[] parameters = {
					new SqlParameter("@gonghao", SqlDbType.NVarChar,50),
					new SqlParameter("@xingming", SqlDbType.NVarChar,50),
					new SqlParameter("@zhiwei", SqlDbType.NVarChar,50),
					new SqlParameter("@jianjie", SqlDbType.NVarChar,50),
					new SqlParameter("@keshi", SqlDbType.Int,4),
					new SqlParameter("@guahaofei", SqlDbType.Decimal,9),
					new SqlParameter("@id", SqlDbType.Int,4)};
			parameters[0].Value = model.gonghao;
			parameters[1].Value = model.xingming;
			parameters[2].Value = model.zhiwei;
			parameters[3].Value = model.jianjie;
			parameters[4].Value = model.keshi;
			parameters[5].Value = model.guahaofei;
			parameters[6].Value = model.id;

			int rows=DbHelperSQL.ExecuteSql(strSql.ToString(),parameters);
			if (rows > 0)
			{
				return true;
			}
			else
			{
				return false;
			}
		}

		/// <summary>
		/// 删除一条数据
		/// </summary>
		public bool Delete(int id)
		{
			
			StringBuilder strSql=new StringBuilder();
			strSql.Append("delete from yisheng ");
			strSql.Append(" where id=@id");
			SqlParameter[] parameters = {
					new SqlParameter("@id", SqlDbType.Int,4)
			};
			parameters[0].Value = id;

			int rows=DbHelperSQL.ExecuteSql(strSql.ToString(),parameters);
			if (rows > 0)
			{
				return true;
			}
			else
			{
				return false;
			}
		}
		/// <summary>
		/// 批量删除数据
		/// </summary>
		public bool DeleteList(string idlist )
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("delete from yisheng ");
			strSql.Append(" where id in ("+idlist + ")  ");
			int rows=DbHelperSQL.ExecuteSql(strSql.ToString());
			if (rows > 0)
			{
				return true;
			}
			else
			{
				return false;
			}
		}


		/// <summary>
		/// 得到一个对象实体
		/// </summary>
		public Model.yisheng GetModel(int id)
		{
			
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select  top 1 id,gonghao,xingming,zhiwei,jianjie,keshi,guahaofei from yisheng ");
			strSql.Append(" where id=@id");
			SqlParameter[] parameters = {
					new SqlParameter("@id", SqlDbType.Int,4)
			};
			parameters[0].Value = id;

			Model.yisheng model=new Model.yisheng();
			DataSet ds=DbHelperSQL.Query(strSql.ToString(),parameters);
			if(ds.Tables[0].Rows.Count>0)
			{
				return DataRowToModel(ds.Tables[0].Rows[0]);
			}
			else
			{
				return null;
			}
		}


		/// <summary>
		/// 得到一个对象实体
		/// </summary>
		public Model.yisheng DataRowToModel(DataRow row)
		{
			Model.yisheng model=new Model.yisheng();
			if (row != null)
			{
				if(row["id"]!=null && row["id"].ToString()!="")
				{
					model.id=int.Parse(row["id"].ToString());
				}
				if(row["gonghao"]!=null)
				{
					model.gonghao=row["gonghao"].ToString();
				}
				if(row["xingming"]!=null)
				{
					model.xingming=row["xingming"].ToString();
				}
				if(row["zhiwei"]!=null)
				{
					model.zhiwei=row["zhiwei"].ToString();
				}
				if(row["jianjie"]!=null)
				{
					model.jianjie=row["jianjie"].ToString();
				}
				if(row["keshi"]!=null && row["keshi"].ToString()!="")
				{
					model.keshi=int.Parse(row["keshi"].ToString());
				}
				if(row["guahaofei"]!=null && row["guahaofei"].ToString()!="")
				{
					model.guahaofei=decimal.Parse(row["guahaofei"].ToString());
				}
			}
			return model;
		}

		/// <summary>
		/// 获得数据列表
		/// </summary>
		public DataSet GetList(string strWhere)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select id,gonghao,xingming,zhiwei,jianjie,keshi,guahaofei ");
			strSql.Append(" FROM yisheng ");
			if(strWhere.Trim()!="")
			{
				strSql.Append(" where "+strWhere);
			}
			return DbHelperSQL.Query(strSql.ToString());
		}

		/// <summary>
		/// 获得前几行数据
		/// </summary>
		public DataSet GetList(int Top,string strWhere,string filedOrder)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select ");
			if(Top>0)
			{
				strSql.Append(" top "+Top.ToString());
			}
			strSql.Append(" id,gonghao,xingming,zhiwei,jianjie,keshi,guahaofei ");
			strSql.Append(" FROM yisheng ");
			if(strWhere.Trim()!="")
			{
				strSql.Append(" where "+strWhere);
			}
			strSql.Append(" order by " + filedOrder);
			return DbHelperSQL.Query(strSql.ToString());
		}

		/// <summary>
		/// 获取记录总数
		/// </summary>
		public int GetRecordCount(string strWhere)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select count(1) FROM yisheng ");
			if(strWhere.Trim()!="")
			{
				strSql.Append(" where "+strWhere);
			}
			object obj = DbHelperSQL.GetSingle(strSql.ToString());
			if (obj == null)
			{
				return 0;
			}
			else
			{
				return Convert.ToInt32(obj);
			}
		}
		/// <summary>
		/// 分页获取数据列表
		/// </summary>
		public DataSet GetListByPage(string strWhere, string orderby, int startIndex, int endIndex)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("SELECT * FROM ( ");
			strSql.Append(" SELECT ROW_NUMBER() OVER (");
			if (!string.IsNullOrEmpty(orderby.Trim()))
			{
				strSql.Append("order by T." + orderby );
			}
			else
			{
				strSql.Append("order by T.id desc");
			}
			strSql.Append(")AS Row, T.*  from yisheng T ");
			if (!string.IsNullOrEmpty(strWhere.Trim()))
			{
				strSql.Append(" WHERE " + strWhere);
			}
			strSql.Append(" ) TT");
			strSql.AppendFormat(" WHERE TT.Row between {0} and {1}", startIndex, endIndex);
			return DbHelperSQL.Query(strSql.ToString());
		}

		/*
		/// <summary>
		/// 分页获取数据列表
		/// </summary>
		public DataSet GetList(int PageSize,int PageIndex,string strWhere)
		{
			SqlParameter[] parameters = {
					new SqlParameter("@tblName", SqlDbType.VarChar, 255),
					new SqlParameter("@fldName", SqlDbType.VarChar, 255),
					new SqlParameter("@PageSize", SqlDbType.Int),
					new SqlParameter("@PageIndex", SqlDbType.Int),
					new SqlParameter("@IsReCount", SqlDbType.Bit),
					new SqlParameter("@OrderType", SqlDbType.Bit),
					new SqlParameter("@strWhere", SqlDbType.VarChar,1000),
					};
			parameters[0].Value = "yisheng";
			parameters[1].Value = "id";
			parameters[2].Value = PageSize;
			parameters[3].Value = PageIndex;
			parameters[4].Value = 0;
			parameters[5].Value = 0;
			parameters[6].Value = strWhere;	
			return DbHelperSQL.RunProcedure("UP_GetRecordByPage",parameters,"ds");
		}*/

		#endregion  BasicMethod
		#region  ExtensionMethod

		#endregion  ExtensionMethod
	}
}

