﻿namespace guahaoxitong
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.病人管理ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.科室管理ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.医生管理ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.挂号管理ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.病人管理ToolStripMenuItem,
            this.科室管理ToolStripMenuItem,
            this.医生管理ToolStripMenuItem,
            this.挂号管理ToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(931, 25);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // 病人管理ToolStripMenuItem
            // 
            this.病人管理ToolStripMenuItem.Name = "病人管理ToolStripMenuItem";
            this.病人管理ToolStripMenuItem.Size = new System.Drawing.Size(68, 21);
            this.病人管理ToolStripMenuItem.Text = "病人管理";
            this.病人管理ToolStripMenuItem.Click += new System.EventHandler(this.病人管理ToolStripMenuItem_Click);
            // 
            // 科室管理ToolStripMenuItem
            // 
            this.科室管理ToolStripMenuItem.Name = "科室管理ToolStripMenuItem";
            this.科室管理ToolStripMenuItem.Size = new System.Drawing.Size(68, 21);
            this.科室管理ToolStripMenuItem.Text = "科室管理";
            this.科室管理ToolStripMenuItem.Click += new System.EventHandler(this.科室管理ToolStripMenuItem_Click);
            // 
            // 医生管理ToolStripMenuItem
            // 
            this.医生管理ToolStripMenuItem.Name = "医生管理ToolStripMenuItem";
            this.医生管理ToolStripMenuItem.Size = new System.Drawing.Size(68, 21);
            this.医生管理ToolStripMenuItem.Text = "医生管理";
            this.医生管理ToolStripMenuItem.Click += new System.EventHandler(this.医生管理ToolStripMenuItem_Click);
            // 
            // 挂号管理ToolStripMenuItem
            // 
            this.挂号管理ToolStripMenuItem.Name = "挂号管理ToolStripMenuItem";
            this.挂号管理ToolStripMenuItem.Size = new System.Drawing.Size(68, 21);
            this.挂号管理ToolStripMenuItem.Text = "挂号管理";
            this.挂号管理ToolStripMenuItem.Click += new System.EventHandler(this.挂号管理ToolStripMenuItem_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(931, 464);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Form1";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem 病人管理ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 科室管理ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 医生管理ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 挂号管理ToolStripMenuItem;
    }
}

