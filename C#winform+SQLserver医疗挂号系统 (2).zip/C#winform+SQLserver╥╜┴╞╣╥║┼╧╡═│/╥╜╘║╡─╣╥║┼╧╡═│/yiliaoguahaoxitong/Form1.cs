﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace guahaoxitong
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void 病人管理ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var frm = new Frm_userinfoManager();
            frm.ShowDialog();
        }

        private void 科室管理ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var frm = new Frm_keshiManager();
            frm.ShowDialog();
        }

        private void 医生管理ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var frm = new Frm_yishengManager();
            frm.ShowDialog();
        }

        private void 挂号管理ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var frm = new Frm_guahaoManager();
            frm.ShowDialog();
        }
    }
}
