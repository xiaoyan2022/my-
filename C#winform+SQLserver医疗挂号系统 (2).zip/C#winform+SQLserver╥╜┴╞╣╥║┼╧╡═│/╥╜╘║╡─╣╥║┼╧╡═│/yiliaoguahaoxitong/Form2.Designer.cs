﻿namespace guahaoxitong
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.挂号ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.btnSave = new System.Windows.Forms.Button();
            this.lblusername = new System.Windows.Forms.Label();
            this.txtusername = new System.Windows.Forms.TextBox();
            this.lblpassword = new System.Windows.Forms.Label();
            this.txtpassword = new System.Windows.Forms.TextBox();
            this.lblsex = new System.Windows.Forms.Label();
            this.txtsex = new System.Windows.Forms.TextBox();
            this.lblname = new System.Windows.Forms.Label();
            this.txtname = new System.Windows.Forms.TextBox();
            this.lblbirthday = new System.Windows.Forms.Label();
            this.txtbirthday = new System.Windows.Forms.TextBox();
            this.lbltelephone = new System.Windows.Forms.Label();
            this.txttelephone = new System.Windows.Forms.TextBox();
            this.挂号信息查询ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.挂号ToolStripMenuItem,
            this.挂号信息查询ToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(733, 25);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // 挂号ToolStripMenuItem
            // 
            this.挂号ToolStripMenuItem.Name = "挂号ToolStripMenuItem";
            this.挂号ToolStripMenuItem.Size = new System.Drawing.Size(44, 21);
            this.挂号ToolStripMenuItem.Text = "挂号";
            this.挂号ToolStripMenuItem.Click += new System.EventHandler(this.挂号ToolStripMenuItem_Click);
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(357, 302);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 23);
            this.btnSave.TabIndex = 29;
            this.btnSave.Text = "保存";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // lblusername
            // 
            this.lblusername.AutoSize = true;
            this.lblusername.Location = new System.Drawing.Point(230, 92);
            this.lblusername.Name = "lblusername";
            this.lblusername.Size = new System.Drawing.Size(53, 12);
            this.lblusername.TabIndex = 30;
            this.lblusername.Text = "用户名：";
            // 
            // txtusername
            // 
            this.txtusername.Location = new System.Drawing.Point(300, 86);
            this.txtusername.Name = "txtusername";
            this.txtusername.Size = new System.Drawing.Size(180, 21);
            this.txtusername.TabIndex = 31;
            // 
            // lblpassword
            // 
            this.lblpassword.AutoSize = true;
            this.lblpassword.Location = new System.Drawing.Point(242, 122);
            this.lblpassword.Name = "lblpassword";
            this.lblpassword.Size = new System.Drawing.Size(41, 12);
            this.lblpassword.TabIndex = 32;
            this.lblpassword.Text = "密码：";
            // 
            // txtpassword
            // 
            this.txtpassword.Location = new System.Drawing.Point(300, 116);
            this.txtpassword.Name = "txtpassword";
            this.txtpassword.Size = new System.Drawing.Size(180, 21);
            this.txtpassword.TabIndex = 33;
            // 
            // lblsex
            // 
            this.lblsex.AutoSize = true;
            this.lblsex.Location = new System.Drawing.Point(242, 152);
            this.lblsex.Name = "lblsex";
            this.lblsex.Size = new System.Drawing.Size(41, 12);
            this.lblsex.TabIndex = 34;
            this.lblsex.Text = "性别：";
            // 
            // txtsex
            // 
            this.txtsex.Location = new System.Drawing.Point(300, 146);
            this.txtsex.Name = "txtsex";
            this.txtsex.Size = new System.Drawing.Size(180, 21);
            this.txtsex.TabIndex = 35;
            // 
            // lblname
            // 
            this.lblname.AutoSize = true;
            this.lblname.Location = new System.Drawing.Point(242, 182);
            this.lblname.Name = "lblname";
            this.lblname.Size = new System.Drawing.Size(41, 12);
            this.lblname.TabIndex = 36;
            this.lblname.Text = "姓名：";
            // 
            // txtname
            // 
            this.txtname.Location = new System.Drawing.Point(300, 176);
            this.txtname.Name = "txtname";
            this.txtname.Size = new System.Drawing.Size(180, 21);
            this.txtname.TabIndex = 37;
            // 
            // lblbirthday
            // 
            this.lblbirthday.AutoSize = true;
            this.lblbirthday.Location = new System.Drawing.Point(218, 212);
            this.lblbirthday.Name = "lblbirthday";
            this.lblbirthday.Size = new System.Drawing.Size(65, 12);
            this.lblbirthday.TabIndex = 38;
            this.lblbirthday.Text = "出生年月：";
            // 
            // txtbirthday
            // 
            this.txtbirthday.Location = new System.Drawing.Point(300, 206);
            this.txtbirthday.Name = "txtbirthday";
            this.txtbirthday.Size = new System.Drawing.Size(180, 21);
            this.txtbirthday.TabIndex = 39;
            // 
            // lbltelephone
            // 
            this.lbltelephone.AutoSize = true;
            this.lbltelephone.Location = new System.Drawing.Point(242, 242);
            this.lbltelephone.Name = "lbltelephone";
            this.lbltelephone.Size = new System.Drawing.Size(41, 12);
            this.lbltelephone.TabIndex = 40;
            this.lbltelephone.Text = "电话：";
            // 
            // txttelephone
            // 
            this.txttelephone.Location = new System.Drawing.Point(300, 236);
            this.txttelephone.Name = "txttelephone";
            this.txttelephone.Size = new System.Drawing.Size(180, 21);
            this.txttelephone.TabIndex = 41;
            // 
            // 挂号信息查询ToolStripMenuItem
            // 
            this.挂号信息查询ToolStripMenuItem.Name = "挂号信息查询ToolStripMenuItem";
            this.挂号信息查询ToolStripMenuItem.Size = new System.Drawing.Size(92, 21);
            this.挂号信息查询ToolStripMenuItem.Text = "挂号信息查询";
            this.挂号信息查询ToolStripMenuItem.Click += new System.EventHandler(this.挂号信息查询ToolStripMenuItem_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(733, 432);
            this.Controls.Add(this.lblusername);
            this.Controls.Add(this.txtusername);
            this.Controls.Add(this.lblpassword);
            this.Controls.Add(this.txtpassword);
            this.Controls.Add(this.lblsex);
            this.Controls.Add(this.txtsex);
            this.Controls.Add(this.lblname);
            this.Controls.Add(this.txtname);
            this.Controls.Add(this.lblbirthday);
            this.Controls.Add(this.txtbirthday);
            this.Controls.Add(this.lbltelephone);
            this.Controls.Add(this.txttelephone);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form2";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem 挂号ToolStripMenuItem;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Label lblusername;
        private System.Windows.Forms.TextBox txtusername;
        private System.Windows.Forms.Label lblpassword;
        private System.Windows.Forms.TextBox txtpassword;
        private System.Windows.Forms.Label lblsex;
        private System.Windows.Forms.TextBox txtsex;
        private System.Windows.Forms.Label lblname;
        private System.Windows.Forms.TextBox txtname;
        private System.Windows.Forms.Label lblbirthday;
        private System.Windows.Forms.TextBox txtbirthday;
        private System.Windows.Forms.Label lbltelephone;
        private System.Windows.Forms.TextBox txttelephone;
        private System.Windows.Forms.ToolStripMenuItem 挂号信息查询ToolStripMenuItem;
    }
}