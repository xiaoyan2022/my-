﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace guahaoxitong
{
    public partial class Form2 : Form
    {
        Model.userinfo model = new Model.userinfo();
        public Form2()
        {
            InitializeComponent();
            model = new BLL.userinfo().GetModel(loginuser.userinfo.id);
            txtusername.Text = model.username;
            txtpassword.Text = model.password;
            txtsex.Text = model.sex;
            txtname.Text = model.name;
            txtbirthday.Text = model.birthday;
            txttelephone.Text = model.telephone;


        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            model.username = txtusername.Text;
            model.password = txtpassword.Text;
            model.sex = txtsex.Text;
            model.name = txtname.Text;
            model.birthday = txtbirthday.Text;
            model.telephone = txttelephone.Text;

            if (model.id > 0)
            {
                new BLL.userinfo().Update(model);
            }
            else
            {
                new BLL.userinfo().Add(model);
            }
            MessageBox.Show("操作成功！");
            this.Close();
            return;
        }

        private void 挂号ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var frm = new Frm_yishengSearch();
            frm.ShowDialog();
        }

        private void 挂号信息查询ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var frm = new Frm_guahaoSearch();
            frm.ShowDialog();
        }
    }
}
