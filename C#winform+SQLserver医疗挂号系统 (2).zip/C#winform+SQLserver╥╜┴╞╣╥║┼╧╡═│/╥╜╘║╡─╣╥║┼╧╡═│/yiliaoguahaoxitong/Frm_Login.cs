﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace guahaoxitong
{
    public partial class Frm_Login : Form
    {
        public Frm_Login()
        {
            InitializeComponent(); 
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            
                var list = new BLL.userinfo().GetModelList(string.Format("username='{0}' and password='{1}'", txtusername.Text, txtpassword.Text));
                if (list.Any()) {
                    loginuser.userinfo = list[0];
                    if (list[0].role == "管理员")
                    {
                        new Form1().ShowDialog();
                    }
                    else {
                        new Form2().ShowDialog();
                    }
                }
                else
                {
                    MessageBox.Show("用户名或密码错误");
                    return;
                }
             
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        /// <summary>
        /// 注册
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button1_Click(object sender, EventArgs e)
        {
            var frm = new Frm_userinfoAU();
            frm.ShowDialog();
        }
    }
}
