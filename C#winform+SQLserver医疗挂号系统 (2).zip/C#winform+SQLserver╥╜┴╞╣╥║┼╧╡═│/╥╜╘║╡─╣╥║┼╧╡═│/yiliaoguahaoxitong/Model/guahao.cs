﻿/** 
* 类 名： guahao
*/
using System;
namespace Model
{
	/// <summary>
	/// guahao:实体类(属性说明自动提取数据库字段的描述信息)
	/// </summary>
	[Serializable]
	public partial class guahao
	{
		public guahao()
		{}
		#region Model
		private int _id;
		private int? _userid;
		private DateTime? _guahaoshijian;
		private int? _yishengid;
		private string _zhuangtai;
		/// <summary>
		/// 
		/// </summary>
		public int id
		{
			set{ _id=value;}
			get{return _id;}
		}
		/// <summary>
		/// 患者
		/// </summary>
		public int? userid
		{
			set{ _userid=value;}
			get{return _userid;}
		}
		/// <summary>
		/// 挂号时间
		/// </summary>
		public DateTime? guahaoshijian
		{
			set{ _guahaoshijian=value;}
			get{return _guahaoshijian;}
		}
		/// <summary>
		/// 医生
		/// </summary>
		public int? yishengid
		{
			set{ _yishengid=value;}
			get{return _yishengid;}
		}
		/// <summary>
		/// 状态
		/// </summary>
		public string zhuangtai
		{
			set{ _zhuangtai=value;}
			get{return _zhuangtai;}
		}
		#endregion Model

	}
}

