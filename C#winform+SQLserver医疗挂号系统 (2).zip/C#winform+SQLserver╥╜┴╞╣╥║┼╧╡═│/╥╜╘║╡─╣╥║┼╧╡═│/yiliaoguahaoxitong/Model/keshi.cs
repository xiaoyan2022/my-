﻿/** 
* 类 名： keshi
*/
using System;
namespace Model
{
	/// <summary>
	/// keshi:实体类(属性说明自动提取数据库字段的描述信息)
	/// </summary>
	[Serializable]
	public partial class keshi
	{
		public keshi()
		{}
		#region Model
		private int _id;
		private string _keshibianhao;
		private string _keshimingcheng;
		private string _louceng;
		/// <summary>
		/// 
		/// </summary>
		public int id
		{
			set{ _id=value;}
			get{return _id;}
		}
		/// <summary>
		/// 科室号
		/// </summary>
		public string keshibianhao
		{
			set{ _keshibianhao=value;}
			get{return _keshibianhao;}
		}
		/// <summary>
		/// 科室名称
		/// </summary>
		public string keshimingcheng
		{
			set{ _keshimingcheng=value;}
			get{return _keshimingcheng;}
		}
		/// <summary>
		/// 楼层
		/// </summary>
		public string louceng
		{
			set{ _louceng=value;}
			get{return _louceng;}
		}
		#endregion Model

	}
}

