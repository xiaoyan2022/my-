﻿/** 
* 类 名： yisheng
*/
using System;
namespace Model
{
	/// <summary>
	/// yisheng:实体类(属性说明自动提取数据库字段的描述信息)
	/// </summary>
	[Serializable]
	public partial class yisheng
	{
		public yisheng()
		{}
		#region Model
		private int _id;
		private string _gonghao;
		private string _xingming;
		private string _zhiwei;
		private string _jianjie;
		private int? _keshi;
		private decimal? _guahaofei;
		/// <summary>
		/// 
		/// </summary>
		public int id
		{
			set{ _id=value;}
			get{return _id;}
		}
		/// <summary>
		/// 工号
		/// </summary>
		public string gonghao
		{
			set{ _gonghao=value;}
			get{return _gonghao;}
		}
		/// <summary>
		/// 姓名
		/// </summary>
		public string xingming
		{
			set{ _xingming=value;}
			get{return _xingming;}
		}
		/// <summary>
		/// 职位
		/// </summary>
		public string zhiwei
		{
			set{ _zhiwei=value;}
			get{return _zhiwei;}
		}
		/// <summary>
		/// 简介
		/// </summary>
		public string jianjie
		{
			set{ _jianjie=value;}
			get{return _jianjie;}
		}
		/// <summary>
		/// 科室
		/// </summary>
		public int? keshi
		{
			set{ _keshi=value;}
			get{return _keshi;}
		}
		/// <summary>
		/// 挂号费
		/// </summary>
		public decimal? guahaofei
		{
			set{ _guahaofei=value;}
			get{return _guahaofei;}
		}
		#endregion Model

	}
}

