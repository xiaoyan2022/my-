﻿   namespace guahaoxitong
{
    partial class Frm_guahaoAU
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
              this.lbluserid = new System.Windows.Forms.Label();
            this.txtuserid = new System.Windows.Forms.TextBox();
  this.lblguahaoshijian = new System.Windows.Forms.Label();
            this.txtguahaoshijian = new System.Windows.Forms.TextBox();
  this.lblyishengid = new System.Windows.Forms.Label();
            this.txtyishengid = new System.Windows.Forms.TextBox();
  this.lblzhuangtai = new System.Windows.Forms.Label();
            this.txtzhuangtai = new System.Windows.Forms.TextBox();
  this.btnClose = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbluserid
            // 
            this.lbluserid.AutoSize = true;
            this.lbluserid.Location = new System.Drawing.Point(10,10 );
            this.lbluserid.Name = "lbluserid";
            this.lbluserid.Size = new System.Drawing.Size(65, 12);
            this.lbluserid.TabIndex = 1;
            this.lbluserid.Text = "患者：";
            // 
            // txtshoukeshijian
            // 
            this.txtuserid.Location = new System.Drawing.Point(80, 10);
            this.txtuserid.Name = "txtuserid";
            this.txtuserid.Size = new System.Drawing.Size(180, 21);
            this.txtuserid.TabIndex = 2;
 // 
            // lblguahaoshijian
            // 
            this.lblguahaoshijian.AutoSize = true;
            this.lblguahaoshijian.Location = new System.Drawing.Point(10,40 );
            this.lblguahaoshijian.Name = "lblguahaoshijian";
            this.lblguahaoshijian.Size = new System.Drawing.Size(65, 12);
            this.lblguahaoshijian.TabIndex = 3;
            this.lblguahaoshijian.Text = "挂号时间：";
            // 
            // txtshoukeshijian
            // 
            this.txtguahaoshijian.Location = new System.Drawing.Point(80, 40);
            this.txtguahaoshijian.Name = "txtguahaoshijian";
            this.txtguahaoshijian.Size = new System.Drawing.Size(180, 21);
            this.txtguahaoshijian.TabIndex = 4;
 // 
            // lblyishengid
            // 
            this.lblyishengid.AutoSize = true;
            this.lblyishengid.Location = new System.Drawing.Point(10,70 );
            this.lblyishengid.Name = "lblyishengid";
            this.lblyishengid.Size = new System.Drawing.Size(65, 12);
            this.lblyishengid.TabIndex = 5;
            this.lblyishengid.Text = "医生：";
            // 
            // txtshoukeshijian
            // 
            this.txtyishengid.Location = new System.Drawing.Point(80, 70);
            this.txtyishengid.Name = "txtyishengid";
            this.txtyishengid.Size = new System.Drawing.Size(180, 21);
            this.txtyishengid.TabIndex = 6;
 // 
            // lblzhuangtai
            // 
            this.lblzhuangtai.AutoSize = true;
            this.lblzhuangtai.Location = new System.Drawing.Point(10,100 );
            this.lblzhuangtai.Name = "lblzhuangtai";
            this.lblzhuangtai.Size = new System.Drawing.Size(65, 12);
            this.lblzhuangtai.TabIndex = 7;
            this.lblzhuangtai.Text = "状态：";
            // 
            // txtshoukeshijian
            // 
            this.txtzhuangtai.Location = new System.Drawing.Point(80, 100);
            this.txtzhuangtai.Name = "txtzhuangtai";
            this.txtzhuangtai.Size = new System.Drawing.Size(180, 21);
            this.txtzhuangtai.TabIndex = 8;
 
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(10, 130);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 23);
            this.btnSave.TabIndex = 9;
            this.btnSave.Text = "保存";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);

            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(50, 130);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(75, 23);
            this.btnClose.TabIndex = 10;
            this.btnClose.Text = "关闭";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // Frm_guahaoAU
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(598, 255);
             this.Controls.Add(this.lbluserid);
            this.Controls.Add(this.txtuserid);
 this.Controls.Add(this.lblguahaoshijian);
            this.Controls.Add(this.txtguahaoshijian);
 this.Controls.Add(this.lblyishengid);
            this.Controls.Add(this.txtyishengid);
 this.Controls.Add(this.lblzhuangtai);
            this.Controls.Add(this.txtzhuangtai);

            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.btnSave);
this.Name = "Frm_guahaoAU";
            this.Text = "guahao编辑";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbluserid;
        private System.Windows.Forms.TextBox txtuserid;
 private System.Windows.Forms.Label lblguahaoshijian;
        private System.Windows.Forms.TextBox txtguahaoshijian;
 private System.Windows.Forms.Label lblyishengid;
        private System.Windows.Forms.TextBox txtyishengid;
 private System.Windows.Forms.Label lblzhuangtai;
        private System.Windows.Forms.TextBox txtzhuangtai;

        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Button btnSave;

    }
       
} 