﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace guahaoxitong
{
    public partial class Frm_guahaoAU : Form
    {
        public Frm_guahaoAU()
        {
            InitializeComponent();
        }
        Model.guahao model = new Model.guahao();
        public Frm_guahaoAU(int id)
            : this()
        {
            model = new BLL.guahao().GetModel(id);
            txtuserid.Text = model.userid.ToString();
            txtguahaoshijian.Text = model.guahaoshijian.ToString();
            txtyishengid.Text = model.yishengid.ToString();
            txtzhuangtai.Text = model.zhuangtai;


        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            model.userid = Convert.ToInt32(txtuserid.Text);
            model.guahaoshijian = Convert.ToDateTime(txtguahaoshijian.Text);
            model.yishengid = Convert.ToInt32(txtyishengid.Text);
            model.zhuangtai = txtzhuangtai.Text;

            if (model.id > 0)
            {
                new BLL.guahao().Update(model);
            }
            else
            {
                new BLL.guahao().Add(model);
            }
            MessageBox.Show("操作成功！");
            this.Close();
            return;
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}