﻿   namespace guahaoxitong
{
    partial class Frm_guahaoManager
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.编辑ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.添加ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.删除ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.刷新ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lbluserid = new System.Windows.Forms.Label();
            this.txtuserid = new System.Windows.Forms.TextBox();
            this.lblguahaoshijian = new System.Windows.Forms.Label();
            this.txtguahaoshijian = new System.Windows.Forms.TextBox();
            this.lblyishengid = new System.Windows.Forms.Label();
            this.txtyishengid = new System.Windows.Forms.TextBox();
            this.btnsearch = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.colid = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.coluserid = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colguahaoshijian = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colyishengid = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colzhuangtai = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.menuStrip1.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // 编辑ToolStripMenuItem
            // 
            this.编辑ToolStripMenuItem.Name = "编辑ToolStripMenuItem";
            this.编辑ToolStripMenuItem.Size = new System.Drawing.Size(44, 21);
            this.编辑ToolStripMenuItem.Text = "编辑";
            this.编辑ToolStripMenuItem.Click += new System.EventHandler(this.编辑ToolStripMenuItem_Click);
            // 
            // 添加ToolStripMenuItem
            // 
            this.添加ToolStripMenuItem.Name = "添加ToolStripMenuItem";
            this.添加ToolStripMenuItem.Size = new System.Drawing.Size(44, 21);
            this.添加ToolStripMenuItem.Text = "添加";
            this.添加ToolStripMenuItem.Click += new System.EventHandler(this.添加ToolStripMenuItem_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.添加ToolStripMenuItem,
            this.编辑ToolStripMenuItem,
            this.删除ToolStripMenuItem,
            this.刷新ToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(601, 25);
            this.menuStrip1.TabIndex = 4;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // 删除ToolStripMenuItem
            // 
            this.删除ToolStripMenuItem.Name = "删除ToolStripMenuItem";
            this.删除ToolStripMenuItem.Size = new System.Drawing.Size(44, 21);
            this.删除ToolStripMenuItem.Text = "删除";
            this.删除ToolStripMenuItem.Click += new System.EventHandler(this.删除ToolStripMenuItem_Click);
            // 
            // 刷新ToolStripMenuItem
            // 
            this.刷新ToolStripMenuItem.Name = "刷新ToolStripMenuItem";
            this.刷新ToolStripMenuItem.Size = new System.Drawing.Size(44, 21);
            this.刷新ToolStripMenuItem.Text = "刷新";
            this.刷新ToolStripMenuItem.Click += new System.EventHandler(this.刷新ToolStripMenuItem_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.lbluserid);
            this.panel1.Controls.Add(this.txtuserid);
            this.panel1.Controls.Add(this.lblguahaoshijian);
            this.panel1.Controls.Add(this.txtguahaoshijian);
            this.panel1.Controls.Add(this.lblyishengid);
            this.panel1.Controls.Add(this.txtyishengid);
            this.panel1.Controls.Add(this.btnsearch);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 25);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(601, 35);
            this.panel1.TabIndex = 6;
            // 
            // lbluserid
            // 
            this.lbluserid.AutoSize = true;
            this.lbluserid.Location = new System.Drawing.Point(12, 13);
            this.lbluserid.Name = "lbluserid";
            this.lbluserid.Size = new System.Drawing.Size(41, 12);
            this.lbluserid.TabIndex = 3;
            this.lbluserid.Text = "患者：";
            // 
            // txtuserid
            // 
            this.txtuserid.Location = new System.Drawing.Point(59, 10);
            this.txtuserid.Name = "txtuserid";
            this.txtuserid.Size = new System.Drawing.Size(100, 21);
            this.txtuserid.TabIndex = 4;
            // 
            // lblguahaoshijian
            // 
            this.lblguahaoshijian.AutoSize = true;
            this.lblguahaoshijian.Location = new System.Drawing.Point(165, 13);
            this.lblguahaoshijian.Name = "lblguahaoshijian";
            this.lblguahaoshijian.Size = new System.Drawing.Size(65, 12);
            this.lblguahaoshijian.TabIndex = 5;
            this.lblguahaoshijian.Text = "挂号时间：";
            // 
            // txtguahaoshijian
            // 
            this.txtguahaoshijian.Location = new System.Drawing.Point(236, 10);
            this.txtguahaoshijian.Name = "txtguahaoshijian";
            this.txtguahaoshijian.Size = new System.Drawing.Size(100, 21);
            this.txtguahaoshijian.TabIndex = 6;
            // 
            // lblyishengid
            // 
            this.lblyishengid.AutoSize = true;
            this.lblyishengid.Location = new System.Drawing.Point(344, 13);
            this.lblyishengid.Name = "lblyishengid";
            this.lblyishengid.Size = new System.Drawing.Size(41, 12);
            this.lblyishengid.TabIndex = 7;
            this.lblyishengid.Text = "医生：";
            // 
            // txtyishengid
            // 
            this.txtyishengid.Location = new System.Drawing.Point(382, 8);
            this.txtyishengid.Name = "txtyishengid";
            this.txtyishengid.Size = new System.Drawing.Size(100, 21);
            this.txtyishengid.TabIndex = 8;
            // 
            // btnsearch
            // 
            this.btnsearch.Location = new System.Drawing.Point(488, 8);
            this.btnsearch.Name = "btnsearch";
            this.btnsearch.Size = new System.Drawing.Size(75, 23);
            this.btnsearch.TabIndex = 17;
            this.btnsearch.Text = "查询";
            this.btnsearch.Click += new System.EventHandler(this.btnsearch_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colid,
            this.coluserid,
            this.colguahaoshijian,
            this.colyishengid,
            this.colzhuangtai});
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView1.Location = new System.Drawing.Point(0, 60);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(601, 195);
            this.dataGridView1.TabIndex = 0;
            // 
            // colid
            // 
            this.colid.DataPropertyName = "id";
            this.colid.HeaderText = "id";
            this.colid.Name = "colid";
            this.colid.ReadOnly = true;
            this.colid.Visible = false;
            // 
            // coluserid
            // 
            this.coluserid.DataPropertyName = "userid";
            this.coluserid.HeaderText = "患者";
            this.coluserid.Name = "coluserid";
            this.coluserid.ReadOnly = true;
            // 
            // colguahaoshijian
            // 
            this.colguahaoshijian.DataPropertyName = "guahaoshijian";
            this.colguahaoshijian.HeaderText = "挂号时间";
            this.colguahaoshijian.Name = "colguahaoshijian";
            this.colguahaoshijian.ReadOnly = true;
            // 
            // colyishengid
            // 
            this.colyishengid.DataPropertyName = "yishengid";
            this.colyishengid.HeaderText = "医生";
            this.colyishengid.Name = "colyishengid";
            this.colyishengid.ReadOnly = true;
            // 
            // colzhuangtai
            // 
            this.colzhuangtai.DataPropertyName = "zhuangtai";
            this.colzhuangtai.HeaderText = "状态";
            this.colzhuangtai.Name = "colzhuangtai";
            this.colzhuangtai.ReadOnly = true;
            // 
            // Frm_guahaoManager
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(601, 255);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.menuStrip1);
            this.Name = "Frm_guahaoManager";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStripMenuItem 编辑ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 添加ToolStripMenuItem;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem 删除ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 刷新ToolStripMenuItem;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button btnsearch;
 private System.Windows.Forms.Label lbluserid;
 private System.Windows.Forms.TextBox txtuserid;
 private System.Windows.Forms.Label lblguahaoshijian;
 private System.Windows.Forms.TextBox txtguahaoshijian;
 private System.Windows.Forms.Label lblyishengid;
 private System.Windows.Forms.TextBox txtyishengid;
 private System.Windows.Forms.DataGridViewTextBoxColumn colid;
 private System.Windows.Forms.DataGridViewTextBoxColumn coluserid;
 private System.Windows.Forms.DataGridViewTextBoxColumn colguahaoshijian;
 private System.Windows.Forms.DataGridViewTextBoxColumn colyishengid;
 private System.Windows.Forms.DataGridViewTextBoxColumn colzhuangtai;

    }
       
} 