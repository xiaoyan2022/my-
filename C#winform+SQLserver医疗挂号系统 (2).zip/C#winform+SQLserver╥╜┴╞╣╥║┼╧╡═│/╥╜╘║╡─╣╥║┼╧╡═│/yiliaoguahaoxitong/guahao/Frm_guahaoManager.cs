﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace guahaoxitong
{
    public partial class Frm_guahaoManager : Form
    {
        public Frm_guahaoManager(bool tag = true)
        {
            InitializeComponent();
            if (!tag) {
                menuStrip1.Visible = false;
            }
            dataGridView1.AutoGenerateColumns = false;
            dataGridView1.DataSource = new BLL.guahao().GetList("").Tables[0];
            
        }

        private void 添加ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Frm_guahaoAU frm = new Frm_guahaoAU();
            frm.ShowDialog();
        }

        private void 编辑ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count <= 0) {
                MessageBox.Show("请选择一条数据进行编辑");
                return;
            }
            Frm_guahaoAU frm = new Frm_guahaoAU(Convert.ToInt32(dataGridView1.SelectedRows[0].Cells["colid"].Value));
            frm.ShowDialog();
        }

        private void 删除ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count <= 0)
            {
                MessageBox.Show("请选择数据进行删除");
                return;
            }
           var ids = "";
                foreach (DataGridViewRow item in dataGridView1.SelectedRows)
                {
                   
                    ids += item.Cells[0].Value + ",";
                }
            if (MessageBox.Show("确定要删除选中的数据", "系统提示", MessageBoxButtons.YesNo) == System.Windows.Forms.DialogResult.Yes)
            {
               
                if (new BLL.guahao().DeleteList(ids.TrimEnd(',')))
                {
                    MessageBox.Show("删除成功！");
                    return;
                }
                else {
                    MessageBox.Show("删除失败！");
                    return;
                }
            }
        }

        private void 刷新ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            dataGridView1.AutoGenerateColumns = false;
            dataGridView1.DataSource = new BLL.guahao().GetList("").Tables[0];

        }
        private void btnsearch_Click(object sender, EventArgs e)
        {
            var where = "1=1";
           if (!string.IsNullOrEmpty(txtuserid.Text)) {
                where += string.Format(" and userid like '%{0}%'", txtuserid.Text);
            }if (!string.IsNullOrEmpty(txtguahaoshijian.Text)) {
                where += string.Format(" and guahaoshijian like '%{0}%'", txtguahaoshijian.Text);
            }if (!string.IsNullOrEmpty(txtyishengid.Text)) {
                where += string.Format(" and yishengid like '%{0}%'", txtyishengid.Text);
            } 
            dataGridView1.DataSource = new BLL.guahao().GetList(where).Tables[0];
            dataGridView1.Refresh();
        }

        

        
    }
}