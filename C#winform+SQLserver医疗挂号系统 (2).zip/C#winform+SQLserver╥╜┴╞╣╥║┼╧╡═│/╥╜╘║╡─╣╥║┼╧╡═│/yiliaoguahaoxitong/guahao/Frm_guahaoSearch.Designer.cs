﻿namespace guahaoxitong
{
    partial class Frm_guahaoSearch
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbluserid = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.colid = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.coluserid = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colguahaoshijian = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colyishengid = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colzhuangtai = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lblguahaoshijian = new System.Windows.Forms.Label();
            this.txtguahaoshijian = new System.Windows.Forms.TextBox();
            this.txtuserid = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblyishengid = new System.Windows.Forms.Label();
            this.txtyishengid = new System.Windows.Forms.TextBox();
            this.btnsearch = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lbluserid
            // 
            this.lbluserid.AutoSize = true;
            this.lbluserid.Location = new System.Drawing.Point(12, 13);
            this.lbluserid.Name = "lbluserid";
            this.lbluserid.Size = new System.Drawing.Size(41, 12);
            this.lbluserid.TabIndex = 3;
            this.lbluserid.Text = "患者：";
            // 
            // dataGridView1
            // 
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colid,
            this.coluserid,
            this.colguahaoshijian,
            this.colyishengid,
            this.colzhuangtai});
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView1.Location = new System.Drawing.Point(0, 35);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(930, 455);
            this.dataGridView1.TabIndex = 7;
            // 
            // colid
            // 
            this.colid.DataPropertyName = "id";
            this.colid.HeaderText = "id";
            this.colid.Name = "colid";
            this.colid.ReadOnly = true;
            this.colid.Visible = false;
            // 
            // coluserid
            // 
            this.coluserid.DataPropertyName = "userid";
            this.coluserid.HeaderText = "患者";
            this.coluserid.Name = "coluserid";
            this.coluserid.ReadOnly = true;
            // 
            // colguahaoshijian
            // 
            this.colguahaoshijian.DataPropertyName = "guahaoshijian";
            this.colguahaoshijian.HeaderText = "挂号时间";
            this.colguahaoshijian.Name = "colguahaoshijian";
            this.colguahaoshijian.ReadOnly = true;
            // 
            // colyishengid
            // 
            this.colyishengid.DataPropertyName = "yishengid";
            this.colyishengid.HeaderText = "医生";
            this.colyishengid.Name = "colyishengid";
            this.colyishengid.ReadOnly = true;
            // 
            // colzhuangtai
            // 
            this.colzhuangtai.DataPropertyName = "zhuangtai";
            this.colzhuangtai.HeaderText = "状态";
            this.colzhuangtai.Name = "colzhuangtai";
            this.colzhuangtai.ReadOnly = true;
            // 
            // lblguahaoshijian
            // 
            this.lblguahaoshijian.AutoSize = true;
            this.lblguahaoshijian.Location = new System.Drawing.Point(165, 13);
            this.lblguahaoshijian.Name = "lblguahaoshijian";
            this.lblguahaoshijian.Size = new System.Drawing.Size(65, 12);
            this.lblguahaoshijian.TabIndex = 5;
            this.lblguahaoshijian.Text = "挂号时间：";
            // 
            // txtguahaoshijian
            // 
            this.txtguahaoshijian.Location = new System.Drawing.Point(236, 10);
            this.txtguahaoshijian.Name = "txtguahaoshijian";
            this.txtguahaoshijian.Size = new System.Drawing.Size(100, 21);
            this.txtguahaoshijian.TabIndex = 6;
            // 
            // txtuserid
            // 
            this.txtuserid.Location = new System.Drawing.Point(59, 10);
            this.txtuserid.Name = "txtuserid";
            this.txtuserid.Size = new System.Drawing.Size(100, 21);
            this.txtuserid.TabIndex = 4;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.lbluserid);
            this.panel1.Controls.Add(this.txtuserid);
            this.panel1.Controls.Add(this.lblguahaoshijian);
            this.panel1.Controls.Add(this.txtguahaoshijian);
            this.panel1.Controls.Add(this.lblyishengid);
            this.panel1.Controls.Add(this.txtyishengid);
            this.panel1.Controls.Add(this.btnsearch);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(930, 35);
            this.panel1.TabIndex = 9;
            // 
            // lblyishengid
            // 
            this.lblyishengid.AutoSize = true;
            this.lblyishengid.Location = new System.Drawing.Point(344, 13);
            this.lblyishengid.Name = "lblyishengid";
            this.lblyishengid.Size = new System.Drawing.Size(41, 12);
            this.lblyishengid.TabIndex = 7;
            this.lblyishengid.Text = "医生：";
            // 
            // txtyishengid
            // 
            this.txtyishengid.Location = new System.Drawing.Point(382, 8);
            this.txtyishengid.Name = "txtyishengid";
            this.txtyishengid.Size = new System.Drawing.Size(100, 21);
            this.txtyishengid.TabIndex = 8;
            // 
            // btnsearch
            // 
            this.btnsearch.Location = new System.Drawing.Point(488, 8);
            this.btnsearch.Name = "btnsearch";
            this.btnsearch.Size = new System.Drawing.Size(75, 23);
            this.btnsearch.TabIndex = 17;
            this.btnsearch.Text = "查询";
            // 
            // Frm_guahaoSearch
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(930, 490);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.panel1);
            this.Name = "Frm_guahaoSearch";
            this.Text = "Frm_guahaoSearch";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lbluserid;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn colid;
        private System.Windows.Forms.DataGridViewTextBoxColumn coluserid;
        private System.Windows.Forms.DataGridViewTextBoxColumn colguahaoshijian;
        private System.Windows.Forms.DataGridViewTextBoxColumn colyishengid;
        private System.Windows.Forms.DataGridViewTextBoxColumn colzhuangtai;
        private System.Windows.Forms.Label lblguahaoshijian;
        private System.Windows.Forms.TextBox txtguahaoshijian;
        private System.Windows.Forms.TextBox txtuserid;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblyishengid;
        private System.Windows.Forms.TextBox txtyishengid;
        private System.Windows.Forms.Button btnsearch;
    }
}