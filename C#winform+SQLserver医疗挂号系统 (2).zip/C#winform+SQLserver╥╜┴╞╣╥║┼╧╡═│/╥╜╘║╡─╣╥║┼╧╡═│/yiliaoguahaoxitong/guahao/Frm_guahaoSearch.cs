﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace guahaoxitong
{
    public partial class Frm_guahaoSearch : Form
    {
        public Frm_guahaoSearch()
        {
            InitializeComponent();
            dataGridView1.AutoGenerateColumns = false;
            dataGridView1.DataSource = new BLL.guahao().GetList("userid="+loginuser.userinfo.id).Tables[0];
        }
    }
}
