﻿   namespace guahaoxitong
{
    partial class Frm_keshiAU
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
              this.lblkeshibianhao = new System.Windows.Forms.Label();
            this.txtkeshibianhao = new System.Windows.Forms.TextBox();
  this.lblkeshimingcheng = new System.Windows.Forms.Label();
            this.txtkeshimingcheng = new System.Windows.Forms.TextBox();
  this.lbllouceng = new System.Windows.Forms.Label();
            this.txtlouceng = new System.Windows.Forms.TextBox();
  this.btnClose = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblkeshibianhao
            // 
            this.lblkeshibianhao.AutoSize = true;
            this.lblkeshibianhao.Location = new System.Drawing.Point(10,10 );
            this.lblkeshibianhao.Name = "lblkeshibianhao";
            this.lblkeshibianhao.Size = new System.Drawing.Size(65, 12);
            this.lblkeshibianhao.TabIndex = 1;
            this.lblkeshibianhao.Text = "科室号：";
            // 
            // txtshoukeshijian
            // 
            this.txtkeshibianhao.Location = new System.Drawing.Point(80, 10);
            this.txtkeshibianhao.Name = "txtkeshibianhao";
            this.txtkeshibianhao.Size = new System.Drawing.Size(180, 21);
            this.txtkeshibianhao.TabIndex = 2;
 // 
            // lblkeshimingcheng
            // 
            this.lblkeshimingcheng.AutoSize = true;
            this.lblkeshimingcheng.Location = new System.Drawing.Point(10,40 );
            this.lblkeshimingcheng.Name = "lblkeshimingcheng";
            this.lblkeshimingcheng.Size = new System.Drawing.Size(65, 12);
            this.lblkeshimingcheng.TabIndex = 3;
            this.lblkeshimingcheng.Text = "科室名称：";
            // 
            // txtshoukeshijian
            // 
            this.txtkeshimingcheng.Location = new System.Drawing.Point(80, 40);
            this.txtkeshimingcheng.Name = "txtkeshimingcheng";
            this.txtkeshimingcheng.Size = new System.Drawing.Size(180, 21);
            this.txtkeshimingcheng.TabIndex = 4;
 // 
            // lbllouceng
            // 
            this.lbllouceng.AutoSize = true;
            this.lbllouceng.Location = new System.Drawing.Point(10,70 );
            this.lbllouceng.Name = "lbllouceng";
            this.lbllouceng.Size = new System.Drawing.Size(65, 12);
            this.lbllouceng.TabIndex = 5;
            this.lbllouceng.Text = "楼层：";
            // 
            // txtshoukeshijian
            // 
            this.txtlouceng.Location = new System.Drawing.Point(80, 70);
            this.txtlouceng.Name = "txtlouceng";
            this.txtlouceng.Size = new System.Drawing.Size(180, 21);
            this.txtlouceng.TabIndex = 6;
 
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(10, 100);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 23);
            this.btnSave.TabIndex = 7;
            this.btnSave.Text = "保存";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);

            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(50, 100);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(75, 23);
            this.btnClose.TabIndex = 8;
            this.btnClose.Text = "关闭";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // Frm_keshiAU
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(598, 255);
             this.Controls.Add(this.lblkeshibianhao);
            this.Controls.Add(this.txtkeshibianhao);
 this.Controls.Add(this.lblkeshimingcheng);
            this.Controls.Add(this.txtkeshimingcheng);
 this.Controls.Add(this.lbllouceng);
            this.Controls.Add(this.txtlouceng);

            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.btnSave);
this.Name = "Frm_keshiAU";
            this.Text = "keshi编辑";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblkeshibianhao;
        private System.Windows.Forms.TextBox txtkeshibianhao;
 private System.Windows.Forms.Label lblkeshimingcheng;
        private System.Windows.Forms.TextBox txtkeshimingcheng;
 private System.Windows.Forms.Label lbllouceng;
        private System.Windows.Forms.TextBox txtlouceng;

        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Button btnSave;

    }
       
} 