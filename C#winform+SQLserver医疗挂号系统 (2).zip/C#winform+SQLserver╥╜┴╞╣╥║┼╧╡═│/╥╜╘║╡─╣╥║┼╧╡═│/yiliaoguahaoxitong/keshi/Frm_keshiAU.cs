﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace guahaoxitong
{
    public partial class Frm_keshiAU : Form
    {
        public Frm_keshiAU()
        {
            InitializeComponent();
        }
        Model.keshi model = new Model.keshi();
        public Frm_keshiAU(int id):this()
        {
            model = new BLL.keshi().GetModel(id);
          txtkeshibianhao.Text = model.keshibianhao;
                                                      txtkeshimingcheng.Text = model.keshimingcheng;
                                                      txtlouceng.Text = model.louceng;
                                                      
           
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
           model.keshibianhao = txtkeshibianhao.Text;
                                                      model.keshimingcheng = txtkeshimingcheng.Text;
                                                      model.louceng = txtlouceng.Text;
                                                      
            if (model.id > 0)
            {
                new BLL.keshi().Update(model);
            }
            else {
                new BLL.keshi().Add(model);
            }
            MessageBox.Show("操作成功！");
            this.Close();
            return;
        }

        private void btnClose_Click(object sender, EventArgs e)
         {
            this.Close();
        }
    }
}