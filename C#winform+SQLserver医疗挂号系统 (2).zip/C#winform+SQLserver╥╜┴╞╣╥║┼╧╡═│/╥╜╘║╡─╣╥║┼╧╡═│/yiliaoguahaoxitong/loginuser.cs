﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace guahaoxitong
{
   public static class loginuser
    {
       public static Model.userinfo userinfo { get; set; }
    }
}
