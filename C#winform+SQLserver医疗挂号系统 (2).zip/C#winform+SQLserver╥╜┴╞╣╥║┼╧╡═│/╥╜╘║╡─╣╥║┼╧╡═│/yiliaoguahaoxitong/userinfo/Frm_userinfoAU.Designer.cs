﻿   namespace guahaoxitong
{
    partial class Frm_userinfoAU
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblusername = new System.Windows.Forms.Label();
            this.txtusername = new System.Windows.Forms.TextBox();
            this.lblpassword = new System.Windows.Forms.Label();
            this.txtpassword = new System.Windows.Forms.TextBox();
            this.lblsex = new System.Windows.Forms.Label();
            this.txtsex = new System.Windows.Forms.TextBox();
            this.lblname = new System.Windows.Forms.Label();
            this.txtname = new System.Windows.Forms.TextBox();
            this.lblbirthday = new System.Windows.Forms.Label();
            this.txtbirthday = new System.Windows.Forms.TextBox();
            this.lbltelephone = new System.Windows.Forms.Label();
            this.txttelephone = new System.Windows.Forms.TextBox();
            this.btnClose = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblusername
            // 
            this.lblusername.AutoSize = true;
            this.lblusername.Location = new System.Drawing.Point(79, 34);
            this.lblusername.Name = "lblusername";
            this.lblusername.Size = new System.Drawing.Size(53, 12);
            this.lblusername.TabIndex = 1;
            this.lblusername.Text = "用户名：";
            // 
            // txtusername
            // 
            this.txtusername.Location = new System.Drawing.Point(149, 28);
            this.txtusername.Name = "txtusername";
            this.txtusername.Size = new System.Drawing.Size(180, 21);
            this.txtusername.TabIndex = 2;
            // 
            // lblpassword
            // 
            this.lblpassword.AutoSize = true;
            this.lblpassword.Location = new System.Drawing.Point(91, 64);
            this.lblpassword.Name = "lblpassword";
            this.lblpassword.Size = new System.Drawing.Size(41, 12);
            this.lblpassword.TabIndex = 3;
            this.lblpassword.Text = "密码：";
            // 
            // txtpassword
            // 
            this.txtpassword.Location = new System.Drawing.Point(149, 58);
            this.txtpassword.Name = "txtpassword";
            this.txtpassword.Size = new System.Drawing.Size(180, 21);
            this.txtpassword.TabIndex = 4;
            // 
            // lblsex
            // 
            this.lblsex.AutoSize = true;
            this.lblsex.Location = new System.Drawing.Point(91, 94);
            this.lblsex.Name = "lblsex";
            this.lblsex.Size = new System.Drawing.Size(41, 12);
            this.lblsex.TabIndex = 5;
            this.lblsex.Text = "性别：";
            // 
            // txtsex
            // 
            this.txtsex.Location = new System.Drawing.Point(149, 88);
            this.txtsex.Name = "txtsex";
            this.txtsex.Size = new System.Drawing.Size(180, 21);
            this.txtsex.TabIndex = 6;
            // 
            // lblname
            // 
            this.lblname.AutoSize = true;
            this.lblname.Location = new System.Drawing.Point(91, 124);
            this.lblname.Name = "lblname";
            this.lblname.Size = new System.Drawing.Size(41, 12);
            this.lblname.TabIndex = 7;
            this.lblname.Text = "姓名：";
            // 
            // txtname
            // 
            this.txtname.Location = new System.Drawing.Point(149, 118);
            this.txtname.Name = "txtname";
            this.txtname.Size = new System.Drawing.Size(180, 21);
            this.txtname.TabIndex = 8;
            // 
            // lblbirthday
            // 
            this.lblbirthday.AutoSize = true;
            this.lblbirthday.Location = new System.Drawing.Point(67, 154);
            this.lblbirthday.Name = "lblbirthday";
            this.lblbirthday.Size = new System.Drawing.Size(65, 12);
            this.lblbirthday.TabIndex = 9;
            this.lblbirthday.Text = "出生年月：";
            // 
            // txtbirthday
            // 
            this.txtbirthday.Location = new System.Drawing.Point(149, 148);
            this.txtbirthday.Name = "txtbirthday";
            this.txtbirthday.Size = new System.Drawing.Size(180, 21);
            this.txtbirthday.TabIndex = 10;
            // 
            // lbltelephone
            // 
            this.lbltelephone.AutoSize = true;
            this.lbltelephone.Location = new System.Drawing.Point(91, 184);
            this.lbltelephone.Name = "lbltelephone";
            this.lbltelephone.Size = new System.Drawing.Size(41, 12);
            this.lbltelephone.TabIndex = 11;
            this.lbltelephone.Text = "电话：";
            // 
            // txttelephone
            // 
            this.txttelephone.Location = new System.Drawing.Point(149, 178);
            this.txttelephone.Name = "txttelephone";
            this.txttelephone.Size = new System.Drawing.Size(180, 21);
            this.txttelephone.TabIndex = 12;
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(254, 249);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(75, 23);
            this.btnClose.TabIndex = 16;
            this.btnClose.Text = "关闭";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(158, 249);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 23);
            this.btnSave.TabIndex = 15;
            this.btnSave.Text = "保存";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // Frm_userinfoAU
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(430, 326);
            this.Controls.Add(this.lblusername);
            this.Controls.Add(this.txtusername);
            this.Controls.Add(this.lblpassword);
            this.Controls.Add(this.txtpassword);
            this.Controls.Add(this.lblsex);
            this.Controls.Add(this.txtsex);
            this.Controls.Add(this.lblname);
            this.Controls.Add(this.txtname);
            this.Controls.Add(this.lblbirthday);
            this.Controls.Add(this.txtbirthday);
            this.Controls.Add(this.lbltelephone);
            this.Controls.Add(this.txttelephone);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.btnSave);
            this.Name = "Frm_userinfoAU";
            this.Text = "userinfo编辑";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblusername;
        private System.Windows.Forms.TextBox txtusername;
 private System.Windows.Forms.Label lblpassword;
        private System.Windows.Forms.TextBox txtpassword;
 private System.Windows.Forms.Label lblsex;
        private System.Windows.Forms.TextBox txtsex;
 private System.Windows.Forms.Label lblname;
        private System.Windows.Forms.TextBox txtname;
 private System.Windows.Forms.Label lblbirthday;
        private System.Windows.Forms.TextBox txtbirthday;
 private System.Windows.Forms.Label lbltelephone;
 private System.Windows.Forms.TextBox txttelephone;

        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Button btnSave;

    }
       
} 