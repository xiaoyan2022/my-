﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace guahaoxitong
{
    public partial class Frm_userinfoAU : Form
    {
        public Frm_userinfoAU()
        {
            InitializeComponent();
            model.role = "用户";
        }
        Model.userinfo model = new Model.userinfo();
        public Frm_userinfoAU(int id)
            : this()
        {
            model = new BLL.userinfo().GetModel(id);
            txtusername.Text = model.username;
            txtpassword.Text = model.password;
            txtsex.Text = model.sex;
            txtname.Text = model.name;
            txtbirthday.Text = model.birthday;
            txttelephone.Text = model.telephone;


        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            model.username = txtusername.Text;
            model.password = txtpassword.Text;
            model.sex = txtsex.Text;
            model.name = txtname.Text;
            model.birthday = txtbirthday.Text;
            model.telephone = txttelephone.Text;

            if (model.id > 0)
            {
                new BLL.userinfo().Update(model);
            }
            else
            {
                new BLL.userinfo().Add(model);
            }
            MessageBox.Show("操作成功！");
            this.Close();
            return;
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}