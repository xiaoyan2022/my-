﻿   namespace guahaoxitong
{
    partial class Frm_userinfoManager
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.编辑ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.添加ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.删除ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.刷新ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblusername = new System.Windows.Forms.Label();
            this.txtusername = new System.Windows.Forms.TextBox();
            this.lblsex = new System.Windows.Forms.Label();
            this.txtsex = new System.Windows.Forms.TextBox();
            this.btnsearch = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.lblname = new System.Windows.Forms.Label();
            this.txtname = new System.Windows.Forms.TextBox();
            this.lbltelephone = new System.Windows.Forms.Label();
            this.txttelephone = new System.Windows.Forms.TextBox();
            this.colid = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colusername = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colpassword = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colsex = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colname = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colbirthday = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.coltelephone = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colrole = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.menuStrip1.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // 编辑ToolStripMenuItem
            // 
            this.编辑ToolStripMenuItem.Name = "编辑ToolStripMenuItem";
            this.编辑ToolStripMenuItem.Size = new System.Drawing.Size(44, 21);
            this.编辑ToolStripMenuItem.Text = "编辑";
            this.编辑ToolStripMenuItem.Click += new System.EventHandler(this.编辑ToolStripMenuItem_Click);
            // 
            // 添加ToolStripMenuItem
            // 
            this.添加ToolStripMenuItem.Name = "添加ToolStripMenuItem";
            this.添加ToolStripMenuItem.Size = new System.Drawing.Size(44, 21);
            this.添加ToolStripMenuItem.Text = "添加";
            this.添加ToolStripMenuItem.Click += new System.EventHandler(this.添加ToolStripMenuItem_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.添加ToolStripMenuItem,
            this.编辑ToolStripMenuItem,
            this.删除ToolStripMenuItem,
            this.刷新ToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(775, 25);
            this.menuStrip1.TabIndex = 4;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // 删除ToolStripMenuItem
            // 
            this.删除ToolStripMenuItem.Name = "删除ToolStripMenuItem";
            this.删除ToolStripMenuItem.Size = new System.Drawing.Size(44, 21);
            this.删除ToolStripMenuItem.Text = "删除";
            this.删除ToolStripMenuItem.Click += new System.EventHandler(this.删除ToolStripMenuItem_Click);
            // 
            // 刷新ToolStripMenuItem
            // 
            this.刷新ToolStripMenuItem.Name = "刷新ToolStripMenuItem";
            this.刷新ToolStripMenuItem.Size = new System.Drawing.Size(44, 21);
            this.刷新ToolStripMenuItem.Text = "刷新";
            this.刷新ToolStripMenuItem.Click += new System.EventHandler(this.刷新ToolStripMenuItem_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.lblname);
            this.panel1.Controls.Add(this.txtname);
            this.panel1.Controls.Add(this.lbltelephone);
            this.panel1.Controls.Add(this.txttelephone);
            this.panel1.Controls.Add(this.lblusername);
            this.panel1.Controls.Add(this.txtusername);
            this.panel1.Controls.Add(this.lblsex);
            this.panel1.Controls.Add(this.txtsex);
            this.panel1.Controls.Add(this.btnsearch);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 25);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(775, 35);
            this.panel1.TabIndex = 6;
            // 
            // lblusername
            // 
            this.lblusername.AutoSize = true;
            this.lblusername.Location = new System.Drawing.Point(8, 11);
            this.lblusername.Name = "lblusername";
            this.lblusername.Size = new System.Drawing.Size(53, 12);
            this.lblusername.TabIndex = 3;
            this.lblusername.Text = "用户名：";
            // 
            // txtusername
            // 
            this.txtusername.Location = new System.Drawing.Point(67, 7);
            this.txtusername.Name = "txtusername";
            this.txtusername.Size = new System.Drawing.Size(100, 21);
            this.txtusername.TabIndex = 4;
            // 
            // lblsex
            // 
            this.lblsex.AutoSize = true;
            this.lblsex.Location = new System.Drawing.Point(182, 11);
            this.lblsex.Name = "lblsex";
            this.lblsex.Size = new System.Drawing.Size(41, 12);
            this.lblsex.TabIndex = 7;
            this.lblsex.Text = "性别：";
            // 
            // txtsex
            // 
            this.txtsex.Location = new System.Drawing.Point(229, 7);
            this.txtsex.Name = "txtsex";
            this.txtsex.Size = new System.Drawing.Size(100, 21);
            this.txtsex.TabIndex = 8;
            // 
            // btnsearch
            // 
            this.btnsearch.Location = new System.Drawing.Point(666, 6);
            this.btnsearch.Name = "btnsearch";
            this.btnsearch.Size = new System.Drawing.Size(75, 23);
            this.btnsearch.TabIndex = 17;
            this.btnsearch.Text = "查询";
            this.btnsearch.Click += new System.EventHandler(this.btnsearch_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colid,
            this.colusername,
            this.colpassword,
            this.colsex,
            this.colname,
            this.colbirthday,
            this.coltelephone,
            this.colrole});
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView1.Location = new System.Drawing.Point(0, 60);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.Size = new System.Drawing.Size(775, 195);
            this.dataGridView1.TabIndex = 0;
            // 
            // lblname
            // 
            this.lblname.AutoSize = true;
            this.lblname.Location = new System.Drawing.Point(343, 11);
            this.lblname.Name = "lblname";
            this.lblname.Size = new System.Drawing.Size(41, 12);
            this.lblname.TabIndex = 18;
            this.lblname.Text = "姓名：";
            // 
            // txtname
            // 
            this.txtname.Location = new System.Drawing.Point(384, 7);
            this.txtname.Name = "txtname";
            this.txtname.Size = new System.Drawing.Size(100, 21);
            this.txtname.TabIndex = 19;
            // 
            // lbltelephone
            // 
            this.lbltelephone.AutoSize = true;
            this.lbltelephone.Location = new System.Drawing.Point(490, 11);
            this.lbltelephone.Name = "lbltelephone";
            this.lbltelephone.Size = new System.Drawing.Size(41, 12);
            this.lbltelephone.TabIndex = 20;
            this.lbltelephone.Text = "电话：";
            // 
            // txttelephone
            // 
            this.txttelephone.Location = new System.Drawing.Point(537, 7);
            this.txttelephone.Name = "txttelephone";
            this.txttelephone.Size = new System.Drawing.Size(100, 21);
            this.txttelephone.TabIndex = 21;
            // 
            // colid
            // 
            this.colid.DataPropertyName = "id";
            this.colid.HeaderText = "id";
            this.colid.Name = "colid";
            this.colid.ReadOnly = true;
            this.colid.Visible = false;
            // 
            // colusername
            // 
            this.colusername.DataPropertyName = "username";
            this.colusername.HeaderText = "用户名";
            this.colusername.Name = "colusername";
            this.colusername.ReadOnly = true;
            // 
            // colpassword
            // 
            this.colpassword.DataPropertyName = "password";
            this.colpassword.HeaderText = "密码";
            this.colpassword.Name = "colpassword";
            this.colpassword.ReadOnly = true;
            // 
            // colsex
            // 
            this.colsex.DataPropertyName = "sex";
            this.colsex.HeaderText = "性别";
            this.colsex.Name = "colsex";
            this.colsex.ReadOnly = true;
            // 
            // colname
            // 
            this.colname.DataPropertyName = "name";
            this.colname.HeaderText = "姓名";
            this.colname.Name = "colname";
            this.colname.ReadOnly = true;
            // 
            // colbirthday
            // 
            this.colbirthday.DataPropertyName = "birthday";
            this.colbirthday.HeaderText = "出生年月";
            this.colbirthday.Name = "colbirthday";
            this.colbirthday.ReadOnly = true;
            // 
            // coltelephone
            // 
            this.coltelephone.DataPropertyName = "telephone";
            this.coltelephone.HeaderText = "电话";
            this.coltelephone.Name = "coltelephone";
            this.coltelephone.ReadOnly = true;
            // 
            // colrole
            // 
            this.colrole.DataPropertyName = "role";
            this.colrole.HeaderText = "角色";
            this.colrole.Name = "colrole";
            this.colrole.ReadOnly = true;
            // 
            // Frm_userinfoManager
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(775, 255);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.menuStrip1);
            this.Name = "Frm_userinfoManager";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStripMenuItem 编辑ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 添加ToolStripMenuItem;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem 删除ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 刷新ToolStripMenuItem;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button btnsearch;
 private System.Windows.Forms.Label lblusername;
 private System.Windows.Forms.TextBox txtusername;
 private System.Windows.Forms.Label lblsex;
 private System.Windows.Forms.TextBox txtsex;
        private System.Windows.Forms.Label lblname;
        private System.Windows.Forms.TextBox txtname;
        private System.Windows.Forms.Label lbltelephone;
        private System.Windows.Forms.TextBox txttelephone;
        private System.Windows.Forms.DataGridViewTextBoxColumn colid;
        private System.Windows.Forms.DataGridViewTextBoxColumn colusername;
        private System.Windows.Forms.DataGridViewTextBoxColumn colpassword;
        private System.Windows.Forms.DataGridViewTextBoxColumn colsex;
        private System.Windows.Forms.DataGridViewTextBoxColumn colname;
        private System.Windows.Forms.DataGridViewTextBoxColumn colbirthday;
        private System.Windows.Forms.DataGridViewTextBoxColumn coltelephone;
        private System.Windows.Forms.DataGridViewTextBoxColumn colrole;

    }
       
} 