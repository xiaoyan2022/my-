﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace guahaoxitong
{
    public partial class Frm_userinfoManager : Form
    {
        public Frm_userinfoManager(bool tag = true)
        {
            InitializeComponent();
            if (!tag) {
                menuStrip1.Visible = false;
            }
            dataGridView1.AutoGenerateColumns = false;
            dataGridView1.DataSource = new BLL.userinfo().GetList("role='病人'").Tables[0];
            
        }

        private void 添加ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Frm_userinfoAU frm = new Frm_userinfoAU();
            frm.ShowDialog();
        }

        private void 编辑ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count <= 0) {
                MessageBox.Show("请选择一条数据进行编辑");
                return;
            }
            Frm_userinfoAU frm = new Frm_userinfoAU(Convert.ToInt32(dataGridView1.SelectedRows[0].Cells["colid"].Value));
            frm.ShowDialog();
        }

        private void 删除ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count <= 0)
            {
                MessageBox.Show("请选择数据进行删除");
                return;
            }
           var ids = "";



           //获取选中行

           //int index = dataGridView1.CurrentRow.Index;    //取得选中行的索引 
           // ids = dataGridView1.Rows[index].Cells[0].Value.ToString();   //获取单元格列名为‘Id’的值



           foreach (DataGridViewRow item in dataGridView1.SelectedRows)
           {

               ids += item.Cells[0].Value + ",";
           }
            if (MessageBox.Show("确定要删除选中的数据", "系统提示", MessageBoxButtons.YesNo) == System.Windows.Forms.DialogResult.Yes)
            {
               
                if (new BLL.userinfo().DeleteList(ids.TrimEnd(',')))
                {
                    MessageBox.Show("删除成功！");
                    return;
                }
                else {
                    MessageBox.Show("删除失败！");
                    return;
                }
            }
        }

        private void 刷新ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            dataGridView1.AutoGenerateColumns = false;
            dataGridView1.DataSource = new BLL.userinfo().GetList("").Tables[0];

        }
        private void btnsearch_Click(object sender, EventArgs e)
        {
            var where = "1=1";
           if (!string.IsNullOrEmpty(txtusername.Text)) {
                where += string.Format(" and username like '%{0}%'", txtusername.Text);
            } if (!string.IsNullOrEmpty(txtsex.Text)) {
                where += string.Format(" and sex like '%{0}%'", txtsex.Text);
            }if (!string.IsNullOrEmpty(txtname.Text)) {
                where += string.Format(" and name like '%{0}%'", txtname.Text);
            } if (!string.IsNullOrEmpty(txttelephone.Text)) {
                where += string.Format(" and telephone like '%{0}%'", txttelephone.Text);
            } 
            dataGridView1.DataSource = new BLL.userinfo().GetList(where).Tables[0];
            dataGridView1.Refresh();
        }

        

        
    }
}