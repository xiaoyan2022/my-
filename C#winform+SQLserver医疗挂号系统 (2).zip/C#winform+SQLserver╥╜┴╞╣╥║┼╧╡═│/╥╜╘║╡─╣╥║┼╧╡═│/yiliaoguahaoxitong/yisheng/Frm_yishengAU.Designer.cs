﻿   namespace guahaoxitong
{
    partial class Frm_yishengAU
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblgonghao = new System.Windows.Forms.Label();
            this.txtgonghao = new System.Windows.Forms.TextBox();
            this.lblxingming = new System.Windows.Forms.Label();
            this.txtxingming = new System.Windows.Forms.TextBox();
            this.lblzhiwei = new System.Windows.Forms.Label();
            this.txtzhiwei = new System.Windows.Forms.TextBox();
            this.lbljianjie = new System.Windows.Forms.Label();
            this.txtjianjie = new System.Windows.Forms.TextBox();
            this.lblkeshi = new System.Windows.Forms.Label();
            this.txtkeshi = new System.Windows.Forms.TextBox();
            this.lblguahaofei = new System.Windows.Forms.Label();
            this.txtguahaofei = new System.Windows.Forms.TextBox();
            this.btnClose = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblgonghao
            // 
            this.lblgonghao.AutoSize = true;
            this.lblgonghao.Location = new System.Drawing.Point(56, 39);
            this.lblgonghao.Name = "lblgonghao";
            this.lblgonghao.Size = new System.Drawing.Size(41, 12);
            this.lblgonghao.TabIndex = 1;
            this.lblgonghao.Text = "工号：";
            // 
            // txtgonghao
            // 
            this.txtgonghao.Location = new System.Drawing.Point(126, 34);
            this.txtgonghao.Name = "txtgonghao";
            this.txtgonghao.Size = new System.Drawing.Size(180, 21);
            this.txtgonghao.TabIndex = 2;
            // 
            // lblxingming
            // 
            this.lblxingming.AutoSize = true;
            this.lblxingming.Location = new System.Drawing.Point(56, 69);
            this.lblxingming.Name = "lblxingming";
            this.lblxingming.Size = new System.Drawing.Size(41, 12);
            this.lblxingming.TabIndex = 3;
            this.lblxingming.Text = "姓名：";
            // 
            // txtxingming
            // 
            this.txtxingming.Location = new System.Drawing.Point(126, 64);
            this.txtxingming.Name = "txtxingming";
            this.txtxingming.Size = new System.Drawing.Size(180, 21);
            this.txtxingming.TabIndex = 4;
            // 
            // lblzhiwei
            // 
            this.lblzhiwei.AutoSize = true;
            this.lblzhiwei.Location = new System.Drawing.Point(56, 99);
            this.lblzhiwei.Name = "lblzhiwei";
            this.lblzhiwei.Size = new System.Drawing.Size(41, 12);
            this.lblzhiwei.TabIndex = 5;
            this.lblzhiwei.Text = "职位：";
            // 
            // txtzhiwei
            // 
            this.txtzhiwei.Location = new System.Drawing.Point(126, 94);
            this.txtzhiwei.Name = "txtzhiwei";
            this.txtzhiwei.Size = new System.Drawing.Size(180, 21);
            this.txtzhiwei.TabIndex = 6;
            // 
            // lbljianjie
            // 
            this.lbljianjie.AutoSize = true;
            this.lbljianjie.Location = new System.Drawing.Point(56, 129);
            this.lbljianjie.Name = "lbljianjie";
            this.lbljianjie.Size = new System.Drawing.Size(41, 12);
            this.lbljianjie.TabIndex = 7;
            this.lbljianjie.Text = "简介：";
            // 
            // txtjianjie
            // 
            this.txtjianjie.Location = new System.Drawing.Point(126, 124);
            this.txtjianjie.Name = "txtjianjie";
            this.txtjianjie.Size = new System.Drawing.Size(180, 21);
            this.txtjianjie.TabIndex = 8;
            // 
            // lblkeshi
            // 
            this.lblkeshi.AutoSize = true;
            this.lblkeshi.Location = new System.Drawing.Point(56, 159);
            this.lblkeshi.Name = "lblkeshi";
            this.lblkeshi.Size = new System.Drawing.Size(41, 12);
            this.lblkeshi.TabIndex = 9;
            this.lblkeshi.Text = "科室：";
            // 
            // txtkeshi
            // 
            this.txtkeshi.Location = new System.Drawing.Point(126, 154);
            this.txtkeshi.Name = "txtkeshi";
            this.txtkeshi.Size = new System.Drawing.Size(180, 21);
            this.txtkeshi.TabIndex = 10;
            // 
            // lblguahaofei
            // 
            this.lblguahaofei.AutoSize = true;
            this.lblguahaofei.Location = new System.Drawing.Point(56, 189);
            this.lblguahaofei.Name = "lblguahaofei";
            this.lblguahaofei.Size = new System.Drawing.Size(53, 12);
            this.lblguahaofei.TabIndex = 11;
            this.lblguahaofei.Text = "挂号费：";
            // 
            // txtguahaofei
            // 
            this.txtguahaofei.Location = new System.Drawing.Point(126, 184);
            this.txtguahaofei.Name = "txtguahaofei";
            this.txtguahaofei.Size = new System.Drawing.Size(180, 21);
            this.txtguahaofei.TabIndex = 12;
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(231, 226);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(75, 23);
            this.btnClose.TabIndex = 14;
            this.btnClose.Text = "关闭";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(126, 226);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 23);
            this.btnSave.TabIndex = 13;
            this.btnSave.Text = "保存";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // Frm_yishengAU
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(364, 295);
            this.Controls.Add(this.lblgonghao);
            this.Controls.Add(this.txtgonghao);
            this.Controls.Add(this.lblxingming);
            this.Controls.Add(this.txtxingming);
            this.Controls.Add(this.lblzhiwei);
            this.Controls.Add(this.txtzhiwei);
            this.Controls.Add(this.lbljianjie);
            this.Controls.Add(this.txtjianjie);
            this.Controls.Add(this.lblkeshi);
            this.Controls.Add(this.txtkeshi);
            this.Controls.Add(this.lblguahaofei);
            this.Controls.Add(this.txtguahaofei);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.btnSave);
            this.Name = "Frm_yishengAU";
            this.Text = "yisheng编辑";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblgonghao;
        private System.Windows.Forms.TextBox txtgonghao;
 private System.Windows.Forms.Label lblxingming;
        private System.Windows.Forms.TextBox txtxingming;
 private System.Windows.Forms.Label lblzhiwei;
        private System.Windows.Forms.TextBox txtzhiwei;
 private System.Windows.Forms.Label lbljianjie;
        private System.Windows.Forms.TextBox txtjianjie;
 private System.Windows.Forms.Label lblkeshi;
        private System.Windows.Forms.TextBox txtkeshi;
 private System.Windows.Forms.Label lblguahaofei;
        private System.Windows.Forms.TextBox txtguahaofei;

        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Button btnSave;

    }
       
} 