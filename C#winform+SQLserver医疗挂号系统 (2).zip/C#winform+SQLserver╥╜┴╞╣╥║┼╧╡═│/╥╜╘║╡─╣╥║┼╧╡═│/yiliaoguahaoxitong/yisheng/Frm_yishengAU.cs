﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace guahaoxitong
{
    public partial class Frm_yishengAU : Form
    {
        public Frm_yishengAU()
        {
            InitializeComponent();
        }
        Model.yisheng model = new Model.yisheng();
        public Frm_yishengAU(int id)
            : this()
        {
            model = new BLL.yisheng().GetModel(id);
            txtgonghao.Text = model.gonghao;
            txtxingming.Text = model.xingming;
            txtzhiwei.Text = model.zhiwei;
            txtjianjie.Text = model.jianjie;
            txtkeshi.Text = model.keshi.ToString();
            txtguahaofei.Text = model.guahaofei.ToString();


        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            model.gonghao = txtgonghao.Text;
            model.xingming = txtxingming.Text;
            model.zhiwei = txtzhiwei.Text;
            model.jianjie = txtjianjie.Text;
            model.keshi = Convert.ToInt32(txtkeshi.Text);
            model.guahaofei = Convert.ToDecimal(txtguahaofei.Text);

            if (model.id > 0)
            {
                new BLL.yisheng().Update(model);
            }
            else
            {
                new BLL.yisheng().Add(model);
            }
            MessageBox.Show("操作成功！");
            this.Close();
            return;
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}