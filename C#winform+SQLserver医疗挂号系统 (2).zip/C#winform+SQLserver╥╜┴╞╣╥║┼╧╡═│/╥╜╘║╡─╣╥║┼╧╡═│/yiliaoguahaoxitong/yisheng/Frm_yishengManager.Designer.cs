﻿   namespace guahaoxitong
{
    partial class Frm_yishengManager
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.编辑ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.添加ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.删除ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.刷新ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblxingming = new System.Windows.Forms.Label();
            this.txtxingming = new System.Windows.Forms.TextBox();
            this.lblzhiwei = new System.Windows.Forms.Label();
            this.txtzhiwei = new System.Windows.Forms.TextBox();
            this.lblkeshi = new System.Windows.Forms.Label();
            this.txtkeshi = new System.Windows.Forms.TextBox();
            this.btnsearch = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.colid = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colgonghao = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colxingming = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colzhiwei = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.coljianjie = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colkeshi = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colguahaofei = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.menuStrip1.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // 编辑ToolStripMenuItem
            // 
            this.编辑ToolStripMenuItem.Name = "编辑ToolStripMenuItem";
            this.编辑ToolStripMenuItem.Size = new System.Drawing.Size(44, 21);
            this.编辑ToolStripMenuItem.Text = "编辑";
            this.编辑ToolStripMenuItem.Click += new System.EventHandler(this.编辑ToolStripMenuItem_Click);
            // 
            // 添加ToolStripMenuItem
            // 
            this.添加ToolStripMenuItem.Name = "添加ToolStripMenuItem";
            this.添加ToolStripMenuItem.Size = new System.Drawing.Size(44, 21);
            this.添加ToolStripMenuItem.Text = "添加";
            this.添加ToolStripMenuItem.Click += new System.EventHandler(this.添加ToolStripMenuItem_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.添加ToolStripMenuItem,
            this.编辑ToolStripMenuItem,
            this.删除ToolStripMenuItem,
            this.刷新ToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(655, 25);
            this.menuStrip1.TabIndex = 4;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // 删除ToolStripMenuItem
            // 
            this.删除ToolStripMenuItem.Name = "删除ToolStripMenuItem";
            this.删除ToolStripMenuItem.Size = new System.Drawing.Size(44, 21);
            this.删除ToolStripMenuItem.Text = "删除";
            this.删除ToolStripMenuItem.Click += new System.EventHandler(this.删除ToolStripMenuItem_Click);
            // 
            // 刷新ToolStripMenuItem
            // 
            this.刷新ToolStripMenuItem.Name = "刷新ToolStripMenuItem";
            this.刷新ToolStripMenuItem.Size = new System.Drawing.Size(44, 21);
            this.刷新ToolStripMenuItem.Text = "刷新";
            this.刷新ToolStripMenuItem.Click += new System.EventHandler(this.刷新ToolStripMenuItem_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.lblxingming);
            this.panel1.Controls.Add(this.txtxingming);
            this.panel1.Controls.Add(this.lblzhiwei);
            this.panel1.Controls.Add(this.txtzhiwei);
            this.panel1.Controls.Add(this.lblkeshi);
            this.panel1.Controls.Add(this.txtkeshi);
            this.panel1.Controls.Add(this.btnsearch);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 25);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(655, 35);
            this.panel1.TabIndex = 6;
            // 
            // lblxingming
            // 
            this.lblxingming.AutoSize = true;
            this.lblxingming.Location = new System.Drawing.Point(25, 11);
            this.lblxingming.Name = "lblxingming";
            this.lblxingming.Size = new System.Drawing.Size(41, 12);
            this.lblxingming.TabIndex = 5;
            this.lblxingming.Text = "姓名：";
            // 
            // txtxingming
            // 
            this.txtxingming.Location = new System.Drawing.Point(72, 7);
            this.txtxingming.Name = "txtxingming";
            this.txtxingming.Size = new System.Drawing.Size(100, 21);
            this.txtxingming.TabIndex = 6;
            // 
            // lblzhiwei
            // 
            this.lblzhiwei.AutoSize = true;
            this.lblzhiwei.Location = new System.Drawing.Point(177, 11);
            this.lblzhiwei.Name = "lblzhiwei";
            this.lblzhiwei.Size = new System.Drawing.Size(41, 12);
            this.lblzhiwei.TabIndex = 7;
            this.lblzhiwei.Text = "职位：";
            // 
            // txtzhiwei
            // 
            this.txtzhiwei.Location = new System.Drawing.Point(224, 7);
            this.txtzhiwei.Name = "txtzhiwei";
            this.txtzhiwei.Size = new System.Drawing.Size(100, 21);
            this.txtzhiwei.TabIndex = 8;
            // 
            // lblkeshi
            // 
            this.lblkeshi.AutoSize = true;
            this.lblkeshi.Location = new System.Drawing.Point(330, 11);
            this.lblkeshi.Name = "lblkeshi";
            this.lblkeshi.Size = new System.Drawing.Size(41, 12);
            this.lblkeshi.TabIndex = 11;
            this.lblkeshi.Text = "科室：";
            // 
            // txtkeshi
            // 
            this.txtkeshi.Location = new System.Drawing.Point(377, 7);
            this.txtkeshi.Name = "txtkeshi";
            this.txtkeshi.Size = new System.Drawing.Size(100, 21);
            this.txtkeshi.TabIndex = 12;
            // 
            // btnsearch
            // 
            this.btnsearch.Location = new System.Drawing.Point(500, 6);
            this.btnsearch.Name = "btnsearch";
            this.btnsearch.Size = new System.Drawing.Size(75, 23);
            this.btnsearch.TabIndex = 17;
            this.btnsearch.Text = "查询";
            this.btnsearch.Click += new System.EventHandler(this.btnsearch_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colid,
            this.colgonghao,
            this.colxingming,
            this.colzhiwei,
            this.coljianjie,
            this.colkeshi,
            this.colguahaofei});
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView1.Location = new System.Drawing.Point(0, 60);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.Size = new System.Drawing.Size(655, 332);
            this.dataGridView1.TabIndex = 0;
            // 
            // colid
            // 
            this.colid.DataPropertyName = "id";
            this.colid.HeaderText = "id";
            this.colid.Name = "colid";
            this.colid.ReadOnly = true;
            this.colid.Visible = false;
            // 
            // colgonghao
            // 
            this.colgonghao.DataPropertyName = "gonghao";
            this.colgonghao.HeaderText = "工号";
            this.colgonghao.Name = "colgonghao";
            this.colgonghao.ReadOnly = true;
            // 
            // colxingming
            // 
            this.colxingming.DataPropertyName = "xingming";
            this.colxingming.HeaderText = "姓名";
            this.colxingming.Name = "colxingming";
            this.colxingming.ReadOnly = true;
            // 
            // colzhiwei
            // 
            this.colzhiwei.DataPropertyName = "zhiwei";
            this.colzhiwei.HeaderText = "职位";
            this.colzhiwei.Name = "colzhiwei";
            this.colzhiwei.ReadOnly = true;
            // 
            // coljianjie
            // 
            this.coljianjie.DataPropertyName = "jianjie";
            this.coljianjie.HeaderText = "简介";
            this.coljianjie.Name = "coljianjie";
            this.coljianjie.ReadOnly = true;
            // 
            // colkeshi
            // 
            this.colkeshi.DataPropertyName = "keshi";
            this.colkeshi.HeaderText = "科室";
            this.colkeshi.Name = "colkeshi";
            this.colkeshi.ReadOnly = true;
            // 
            // colguahaofei
            // 
            this.colguahaofei.DataPropertyName = "guahaofei";
            this.colguahaofei.HeaderText = "挂号费";
            this.colguahaofei.Name = "colguahaofei";
            this.colguahaofei.ReadOnly = true;
            // 
            // Frm_yishengManager
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(655, 392);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.menuStrip1);
            this.Name = "Frm_yishengManager";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStripMenuItem 编辑ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 添加ToolStripMenuItem;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem 删除ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 刷新ToolStripMenuItem;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button btnsearch;
 private System.Windows.Forms.Label lblxingming;
 private System.Windows.Forms.TextBox txtxingming;
 private System.Windows.Forms.Label lblzhiwei;
 private System.Windows.Forms.TextBox txtzhiwei;
 private System.Windows.Forms.Label lblkeshi;
 private System.Windows.Forms.TextBox txtkeshi;
 private System.Windows.Forms.DataGridViewTextBoxColumn colid;
 private System.Windows.Forms.DataGridViewTextBoxColumn colgonghao;
 private System.Windows.Forms.DataGridViewTextBoxColumn colxingming;
 private System.Windows.Forms.DataGridViewTextBoxColumn colzhiwei;
 private System.Windows.Forms.DataGridViewTextBoxColumn coljianjie;
 private System.Windows.Forms.DataGridViewTextBoxColumn colkeshi;
 private System.Windows.Forms.DataGridViewTextBoxColumn colguahaofei;

    }
       
} 