﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace guahaoxitong
{
    public partial class Frm_yishengManager : Form
    {
        public Frm_yishengManager(bool tag = true)
        {
            InitializeComponent();
            if (!tag) {
                menuStrip1.Visible = false;
            }
            dataGridView1.AutoGenerateColumns = false;
            dataGridView1.DataSource = new BLL.yisheng().GetList("").Tables[0];
            
        }

        private void 添加ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Frm_yishengAU frm = new Frm_yishengAU();
            frm.ShowDialog();
        }

        private void 编辑ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count <= 0) {
                MessageBox.Show("请选择一条数据进行编辑");
                return;
            }
            Frm_yishengAU frm = new Frm_yishengAU(Convert.ToInt32(dataGridView1.SelectedRows[0].Cells["colid"].Value));
            frm.ShowDialog();
        }

        private void 删除ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count <= 0)
            {
                MessageBox.Show("请选择数据进行删除");
                return;
            }
           var ids = "";
                foreach (DataGridViewRow item in dataGridView1.SelectedRows)
                {
                   
                    ids += item.Cells[0].Value + ",";
                }
            if (MessageBox.Show("确定要删除选中的数据", "系统提示", MessageBoxButtons.YesNo) == System.Windows.Forms.DialogResult.Yes)
            {
               
                if (new BLL.yisheng().DeleteList(ids.TrimEnd(',')))
                {
                    MessageBox.Show("删除成功！");
                    return;
                }
                else {
                    MessageBox.Show("删除失败！");
                    return;
                }
            }
        }

        private void 刷新ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            dataGridView1.AutoGenerateColumns = false;
            dataGridView1.DataSource = new BLL.yisheng().GetList("").Tables[0];

        }
        private void btnsearch_Click(object sender, EventArgs e)
        {
            var where = "1=1";
            if (!string.IsNullOrEmpty(txtxingming.Text)) {
                where += string.Format(" and xingming like '%{0}%'", txtxingming.Text);
            }if (!string.IsNullOrEmpty(txtzhiwei.Text)) {
                where += string.Format(" and zhiwei like '%{0}%'", txtzhiwei.Text);
            } if (!string.IsNullOrEmpty(txtkeshi.Text)) {
                where += string.Format(" and keshi like '%{0}%'", txtkeshi.Text);
            }
            dataGridView1.DataSource = new BLL.yisheng().GetList(where).Tables[0];
            dataGridView1.Refresh();
        }

        

        
    }
}