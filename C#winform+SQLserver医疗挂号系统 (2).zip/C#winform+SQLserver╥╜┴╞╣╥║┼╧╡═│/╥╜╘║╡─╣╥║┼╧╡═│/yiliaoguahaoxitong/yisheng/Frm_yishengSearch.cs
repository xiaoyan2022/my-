﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace guahaoxitong
{
    public partial class Frm_yishengSearch : Form
    {
        public Frm_yishengSearch()
        {
            InitializeComponent();
        }

        private void btnsearch_Click(object sender, EventArgs e)
        {
            var where = "1=1";
            if (!string.IsNullOrEmpty(txtxingming.Text))
            {
                where += string.Format(" and xingming like '%{0}%'", txtxingming.Text);
            } if (!string.IsNullOrEmpty(txtzhiwei.Text))
            {
                where += string.Format(" and zhiwei like '%{0}%'", txtzhiwei.Text);
            } if (!string.IsNullOrEmpty(txtkeshi.Text))
            {
                where += string.Format(" and keshi like '%{0}%'", txtkeshi.Text);
            }
            dataGridView1.DataSource = new BLL.yisheng().GetList(where).Tables[0];
            dataGridView1.Refresh();
        }
        /// <summary>
        /// 挂号
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button1_Click(object sender, EventArgs e)
        {
             if (dataGridView1.SelectedRows.Count <= 0) {
                MessageBox.Show("请选择一条数据进行编辑");
                return;
            }
            var guahao = new Model.guahao();
            guahao.guahaoshijian = DateTime.Now;
            guahao.userid = loginuser.userinfo.id;
            guahao.yishengid = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells["colid"].Value);
            guahao.zhuangtai = "已挂号";
            new BLL.guahao().Add(guahao);
            MessageBox.Show("挂号成功！");
        }
    }
}
