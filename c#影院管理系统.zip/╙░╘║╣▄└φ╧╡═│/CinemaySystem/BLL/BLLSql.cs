﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using CinemaySystem.Model;
using Ctd.Comm;
using System.Data;

using Dapper;

namespace CinemaySystem.BLL
{
    class BLLSql
    {
        public static int AddMAdmin(MAdmin mod)
        {
            using (IDbConnection connection = new SqlConnDb().GetSqlConnection())
            {
                string sql = string.Format(@"insert into AdminTB (UserName,Psw)  values(@UserName,@Psw)");
                int ret = connection.Execute(sql, mod);
                if (ret != 1)
                {
                    throw new Exception("新增影响条数为0");
                }

                return ret;
            }
        }

        public static int AlterMAdmin(MAdmin mod)
        {
            using (IDbConnection connection = new SqlConnDb().GetSqlConnection())
            {
                //string sql = string.Format(@"update AdminTB set UserName=@UserName,Psw=@Psw where UserID=@UserID");
                string sql = string.Format(@"update AdminTB set Psw=@Psw where UserName=@UserName");
                int ret = connection.Execute(sql, mod);
                if (ret != 1)
                {
                    throw new Exception("新增影响条数为0");
                }

                return ret;
            }
        }

        public static int DeleteMAdmin(MAdmin mod)
        {
            using (IDbConnection connection = new SqlConnDb().GetSqlConnection())
            {
                //string sql = string.Format(@"delete from  AdminTB where UserID=@UserID");
                string sql = string.Format(@"delete from  AdminTB where UserName=@UserName");
                int ret = connection.Execute(sql, mod);
                if (ret != 1)
                {
                    throw new Exception("新增影响条数为0");
                }

                return ret;
            }
        }

        public static DataTable QueryByTbName(string tbName)
        {
            using (SqlConnDb sqlDb = new SqlConnDb())
            {
                return sqlDb.ExecuteDataTable(string.Format("select * from [{0}]", tbName));
            }
        }

        public static int AddMMember(MMember mod)
        {
            using (IDbConnection connection = new SqlConnDb().GetSqlConnection())
            {
                string sql = string.Format(@"insert into MemberTB (Phone,Psw)  values(@Phone,@Psw)");
                int ret = connection.Execute(sql, mod);
                if (ret != 1)
                {
                    throw new Exception("新增影响条数为0");
                }

                return ret;
            }
        }

        public static int AlterMMember(MMember mod)
        {
            using (IDbConnection connection = new SqlConnDb().GetSqlConnection())
            {
                //string sql = string.Format(@"update AdminTB set UserName=@UserName,Psw=@Psw where UserID=@UserID");
                string sql = string.Format(@"update MemberTB set Psw=@Psw where Phone=@Phone");
                int ret = connection.Execute(sql, mod);
                if (ret != 1)
                {
                    throw new Exception("新增影响条数为0");
                }

                return ret;
            }
        }

        public static int DeleteMMember(MMember mod)
        {
            using (IDbConnection connection = new SqlConnDb().GetSqlConnection())
            {
                //string sql = string.Format(@"delete from  AdminTB where UserID=@UserID");
                string sql = string.Format(@"delete from  MemberTB where Phone=@Phone");
                int ret = connection.Execute(sql, mod);
                if (ret != 1)
                {
                    throw new Exception("新增影响条数为0");
                }

                return ret;
            }
        }



        public static int AddMMovie(MMovie mod)
        {
            using (IDbConnection connection = new SqlConnDb().GetSqlConnection())
            {
                string sql = string.Format(@"insert into MovieTB (FilmName,Director,FilmType,FileImageName,Score
                                    )  values(@FilmName,@Director,@FilmType,@FileImageName,@Score)");
                int ret = connection.Execute(sql, mod);
                if (ret != 1)
                {
                    throw new Exception("新增影响条数为0");
                }

                return ret;
            }
        }

        public static int AlterMMovie(MMovie mod)
        {
            using (IDbConnection connection = new SqlConnDb().GetSqlConnection())
            {
                    string sql = string.Format(@"update MovieTB set Director=@Director,
                                                        FilmType=@FilmType,FileImageName=FileImageName,
                                                    Score=@Score
                                            where FilmName=@FilmName");
                int ret = connection.Execute(sql, mod);
                if (ret != 1)
                {
                    throw new Exception("新增影响条数为0");
                }

                return ret;
            }
        }

        public static int DeleteMMovie(MMovie mod)
        {
            using (IDbConnection connection = new SqlConnDb().GetSqlConnection())
            {
                string sql = string.Format(@"delete from  MovieTB where FilmName=@FilmName");
                int ret = connection.Execute(sql, mod);
                if (ret != 1)
                {
                    throw new Exception("新增影响条数为0");
                }

                return ret;
            }
        }

        public static int AddMCinema(MCinema mod)
        {
            using (IDbConnection connection = new SqlConnDb().GetSqlConnection())
            {
                string sql = string.Format(@"insert into CinemaTB (CinemaName,CinemaPosition,Phone
                                    )  values(@CinemaName,@CinemaPosition,@Phone)");
                int ret = connection.Execute(sql, mod);
                if (ret != 1)
                {
                    throw new Exception("新增影响条数为0");
                }

                return ret;
            }
        }

        public static int AlterMCinema(MCinema mod)
        {
            using (IDbConnection connection = new SqlConnDb().GetSqlConnection())
            {
                string sql = string.Format(@"update CinemaTB set CinemaPosition=@CinemaPosition,
                                                        Phone=@Phone
                                            where CinemaName=@CinemaName");
                int ret = connection.Execute(sql, mod);
                if (ret != 1)
                {
                    throw new Exception("新增影响条数为0");
                }

                return ret;
            }
        }

        public static int DeleteMCinema(MCinema mod)
        {
            using (IDbConnection connection = new SqlConnDb().GetSqlConnection())
            {
                string sql = string.Format(@"delete from  CinemaTB where CinemaName=@CinemaName");
                int ret = connection.Execute(sql, mod);
                if (ret != 1)
                {
                    throw new Exception("新增影响条数为0");
                }

                return ret;
            }
        }

        public static int AddMFilmHall(MFilmHall mod)
        {
            using (IDbConnection connection = new SqlConnDb().GetSqlConnection())
            {
                string sql = string.Format(@"insert into FilmHallTB (FilmHallID,FilmHallName,SeatCnt
                                    )  values(@FilmHallID,@FilmHallName,@SeatCnt)");
                int ret = connection.Execute(sql, mod);
                if (ret != 1)
                {
                    throw new Exception("新增影响条数为0");
                }

                return ret;
            }
        }

        public static int AlterMFilmHall(MFilmHall mod)
        {
            using (IDbConnection connection = new SqlConnDb().GetSqlConnection())
            {
                string sql = string.Format(@"update FilmHallTB set FilmHallName=@FilmHallName,
                                                        SeatCnt=@SeatCnt
                                            where FilmHallID=@FilmHallID");
                int ret = connection.Execute(sql, mod);
                if (ret != 1)
                {
                    throw new Exception("新增影响条数为0");
                }

                return ret;
            }
        }

        public static int DeleteMFilmHall(MFilmHall mod)
        {
            using (IDbConnection connection = new SqlConnDb().GetSqlConnection())
            {
                string sql = string.Format(@"delete from  FilmHallTB where FilmHallID=@FilmHallID");
                int ret = connection.Execute(sql, mod);
                if (ret != 1)
                {
                    throw new Exception("新增影响条数为0");
                }

                return ret;
            }
        }

        public static void LoginAdmin(MAdmin mo)
        {
            using (SqlConnDb connection = new SqlConnDb())
            {
                string sql = string.Format(@"select *  from AdminTB where UserName='{0}' and psw = '{1}'",mo.UserName,mo.Psw);

                DataTable dt = connection.ExecuteDataTable(sql);

                if (dt.Rows.Count != 1)
                {
                    throw new Exception("登录失败");
                }
            }
        }

        public static void LoginMember(MMember mo)
        {
            using (SqlConnDb connection = new SqlConnDb())
            {
                string sql = string.Format(@"select *  from [MemberTB] where phone='{0}' and psw = '{1}'", mo.Phone, mo.Psw);

                DataTable dt = connection.ExecuteDataTable(sql);
                if (dt.Rows.Count != 1)
                {
                    throw new Exception("登录失败");
                }
            }
        }

        public static DataTable GetAllShowFilm()
        {
            using (SqlConnDb connection = new SqlConnDb())
            {
                string sql = string.Format(@"select *  from [ShowSheetTB]");

                return connection.ExecuteDataTable(sql);
            }
        }

        public static void AddOrder(MOrder mod)
        {
            using (IDbConnection connection = new SqlConnDb().GetSqlConnection())
            {
                string sql = string.Format(@"insert into OrderTB (Phone,ShowSheetName,seat)  values(@Phone,@ShowSheetName,@seat)");
                int ret = connection.Execute(sql, mod);
                if (ret != 1)
                {
                    throw new Exception("新增影响条数为0");
                }
            }
        }

        public static HashSet<string> GetHashSetByShowSheetName(string ShowSheetName)
        {
            using (SqlConnDb connection = new SqlConnDb())
            {
                string sql = string.Format(@"select seat  from [OrderTB] where ShowSheetName='{0}'", ShowSheetName);
                HashSet<string> st = new HashSet<string>();
                DataTable dt = connection.ExecuteDataTable(sql);

                for (int i = 0; i<dt.Rows.Count;i++ )
                {
                    st.Add(dt.Rows[i]["seat"].ToString());
                }

                return st;
            }
        }


        public static DataTable GetDtByShowSheetName(string ShowSheetName)
        {
            using (SqlConnDb connection = new SqlConnDb())
            {
                string sql = string.Format(@"select *  from [OrderTB] where ShowSheetName='{0}'", ShowSheetName);
                HashSet<string> st = new HashSet<string>();
                DataTable dt = connection.ExecuteDataTable(sql);
                return dt;
            }
        }
        public static DataTable GetDtByPhone(string phone)
        {
            using (SqlConnDb connection = new SqlConnDb())
            {
                string sql = string.Format(@"select *  from [OrderTB] where phone='{0}'", phone);
                DataTable dt = connection.ExecuteDataTable(sql);
                return dt;
            }
        }

        public static DataTable GetShowSheeDtByShowSheetName(string ShowSheetName)
        {
            using (SqlConnDb connection = new SqlConnDb())
            {
                string sql = string.Format(@"select *  from ShowSheetTB where ShowSheetName='{0}'", ShowSheetName);
                DataTable dt = connection.ExecuteDataTable(sql);
                return dt;
            }
        }
    }
}
