﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.IO;
using System.Security.Cryptography;
using System.Reflection;
using System.Net;
using System.Management;

namespace Ctd.Comm
{
    public class Function
    {
        /// <summary>
        /// 得到本机IP
        /// </summary>
        /// <returns></returns>
        public static string GetLocalIp()
        {
            System.Net.IPAddress[] ips = System.Net.Dns.GetHostAddresses(Environment.MachineName);
            string strIP = "";
            for (int i = 0; i < ips.Length; i++)
            {
                if (ips[i].ToString().Contains("192.168.10") || ips[i].ToString().Contains("192.168.40") || ips[i].ToString().Contains("192.168.0"))
                {
                    return ips[i].ToString();
                }
                strIP = ips[i].ToString();
            }
            return strIP;
        }

        /// <summary>
        /// 得到文件名MD5
        /// </summary>
        /// <param name="fileName"></param>
        /// <returns></returns>
        public static string GetMD5HashFromFile(string fileName)
        {
            try
            {
                FileStream file = new FileStream(fileName, FileMode.Open, FileAccess.Read);
                System.Security.Cryptography.MD5 md5 = new System.Security.Cryptography.MD5CryptoServiceProvider();
                byte[] retVal = md5.ComputeHash(file);
                file.Close();

                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < retVal.Length; i++)
                {
                    sb.Append(retVal[i].ToString("x2"));
                }
                return sb.ToString().ToUpper();
            }
            catch (Exception ex)
            {
                throw new Exception("GetMD5HashFromFile() fail,error:" + ex.Message);
            }
        }

        /// <summary>
        /// 32位MD5加密
        /// </summary>
        /// <param name="password"></param>
        /// <returns></returns>
        public static string MD5Encrypt32(string password)
        {
            string cl = password;
            string pwd = "";
            MD5 md5 = MD5.Create(); //实例化一个md5对像
            // 加密后是一个字节类型的数组，这里要注意编码UTF8/Unicode等的选择　
            byte[] s = md5.ComputeHash(Encoding.UTF8.GetBytes(cl));
            // 通过使用循环，将字节类型的数组转换为字符串，此字符串是常规字符格式化所得
            for (int i = 0; i < s.Length; i++)
            {
                // 将得到的字符串使用十六进制类型格式。格式后的字符是小写的字母，如果使用大写（X）则格式后的字符是大写字符 
                string sx = s[i].ToString("X");
                if (sx.Length == 1)
                {
                    sx = "0" + sx;
                }
                pwd = pwd + sx;

            }
            return pwd;
        }

        /// <summary>
        /// 31->0x31 压缩，两个字节压缩成一个字节
        /// </summary>
        /// <param name="hexString"></param>
        /// <returns></returns>
        public static byte[] HexStrToByte(string hexString)
        {
            hexString = hexString.Replace(" ", "");
            if ((hexString.Length % 2) != 0)
                hexString += " ";
            byte[] returnBytes = new byte[hexString.Length / 2];
            for (int i = 0; i < returnBytes.Length; i++)
                returnBytes[i] = Convert.ToByte(hexString.Substring(i * 2, 2), 16);
            return returnBytes;
        }

        /// <summary>
        /// byte to HexStr 0xae00cf => "AE00CF"
        /// </summary>
        /// <param name="bytes"></param>
        /// <returns></returns>
        public static string ByteToHexStr(byte[] bytes)
        {
            string hexString = string.Empty;
            if (bytes != null)
            {
                StringBuilder strB = new StringBuilder();

                for (int i = 0; i < bytes.Length; i++)
                {
                    strB.Append(bytes[i].ToString("X2"));
                }
                hexString = strB.ToString();
            }
            return hexString;
        }

        /// <summary>
        /// byte to HexStr 0xae00cf => "AE00CF"
        /// </summary>
        /// <param name="bytes"></param>
        /// <returns></returns>
        public static string ByteToHexStr(byte[] bytes,int lenBytes)
        {
            string hexString = string.Empty;
            if (bytes != null)
            {
                StringBuilder strB = new StringBuilder();

                for (int i = 0; i < lenBytes; i++)
                {
                    strB.Append(bytes[i].ToString("X2"));
                }
                hexString = strB.ToString();
            }
            return hexString;
        }


        /// <summary>
        /// 3132->12
        /// </summary>
        /// <param name="hexString"></param>
        /// <returns></returns>
        public static string HexStrToAsciiStr(string hexStr)
        {
            return Encoding.GetEncoding("GB2312").GetString(HexStrToByte(hexStr));
        }

        /// <summary>
        /// "123" to "313233"
        /// </summary>
        /// <param name="ascStr"></param>
        /// <returns></returns>
        public static string AsciiStrToHexStr(string ascStr)
        {
            return ByteToHexStr(System.Text.Encoding.Default.GetBytes(ascStr));
        }

//         public static string HexToAscii2(string hexString)
//         {
//             StringBuilder sb = new StringBuilder();
//             for (int i = 0; i <= hexString.Length - 2; i += 2)
//             {
//                 sb.Append(
//                     Convert.ToString(
//                         Convert.ToChar(Int32.Parse(hexString.Substring(i, 2),
//                                                    System.Globalization.NumberStyles.HexNumber))));
//             }
//             return sb.ToString();
//         }

        public static DataTable ToDataTable(DataRow[] rows)
        {
            if (rows == null || rows.Length == 0) return null;
            DataTable tmp = rows[0].Table.Clone();  // 复制DataRow的表结构  
            foreach (DataRow row in rows)
                tmp.Rows.Add(row.ItemArray);  // 将DataRow添加到DataTable中  
            return tmp;
        }

        public static string getIP()
        {
            string ip = string.Empty;
            List<string> ipList = new List<string>();
            IPAddress[] addressList = Dns.GetHostAddresses(Dns.GetHostName());
            for (int i = 0; i < addressList.Length; i++)
            {
                if (addressList[i].AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork)
                {
                    ipList.Add(addressList[i].ToString());
                    ip = addressList[i].ToString();
                    if (ip.Substring(0, 11) == "192.168.10." || ip.Substring(0, 11) == "192.168.40." || ip.Substring(0, 11) == "192.168.100")
                    {
                        return ip;
                    }
                }
            }
            return ip;
        }

        /// <summary>
        /// 转换数据 去掉#，%
        /// </summary>
        /// <param name="_data"></param>
        /// <returns></returns>
        public static string TanPrintdata(string _data)
        {
            string str = "";
            string[] arr = _data.Split(',');
            for (int i = 0; i < arr.Length; i++)
            {
                string tmp = arr[i];
                if (tmp.Length == 0)
                {
                    continue;
                }
                char c1 = arr[i][0];
                char c2 = arr[i][tmp.Length - 1];
                if (c1 == '#' || c1 == '%' || c1 == '&')
                {
                    if (c1 == c2)
                    {
                        //判断中间不出现其它C1
                        arr[i] = arr[i].Substring(1, arr[i].Length - 2);

                        int loc = arr[i].IndexOf(c1);
                        if (loc != -1)
                        {
                            throw new Exception("字符串中包含分隔符!");
                        }
                    }
                    else
                    {
                        if (!(c2 == '#' || c2 == '%'))
                        {
                            throw new Exception("字符串中包含分隔符!");
                        }
                        //判断中间出现一个c1和c2
                        int loc1 = arr[i].IndexOf(c1, 1);
                        int loc2 = arr[i].IndexOf(c2);
                        if (loc1 + 1 != loc2)
                        {
                            throw new Exception("字符串中包含分隔符!");
                        }
                        arr[i] = arr[i].Replace(c1.ToString() + c2.ToString(), ",");
                        arr[i] = arr[i].Substring(1, arr[i].Length - 2);

                        loc1 = arr[i].IndexOf(c1);
                        loc2 = arr[i].IndexOf(c2);
                        if (loc1 != -1 || loc2 != -1)
                        {
                            throw new Exception("字符串中包含分隔符!");
                        }

                    }
                }
            }

            for (int j = 0; j < arr.Length; j++)
            {
                if (j == arr.Length - 1)
                {
                    str += arr[j];
                }
                else
                {
                    str += arr[j] + ",";
                }
            }

            return str;
        }

        public static string GetMaskPan(string pan)
        {
            string ymPan="****************************";
            string retPan= pan.Substring(0,6) + ymPan.Substring(0,pan.Length-10) + pan.Substring(pan.Length-4);
            return retPan;
        }

        public static string GetBFPan(string pan)
        {
            string tmpBw = "FFFFFFFFFFFFFFFF";

            string panBuf = pan;
            if (pan.Length != 16)
            {
                panBuf = pan + tmpBw.Substring(0, tmpBw.Length - pan.Length % 16);
            }
            return panBuf;

        }
    }
}
