﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.IO;
using System.Data;

namespace Ctd.Comm
{
        /// <summary>
    ///SqlConnDb 的摘要说明
    /// </summary>
    public class SqlConnDb : IDisposable
    {
        //public static readonly string coonStr = "Data Source=.;Initial Catalog=CtdMangerSystemDB;User ID=software;Password=softadmin107!)&";
        //public static readonly string coonStr = @"Data Source=MS-APJBAMHFAFVA\MSSQLSERVER2019;Initial Catalog=CinemaDB;User ID=sa;Password=aaaa@123";
        public static  string coonStr = @"server=小颜\SQLEXPRESS;database=CinemaDB;integrated security=true";
                
        public SqlConnDb()
        {
            m_connectionStr = coonStr;
            conn = new SqlConnection(m_connectionStr);
            conn.Open();
        }

        public SqlConnDb(string connectionStr)
        {
            m_connectionStr = connectionStr;
            conn = new SqlConnection(m_connectionStr);
            conn.Open();
        }

        ~SqlConnDb()
        {
            this.Dispose();
        }

        private string m_connectionStr;
        private SqlConnection conn;        // = new SqlConnection(m_connectionStr);
        //事务

        public SqlConnection GetSqlConnection()
        {
            return conn;
        }

        public void InitSqlConnDb()
        {
            conn = new SqlConnection(m_connectionStr);
            conn.Open();
        }
        /// <summary>
        /// 执行插入、更新、删除等命令
        /// </summary>
        /// <param name="sql">SQL 语句</param>
        public bool ExcutNoReader(string[] sql)
        {
            try
            {
                using (SqlTransaction transaction = conn.BeginTransaction("SampleTransaction"))
                {
                    try
                    {
                        using (SqlCommand cmd = new SqlCommand("", conn, transaction))
                        {
                            cmd.CommandTimeout = 600;

                            for (int i = 0; i < sql.Length; i++)
                            {
                                cmd.CommandText = sql[i];
                                cmd.ExecuteNonQuery();
                            }
                        }
                        transaction.Commit();
                    }
                    catch (System.Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
                return true;
            }
            catch (System.Exception ex)
            {
                throw ex;
            }
        }

        public int ExcutNoReader(string sql)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand(sql, conn))
                {
                    cmd.CommandTimeout = 600;
                    return cmd.ExecuteNonQuery();//返回执行成功的行数
                }
            }
            catch (System.Exception e)
            {
                throw e;
            }
        }

        /// <summary>
        /// 返回Datatable
        /// </summary>
        /// <param name="sql">sql命令</param>
        /// <returns></returns>
        public System.Data.DataTable ExecuteDataTable(string sql)
        {
            try
            {
                using (SqlDataAdapter adapter = new SqlDataAdapter(sql, conn))
                {
                    System.Data.DataSet ds = new System.Data.DataSet();
                    adapter.SelectCommand.CommandTimeout = 600;
                    adapter.Fill(ds);
                    return ds.Tables[0];
                }
            }
            catch (System.Exception e)
            {
                throw e;
            }

        }

        /// <summary>
        /// 从数据库中查询数据的,返回为DataSet
        /// </summary>
        /// <param name="sql"></param>
        /// <returns></returns>
        public DataSet Query(string sql)
        {
            try
            {
                DataSet ds = new DataSet();//DataSet是表的集合
                using (SqlDataAdapter da = new SqlDataAdapter(sql, conn))    //从数据库中查询)
                {
                    da.Fill(ds);//将数据填充到DataSet
                    return ds;//返回结果
                }
            }
            catch (System.Exception ex)
            {
                throw ex;
            }

        }
        /// <summary>
        /// 返回SqlDataReader
        /// </summary>
        /// <param name="sql">sql命令</param>
        /// <returns></returns>
        public SqlDataReader ExecuteReader(string sql)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand(sql, conn))
                {
                    SqlDataReader rd = cmd.ExecuteReader();

                    return rd;
                }
            }
            catch (System.Exception e)
            {
                throw e;
            }

        }

        /// <summary>
        /// 使openrowset生效
        /// </summary>
        public void Enable_openrowset()
        {
            string cmd = @"EXEC sp_configure 'show advanced options', 1;RECONFIGURE;EXEC sp_configure 'Ad Hoc Distributed Queries', 1;RECONFIGURE;";
            ExcutNoReader(cmd);
        }

        public void Dispose()
        {
            if (conn != null)
            {
                if (conn.State == ConnectionState.Open)
                {
                    conn.Close();
                    conn.Dispose();
                    SqlConnection.ClearPool(conn);
                    SqlConnection.ClearAllPools();
                }
            }
        }

    }//end of class

}
