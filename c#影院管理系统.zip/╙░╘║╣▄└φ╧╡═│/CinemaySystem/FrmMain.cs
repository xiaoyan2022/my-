﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using TX.Framework.WindowUI.Forms;
using TX.Framework.WindowUI.Controls;
using CinemaySystem.UI;
using CinemaySystem.BLL;
using CinemaySystem.Model;
namespace CinemaySystem
{
    public partial class FrmMain : Form
    {
        static public string Phone;
        DataTable dt = new DataTable();
        


        public FrmMain()
        {
            InitializeComponent();

        }

        private void 登录ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmLogin fl = new FrmLogin();
            fl.Show();
        }

        private void 弹出ToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void 基础数据ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmBaseData fb = new FrmBaseData();
            fb.Show();
        }

        private void FrmMain_Load(object sender, EventArgs e)
        {
            FrmLogin fl = new FrmLogin();
            fl.ShowDialog();

            for (int j = 1; j < 11;j++ )
            {
                for (int i = 1; i < 5; i++)
                {
                    CheckBox ch = new CheckBox();
                    ch.Text = j.ToString() + "-" +i.ToString();
                    ch.Checked = false;
                    ch.Click += new System.EventHandler(this.txb_SeatChange);
                    flowLayoutPanel1.Controls.Add(ch);
                }
            }

            dt = BLLSql.GetAllShowFilm();
            dgvShow.DataSource = dt;
            dgvShow2.DataSource = dt;

            txb会员.Text = Phone;

            if (Phone == "" || Phone == null)
            {
                //管理员登录不能购票
                button2.Visible = false;
            }
            else {
                //会员登录不能录入数据
                录入ToolStripMenuItem.Visible = false;
                //录入ToolStripMenuItem.Enabled = false;
            }

            txTabControl1.Visible = false;
        }

        private void txb_SeatChange(object sender, EventArgs e)
        {
            CheckBox ch = (CheckBox)sender;
            if (ch.Checked)
            {
                txb_Seat.Text += "," + ch.Text;
                ch.BackColor = Color.Red;
            }
            else
            {
                string str = txb_Seat.Text;
                str = str.Replace(ch.Text, "");
                txb_Seat.Text = str.TrimEnd(',');
                ch.BackColor = Color.LightGreen;
            }

            txb_Seat.Text = txb_Seat.Text.TrimStart(',');
        }

        private void dgvShow_SelectionChanged(object sender, EventArgs e)
        {
            try
            {
                int a = dgvShow.CurrentRow.Index;
                txb_FilmName.Text = dgvShow.Rows[a].Cells["FilmName"].Value.ToString();
                txb_CinemaName.Text = dgvShow.Rows[a].Cells["CinemaName"].Value.ToString();
                txb_STime.Text = dgvShow.Rows[a].Cells["STime"].Value.ToString();
                txb_TicketPrice.Text = dgvShow.Rows[a].Cells["TicketPrice"].Value.ToString();
                txb_FilmHallID.Text = dgvShow.Rows[a].Cells["FilmHallID"].Value.ToString();
                txb_ShowSheetName.Text = dgvShow.Rows[a].Cells["ShowSheetName"].Value.ToString();
                updateCbox();

                this.pictureBox1.Load("Image\\" + txb_FilmName.Text + ".png");
            }
            catch (System.Exception ex)
            {
            	
            }
        }

        private void updateCbox()
        {
            try
            {
                HashSet<string> hseat = BLLSql.GetHashSetByShowSheetName(txb_ShowSheetName.Text);
                foreach (Control ct in flowLayoutPanel1.Controls)
                {
                    CheckBox cb = (CheckBox)ct;
                    if (hseat.Contains(cb.Text))
                    {
                        cb.Enabled = false;
                        cb.BackColor = Color.Gray;
                        cb.Checked = true;
                    }
                    else
                    {
                        cb.Enabled = true;
                        cb.BackColor = Color.LightGreen;
                        cb.Checked = false;
                    }

                }
            }
            catch (System.Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            updateCbox();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                MOrder ot = new MOrder();
                ot.Phone = Phone;
                ot.ShowSheetName = txb_ShowSheetName.Text;

                string []seat = txb_Seat.Text.Split(',');

                for (int i = 0; i<seat.Length; i++)
                {
                    ot.Seat = seat[i];
                    BLLSql.AddOrder(ot); 
                }

                MessageBox.Show("成功");

            }
            catch (System.Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            dt = BLLSql.GetAllShowFilm();
            dgvShow2.DataSource = dt;
        }

        private void dgvShow2_SelectionChanged(object sender, EventArgs e)
        {
            try
            {
                int a = dgvShow.CurrentRow.Index;
//                 txb_FilmName.Text = dgvShow.Rows[a].Cells["FilmName"].Value.ToString();
//                 txb_CinemaName.Text = dgvShow.Rows[a].Cells["CinemaName"].Value.ToString();
//                 txb_STime.Text = dgvShow.Rows[a].Cells["STime"].Value.ToString();
//                 txb_TicketPrice.Text = dgvShow.Rows[a].Cells["TicketPrice"].Value.ToString();
//                 txb_FilmHallID.Text = dgvShow.Rows[a].Cells["FilmHallID"].Value.ToString();
                //txb_ShowSheetName.Text = dgvShow.Rows[a].Cells["ShowSheetName"].Value.ToString();

                dgv_order.DataSource = BLLSql.GetDtByShowSheetName(dgvShow.Rows[a].Cells["ShowSheetName"].Value.ToString());
            }
            catch (System.Exception ex)
            {

            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            txTabControl1.Visible = true;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            try
            {
                MShowSheet ms = new MShowSheet();
                ms.FilmName = txb_FilmName.Text;       
                ms.CinemaName = txb_CinemaName.Text;     
                ms.STime = txb_STime.Text;          
                ms.TicketPrice = Convert.ToDecimal(txb_TicketPrice.Text);    
                ms.FilmHallID = txb_FilmHallID.Text ;
                ms.ShowSheetName = txb_ShowSheetName.Text;  

                FrmOrder fo = new FrmOrder(ms,txb_Seat.Text);

                fo.ShowDialog();

                if (FrmOrder.BuyFLag)
                {
                    button2_Click( sender,  e);
                }
                else
                {
                    MessageBox.Show("你取消了购票");
                }
            }
            catch (System.Exception ex)
            {
            	
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            try
            {
                FrmPerOrder fp = new FrmPerOrder(Phone);

                fp.ShowDialog();
            }
            catch (System.Exception ex)
            {
            	
            }
        }
    }
}
