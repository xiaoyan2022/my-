﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CinemaySystem.Model
{
    public class MCinema
    {
        public string CinemaName { get; set; }
        public string CinemaPosition { get; set; }
        public string Phone { get; set; }
    }
}
