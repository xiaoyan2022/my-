﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CinemaySystem.Model
{
    public class MFilmHall
    {
        public string FilmHallID { get; set; }
        public string FilmHallName { get; set; }
        public int SeatCnt { get; set; }
    }
}
