﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CinemaySystem.Model
{
    class MMember
    {
        public int ID { get; set; }
        public string Phone { get; set; }
        public string Psw { get; set; }
    }
}
