﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CinemaySystem.Model
{
    class MMovie
    {
        public int FilmID { get; set; }
        public string FilmName { get; set; }
        public string Director { get; set; }
        public string FilmType { get; set; }
        public string FileImageName { get; set; }
        public decimal Score { get; set; }
    }
}
