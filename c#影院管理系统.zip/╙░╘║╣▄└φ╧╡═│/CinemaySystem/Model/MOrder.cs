﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CinemaySystem.Model
{
    public class MOrder
    {
        public int ID { get; set; }
        public string Phone { get; set; }
        public string ShowSheetName { get; set; }
        public string Seat { get; set; }
    }
}
