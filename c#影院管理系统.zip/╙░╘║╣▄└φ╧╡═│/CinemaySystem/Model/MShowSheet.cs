﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CinemaySystem.Model
{
    public class MShowSheet
    {
        public int ShowSheetID { get; set; }
        public string ShowSheetName { get; set; }
        public string CinemaName { get; set; }
        public string FilmName { get; set; }
        public string STime { get; set; }
        public decimal TicketPrice { get; set; }
        public string FilmHallID { get; set; }
    }
}
