﻿namespace CinemaySystem.UI
{
    partial class FrmBaseData
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            this.txTabControl1 = new TX.Framework.WindowUI.Controls.TXTabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.panel2 = new TX.Framework.WindowUI.Controls.Panel();
            this.dgv_MovieTB = new System.Windows.Forms.DataGridView();
            this.panel1 = new TX.Framework.WindowUI.Controls.Panel();
            this.picFilme = new System.Windows.Forms.PictureBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txb_FilmType = new TX.Framework.WindowUI.Controls.TXTextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txb_Score = new TX.Framework.WindowUI.Controls.TXTextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txb_Director = new TX.Framework.WindowUI.Controls.TXTextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txb_FilmName = new TX.Framework.WindowUI.Controls.TXTextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txbMovie4 = new TX.Framework.WindowUI.Controls.TXButton();
            this.txbMovie3 = new TX.Framework.WindowUI.Controls.TXButton();
            this.txbMovie2 = new TX.Framework.WindowUI.Controls.TXButton();
            this.txbMovie1 = new TX.Framework.WindowUI.Controls.TXButton();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.panel3 = new TX.Framework.WindowUI.Controls.Panel();
            this.dgv_Cinema = new System.Windows.Forms.DataGridView();
            this.panel4 = new TX.Framework.WindowUI.Controls.Panel();
            this.txb_CinemaPhone = new TX.Framework.WindowUI.Controls.TXTextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.txb_CinemaPosition = new TX.Framework.WindowUI.Controls.TXTextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.txb_CinemaName = new TX.Framework.WindowUI.Controls.TXTextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txBtnCinema4 = new TX.Framework.WindowUI.Controls.TXButton();
            this.txBtnCinema3 = new TX.Framework.WindowUI.Controls.TXButton();
            this.txBtnCinema2 = new TX.Framework.WindowUI.Controls.TXButton();
            this.txBtnCinema1 = new TX.Framework.WindowUI.Controls.TXButton();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.panel5 = new TX.Framework.WindowUI.Controls.Panel();
            this.dgv_FilmHall = new System.Windows.Forms.DataGridView();
            this.panel6 = new TX.Framework.WindowUI.Controls.Panel();
            this.txb_SeatCnt = new TX.Framework.WindowUI.Controls.TXTextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.txb_FilmHallName = new TX.Framework.WindowUI.Controls.TXTextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.txb_FilmHallID = new TX.Framework.WindowUI.Controls.TXTextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.txBtnFilmHall4 = new TX.Framework.WindowUI.Controls.TXButton();
            this.txBtnFilmHall3 = new TX.Framework.WindowUI.Controls.TXButton();
            this.txBtnFilmHall2 = new TX.Framework.WindowUI.Controls.TXButton();
            this.txBtnFilmHall1 = new TX.Framework.WindowUI.Controls.TXButton();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.panel7 = new TX.Framework.WindowUI.Controls.Panel();
            this.dgv_MemberTB = new System.Windows.Forms.DataGridView();
            this.panel8 = new TX.Framework.WindowUI.Controls.Panel();
            this.txb_MemberPsw = new TX.Framework.WindowUI.Controls.TXTextBox();
            this.txb_Phone = new TX.Framework.WindowUI.Controls.TXTextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txBtn_Member4 = new TX.Framework.WindowUI.Controls.TXButton();
            this.txBtn_Member3 = new TX.Framework.WindowUI.Controls.TXButton();
            this.txBtn_Member2 = new TX.Framework.WindowUI.Controls.TXButton();
            this.txBtn_Member1 = new TX.Framework.WindowUI.Controls.TXButton();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.panel9 = new TX.Framework.WindowUI.Controls.Panel();
            this.dgv_AdminTB = new System.Windows.Forms.DataGridView();
            this.panel10 = new TX.Framework.WindowUI.Controls.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txb_Psw = new TX.Framework.WindowUI.Controls.TXTextBox();
            this.txb_UserName = new TX.Framework.WindowUI.Controls.TXTextBox();
            this.txBtnAdmin4 = new TX.Framework.WindowUI.Controls.TXButton();
            this.txBtnAdmin3 = new TX.Framework.WindowUI.Controls.TXButton();
            this.txBtnAdmin2 = new TX.Framework.WindowUI.Controls.TXButton();
            this.txBtnAdmin1 = new TX.Framework.WindowUI.Controls.TXButton();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.panel12 = new TX.Framework.WindowUI.Controls.Panel();
            this.panel11 = new TX.Framework.WindowUI.Controls.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btn删除影片 = new System.Windows.Forms.Button();
            this.btn录入影片 = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.label19 = new System.Windows.Forms.Label();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.txTextBox1 = new TX.Framework.WindowUI.Controls.TXTextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.txTabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_MovieTB)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picFilme)).BeginInit();
            this.tabPage2.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Cinema)).BeginInit();
            this.panel4.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_FilmHall)).BeginInit();
            this.panel6.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.panel7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_MemberTB)).BeginInit();
            this.panel8.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.panel9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_AdminTB)).BeginInit();
            this.panel10.SuspendLayout();
            this.tabPage6.SuspendLayout();
            this.panel11.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // txTabControl1
            // 
            this.txTabControl1.BaseTabColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(250)))));
            this.txTabControl1.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(168)))), ((int)(((byte)(192)))));
            this.txTabControl1.CaptionFont = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txTabControl1.CheckedTabColor = System.Drawing.Color.FromArgb(((int)(((byte)(67)))), ((int)(((byte)(165)))), ((int)(((byte)(220)))));
            this.txTabControl1.Controls.Add(this.tabPage1);
            this.txTabControl1.Controls.Add(this.tabPage2);
            this.txTabControl1.Controls.Add(this.tabPage3);
            this.txTabControl1.Controls.Add(this.tabPage4);
            this.txTabControl1.Controls.Add(this.tabPage5);
            this.txTabControl1.Controls.Add(this.tabPage6);
            this.txTabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txTabControl1.DrawMode = System.Windows.Forms.TabDrawMode.OwnerDrawFixed;
            this.txTabControl1.HeightLightTabColor = System.Drawing.Color.FromArgb(((int)(((byte)(140)))), ((int)(((byte)(67)))), ((int)(((byte)(165)))), ((int)(((byte)(220)))));
            this.txTabControl1.Location = new System.Drawing.Point(0, 0);
            this.txTabControl1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txTabControl1.Name = "txTabControl1";
            this.txTabControl1.SelectedIndex = 0;
            this.txTabControl1.Size = new System.Drawing.Size(1472, 781);
            this.txTabControl1.TabCornerRadius = 3;
            this.txTabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.panel2);
            this.tabPage1.Controls.Add(this.panel1);
            this.tabPage1.Location = new System.Drawing.Point(4, 33);
            this.tabPage1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tabPage1.Size = new System.Drawing.Size(1464, 744);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "电影表";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // panel2
            // 
            this.panel2.AssociatedSplitter = null;
            this.panel2.BackColor = System.Drawing.Color.Transparent;
            this.panel2.CaptionFont = new System.Drawing.Font("宋体", 9.5F);
            this.panel2.CaptionHeight = 22;
            this.panel2.ColorScheme = TX.Framework.WindowUI.Controls.ColorScheme.Custom;
            this.panel2.Controls.Add(this.dgv_MovieTB);
            this.panel2.CustomColors.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(168)))), ((int)(((byte)(192)))));
            this.panel2.CustomColors.CaptionCloseIcon = System.Drawing.Color.Red;
            this.panel2.CustomColors.CaptionExpandIcon = System.Drawing.SystemColors.ControlText;
            this.panel2.CustomColors.CaptionGradientBegin = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(250)))));
            this.panel2.CustomColors.CaptionGradientEnd = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(250)))));
            this.panel2.CustomColors.CaptionGradientMiddle = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(214)))), ((int)(((byte)(223)))));
            this.panel2.CustomColors.CaptionSelectedGradientBegin = System.Drawing.Color.FromArgb(((int)(((byte)(140)))), ((int)(((byte)(67)))), ((int)(((byte)(165)))), ((int)(((byte)(220)))));
            this.panel2.CustomColors.CaptionSelectedGradientEnd = System.Drawing.Color.FromArgb(((int)(((byte)(67)))), ((int)(((byte)(165)))), ((int)(((byte)(220)))));
            this.panel2.CustomColors.CaptionText = System.Drawing.SystemColors.ControlText;
            this.panel2.CustomColors.CollapsedCaptionText = System.Drawing.SystemColors.ControlText;
            this.panel2.CustomColors.ContentGradientBegin = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(247)))), ((int)(((byte)(252)))));
            this.panel2.CustomColors.ContentGradientEnd = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(247)))), ((int)(((byte)(252)))));
            this.panel2.CustomColors.InnerBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(218)))), ((int)(((byte)(222)))));
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.ForeColor = System.Drawing.SystemColors.ControlText;
            this.panel2.Image = null;
            this.panel2.Location = new System.Drawing.Point(4, 185);
            this.panel2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel2.MinimumSize = new System.Drawing.Size(29, 28);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1456, 555);
            this.panel2.TabIndex = 1;
            this.panel2.Text = "数据";
            this.panel2.ToolTipTextCloseIcon = null;
            this.panel2.ToolTipTextExpandIconPanelCollapsed = null;
            this.panel2.ToolTipTextExpandIconPanelExpanded = null;
            // 
            // dgv_MovieTB
            // 
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv_MovieTB.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgv_MovieTB.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgv_MovieTB.DefaultCellStyle = dataGridViewCellStyle2;
            this.dgv_MovieTB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgv_MovieTB.Location = new System.Drawing.Point(1, 23);
            this.dgv_MovieTB.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dgv_MovieTB.Name = "dgv_MovieTB";
            this.dgv_MovieTB.RowTemplate.Height = 23;
            this.dgv_MovieTB.Size = new System.Drawing.Size(1454, 531);
            this.dgv_MovieTB.TabIndex = 0;
            // 
            // panel1
            // 
            this.panel1.AssociatedSplitter = null;
            this.panel1.BackColor = System.Drawing.Color.Transparent;
            this.panel1.CaptionFont = new System.Drawing.Font("宋体", 9.5F);
            this.panel1.CaptionHeight = 30;
            this.panel1.ColorScheme = TX.Framework.WindowUI.Controls.ColorScheme.Custom;
            this.panel1.Controls.Add(this.picFilme);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.txb_FilmType);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.txb_Score);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.txb_Director);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.txb_FilmName);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.txbMovie4);
            this.panel1.Controls.Add(this.txbMovie3);
            this.panel1.Controls.Add(this.txbMovie2);
            this.panel1.Controls.Add(this.txbMovie1);
            this.panel1.CustomColors.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(168)))), ((int)(((byte)(192)))));
            this.panel1.CustomColors.CaptionCloseIcon = System.Drawing.Color.Red;
            this.panel1.CustomColors.CaptionExpandIcon = System.Drawing.SystemColors.ControlText;
            this.panel1.CustomColors.CaptionGradientBegin = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(250)))));
            this.panel1.CustomColors.CaptionGradientEnd = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(250)))));
            this.panel1.CustomColors.CaptionGradientMiddle = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(214)))), ((int)(((byte)(223)))));
            this.panel1.CustomColors.CaptionSelectedGradientBegin = System.Drawing.Color.FromArgb(((int)(((byte)(140)))), ((int)(((byte)(67)))), ((int)(((byte)(165)))), ((int)(((byte)(220)))));
            this.panel1.CustomColors.CaptionSelectedGradientEnd = System.Drawing.Color.FromArgb(((int)(((byte)(67)))), ((int)(((byte)(165)))), ((int)(((byte)(220)))));
            this.panel1.CustomColors.CaptionText = System.Drawing.SystemColors.ControlText;
            this.panel1.CustomColors.CollapsedCaptionText = System.Drawing.SystemColors.ControlText;
            this.panel1.CustomColors.ContentGradientBegin = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(247)))), ((int)(((byte)(252)))));
            this.panel1.CustomColors.ContentGradientEnd = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(247)))), ((int)(((byte)(252)))));
            this.panel1.CustomColors.InnerBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(218)))), ((int)(((byte)(222)))));
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.panel1.Image = null;
            this.panel1.Location = new System.Drawing.Point(4, 4);
            this.panel1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel1.MinimumSize = new System.Drawing.Size(40, 38);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1456, 181);
            this.panel1.TabIndex = 0;
            this.panel1.ToolTipTextCloseIcon = null;
            this.panel1.ToolTipTextExpandIconPanelCollapsed = null;
            this.panel1.ToolTipTextExpandIconPanelExpanded = null;
            // 
            // picFilme
            // 
            this.picFilme.Location = new System.Drawing.Point(963, 50);
            this.picFilme.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.picFilme.Name = "picFilme";
            this.picFilme.Size = new System.Drawing.Size(460, 124);
            this.picFilme.TabIndex = 6;
            this.picFilme.TabStop = false;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(899, 62);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(37, 15);
            this.label9.TabIndex = 5;
            this.label9.Text = "封面";
            // 
            // txb_FilmType
            // 
            this.txb_FilmType.BackColor = System.Drawing.Color.Transparent;
            this.txb_FilmType.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(168)))), ((int)(((byte)(192)))));
            this.txb_FilmType.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txb_FilmType.ForeColor = System.Drawing.SystemColors.WindowText;
            this.txb_FilmType.HeightLightBolorColor = System.Drawing.Color.FromArgb(((int)(((byte)(140)))), ((int)(((byte)(67)))), ((int)(((byte)(165)))), ((int)(((byte)(220)))));
            this.txb_FilmType.Image = null;
            this.txb_FilmType.ImageSize = new System.Drawing.Size(0, 0);
            this.txb_FilmType.Location = new System.Drawing.Point(541, 54);
            this.txb_FilmType.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txb_FilmType.Name = "txb_FilmType";
            this.txb_FilmType.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txb_FilmType.PasswordChar = '\0';
            this.txb_FilmType.Required = false;
            this.txb_FilmType.Size = new System.Drawing.Size(327, 28);
            this.txb_FilmType.TabIndex = 4;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(461, 62);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(67, 15);
            this.label7.TabIndex = 3;
            this.label7.Text = "电影类型";
            // 
            // txb_Score
            // 
            this.txb_Score.BackColor = System.Drawing.Color.Transparent;
            this.txb_Score.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(168)))), ((int)(((byte)(192)))));
            this.txb_Score.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txb_Score.ForeColor = System.Drawing.SystemColors.WindowText;
            this.txb_Score.HeightLightBolorColor = System.Drawing.Color.FromArgb(((int)(((byte)(140)))), ((int)(((byte)(67)))), ((int)(((byte)(165)))), ((int)(((byte)(220)))));
            this.txb_Score.Image = null;
            this.txb_Score.ImageSize = new System.Drawing.Size(0, 0);
            this.txb_Score.Location = new System.Drawing.Point(541, 89);
            this.txb_Score.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txb_Score.Name = "txb_Score";
            this.txb_Score.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txb_Score.PasswordChar = '\0';
            this.txb_Score.Required = false;
            this.txb_Score.Size = new System.Drawing.Size(327, 28);
            this.txb_Score.TabIndex = 4;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(457, 98);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(37, 15);
            this.label8.TabIndex = 3;
            this.label8.Text = "评分";
            // 
            // txb_Director
            // 
            this.txb_Director.BackColor = System.Drawing.Color.Transparent;
            this.txb_Director.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(168)))), ((int)(((byte)(192)))));
            this.txb_Director.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txb_Director.ForeColor = System.Drawing.SystemColors.WindowText;
            this.txb_Director.HeightLightBolorColor = System.Drawing.Color.FromArgb(((int)(((byte)(140)))), ((int)(((byte)(67)))), ((int)(((byte)(165)))), ((int)(((byte)(220)))));
            this.txb_Director.Image = null;
            this.txb_Director.ImageSize = new System.Drawing.Size(0, 0);
            this.txb_Director.Location = new System.Drawing.Point(120, 89);
            this.txb_Director.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txb_Director.Name = "txb_Director";
            this.txb_Director.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txb_Director.PasswordChar = '\0';
            this.txb_Director.Required = false;
            this.txb_Director.Size = new System.Drawing.Size(327, 28);
            this.txb_Director.TabIndex = 4;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(23, 98);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(37, 15);
            this.label6.TabIndex = 3;
            this.label6.Text = "导演";
            // 
            // txb_FilmName
            // 
            this.txb_FilmName.BackColor = System.Drawing.Color.Transparent;
            this.txb_FilmName.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(168)))), ((int)(((byte)(192)))));
            this.txb_FilmName.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txb_FilmName.ForeColor = System.Drawing.SystemColors.WindowText;
            this.txb_FilmName.HeightLightBolorColor = System.Drawing.Color.FromArgb(((int)(((byte)(140)))), ((int)(((byte)(67)))), ((int)(((byte)(165)))), ((int)(((byte)(220)))));
            this.txb_FilmName.Image = null;
            this.txb_FilmName.ImageSize = new System.Drawing.Size(0, 0);
            this.txb_FilmName.Location = new System.Drawing.Point(120, 54);
            this.txb_FilmName.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txb_FilmName.Name = "txb_FilmName";
            this.txb_FilmName.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txb_FilmName.PasswordChar = '\0';
            this.txb_FilmName.Required = false;
            this.txb_FilmName.Size = new System.Drawing.Size(327, 28);
            this.txb_FilmName.TabIndex = 4;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(23, 62);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(52, 15);
            this.label5.TabIndex = 3;
            this.label5.Text = "电影名";
            // 
            // txbMovie4
            // 
            this.txbMovie4.Image = null;
            this.txbMovie4.Location = new System.Drawing.Point(429, 4);
            this.txbMovie4.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txbMovie4.Name = "txbMovie4";
            this.txbMovie4.Size = new System.Drawing.Size(133, 35);
            this.txbMovie4.TabIndex = 0;
            this.txbMovie4.Text = "查询";
            this.txbMovie4.UseVisualStyleBackColor = true;
            this.txbMovie4.Click += new System.EventHandler(this.txbMovie4_Click);
            // 
            // txbMovie3
            // 
            this.txbMovie3.Image = null;
            this.txbMovie3.Location = new System.Drawing.Point(288, 4);
            this.txbMovie3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txbMovie3.Name = "txbMovie3";
            this.txbMovie3.Size = new System.Drawing.Size(133, 35);
            this.txbMovie3.TabIndex = 0;
            this.txbMovie3.Text = "删除";
            this.txbMovie3.UseVisualStyleBackColor = true;
            this.txbMovie3.Click += new System.EventHandler(this.txbMovie3_Click);
            // 
            // txbMovie2
            // 
            this.txbMovie2.Image = null;
            this.txbMovie2.Location = new System.Drawing.Point(147, 4);
            this.txbMovie2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txbMovie2.Name = "txbMovie2";
            this.txbMovie2.Size = new System.Drawing.Size(133, 35);
            this.txbMovie2.TabIndex = 0;
            this.txbMovie2.Text = "修改";
            this.txbMovie2.UseVisualStyleBackColor = true;
            this.txbMovie2.Click += new System.EventHandler(this.txbMovie2_Click);
            // 
            // txbMovie1
            // 
            this.txbMovie1.Image = null;
            this.txbMovie1.Location = new System.Drawing.Point(5, 4);
            this.txbMovie1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txbMovie1.Name = "txbMovie1";
            this.txbMovie1.Size = new System.Drawing.Size(133, 35);
            this.txbMovie1.TabIndex = 0;
            this.txbMovie1.Text = "新增";
            this.txbMovie1.UseVisualStyleBackColor = true;
            this.txbMovie1.Click += new System.EventHandler(this.txbMovie1_Click);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.panel3);
            this.tabPage2.Controls.Add(this.panel4);
            this.tabPage2.Location = new System.Drawing.Point(4, 33);
            this.tabPage2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tabPage2.Size = new System.Drawing.Size(1464, 744);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "影院";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // panel3
            // 
            this.panel3.AssociatedSplitter = null;
            this.panel3.BackColor = System.Drawing.Color.Transparent;
            this.panel3.CaptionFont = new System.Drawing.Font("宋体", 9.5F);
            this.panel3.CaptionHeight = 22;
            this.panel3.ColorScheme = TX.Framework.WindowUI.Controls.ColorScheme.Custom;
            this.panel3.Controls.Add(this.dgv_Cinema);
            this.panel3.CustomColors.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(168)))), ((int)(((byte)(192)))));
            this.panel3.CustomColors.CaptionCloseIcon = System.Drawing.Color.Red;
            this.panel3.CustomColors.CaptionExpandIcon = System.Drawing.SystemColors.ControlText;
            this.panel3.CustomColors.CaptionGradientBegin = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(250)))));
            this.panel3.CustomColors.CaptionGradientEnd = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(250)))));
            this.panel3.CustomColors.CaptionGradientMiddle = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(214)))), ((int)(((byte)(223)))));
            this.panel3.CustomColors.CaptionSelectedGradientBegin = System.Drawing.Color.FromArgb(((int)(((byte)(140)))), ((int)(((byte)(67)))), ((int)(((byte)(165)))), ((int)(((byte)(220)))));
            this.panel3.CustomColors.CaptionSelectedGradientEnd = System.Drawing.Color.FromArgb(((int)(((byte)(67)))), ((int)(((byte)(165)))), ((int)(((byte)(220)))));
            this.panel3.CustomColors.CaptionText = System.Drawing.SystemColors.ControlText;
            this.panel3.CustomColors.CollapsedCaptionText = System.Drawing.SystemColors.ControlText;
            this.panel3.CustomColors.ContentGradientBegin = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(247)))), ((int)(((byte)(252)))));
            this.panel3.CustomColors.ContentGradientEnd = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(247)))), ((int)(((byte)(252)))));
            this.panel3.CustomColors.InnerBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(218)))), ((int)(((byte)(222)))));
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.ForeColor = System.Drawing.SystemColors.ControlText;
            this.panel3.Image = null;
            this.panel3.Location = new System.Drawing.Point(4, 185);
            this.panel3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel3.MinimumSize = new System.Drawing.Size(29, 28);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1456, 555);
            this.panel3.TabIndex = 7;
            this.panel3.Text = "数据";
            this.panel3.ToolTipTextCloseIcon = null;
            this.panel3.ToolTipTextExpandIconPanelCollapsed = null;
            this.panel3.ToolTipTextExpandIconPanelExpanded = null;
            // 
            // dgv_Cinema
            // 
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv_Cinema.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dgv_Cinema.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgv_Cinema.DefaultCellStyle = dataGridViewCellStyle4;
            this.dgv_Cinema.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgv_Cinema.Location = new System.Drawing.Point(1, 23);
            this.dgv_Cinema.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dgv_Cinema.Name = "dgv_Cinema";
            this.dgv_Cinema.RowTemplate.Height = 23;
            this.dgv_Cinema.Size = new System.Drawing.Size(1454, 531);
            this.dgv_Cinema.TabIndex = 0;
            // 
            // panel4
            // 
            this.panel4.AssociatedSplitter = null;
            this.panel4.BackColor = System.Drawing.Color.Transparent;
            this.panel4.CaptionFont = new System.Drawing.Font("宋体", 9.5F);
            this.panel4.CaptionHeight = 30;
            this.panel4.ColorScheme = TX.Framework.WindowUI.Controls.ColorScheme.Custom;
            this.panel4.Controls.Add(this.txb_CinemaPhone);
            this.panel4.Controls.Add(this.label12);
            this.panel4.Controls.Add(this.txb_CinemaPosition);
            this.panel4.Controls.Add(this.label11);
            this.panel4.Controls.Add(this.txb_CinemaName);
            this.panel4.Controls.Add(this.label10);
            this.panel4.Controls.Add(this.txBtnCinema4);
            this.panel4.Controls.Add(this.txBtnCinema3);
            this.panel4.Controls.Add(this.txBtnCinema2);
            this.panel4.Controls.Add(this.txBtnCinema1);
            this.panel4.CustomColors.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(168)))), ((int)(((byte)(192)))));
            this.panel4.CustomColors.CaptionCloseIcon = System.Drawing.Color.Red;
            this.panel4.CustomColors.CaptionExpandIcon = System.Drawing.SystemColors.ControlText;
            this.panel4.CustomColors.CaptionGradientBegin = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(250)))));
            this.panel4.CustomColors.CaptionGradientEnd = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(250)))));
            this.panel4.CustomColors.CaptionGradientMiddle = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(214)))), ((int)(((byte)(223)))));
            this.panel4.CustomColors.CaptionSelectedGradientBegin = System.Drawing.Color.FromArgb(((int)(((byte)(140)))), ((int)(((byte)(67)))), ((int)(((byte)(165)))), ((int)(((byte)(220)))));
            this.panel4.CustomColors.CaptionSelectedGradientEnd = System.Drawing.Color.FromArgb(((int)(((byte)(67)))), ((int)(((byte)(165)))), ((int)(((byte)(220)))));
            this.panel4.CustomColors.CaptionText = System.Drawing.SystemColors.ControlText;
            this.panel4.CustomColors.CollapsedCaptionText = System.Drawing.SystemColors.ControlText;
            this.panel4.CustomColors.ContentGradientBegin = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(247)))), ((int)(((byte)(252)))));
            this.panel4.CustomColors.ContentGradientEnd = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(247)))), ((int)(((byte)(252)))));
            this.panel4.CustomColors.InnerBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(218)))), ((int)(((byte)(222)))));
            this.panel4.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel4.ForeColor = System.Drawing.SystemColors.ControlText;
            this.panel4.Image = null;
            this.panel4.Location = new System.Drawing.Point(4, 4);
            this.panel4.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel4.MinimumSize = new System.Drawing.Size(40, 38);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(1456, 181);
            this.panel4.TabIndex = 6;
            this.panel4.ToolTipTextCloseIcon = null;
            this.panel4.ToolTipTextExpandIconPanelCollapsed = null;
            this.panel4.ToolTipTextExpandIconPanelExpanded = null;
            // 
            // txb_CinemaPhone
            // 
            this.txb_CinemaPhone.BackColor = System.Drawing.Color.Transparent;
            this.txb_CinemaPhone.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(168)))), ((int)(((byte)(192)))));
            this.txb_CinemaPhone.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txb_CinemaPhone.ForeColor = System.Drawing.SystemColors.WindowText;
            this.txb_CinemaPhone.HeightLightBolorColor = System.Drawing.Color.FromArgb(((int)(((byte)(140)))), ((int)(((byte)(67)))), ((int)(((byte)(165)))), ((int)(((byte)(220)))));
            this.txb_CinemaPhone.Image = null;
            this.txb_CinemaPhone.ImageSize = new System.Drawing.Size(0, 0);
            this.txb_CinemaPhone.Location = new System.Drawing.Point(117, 128);
            this.txb_CinemaPhone.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txb_CinemaPhone.Name = "txb_CinemaPhone";
            this.txb_CinemaPhone.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txb_CinemaPhone.PasswordChar = '\0';
            this.txb_CinemaPhone.Required = false;
            this.txb_CinemaPhone.Size = new System.Drawing.Size(327, 28);
            this.txb_CinemaPhone.TabIndex = 6;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(20, 136);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(67, 15);
            this.label12.TabIndex = 5;
            this.label12.Text = "影院电话";
            // 
            // txb_CinemaPosition
            // 
            this.txb_CinemaPosition.BackColor = System.Drawing.Color.Transparent;
            this.txb_CinemaPosition.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(168)))), ((int)(((byte)(192)))));
            this.txb_CinemaPosition.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txb_CinemaPosition.ForeColor = System.Drawing.SystemColors.WindowText;
            this.txb_CinemaPosition.HeightLightBolorColor = System.Drawing.Color.FromArgb(((int)(((byte)(140)))), ((int)(((byte)(67)))), ((int)(((byte)(165)))), ((int)(((byte)(220)))));
            this.txb_CinemaPosition.Image = null;
            this.txb_CinemaPosition.ImageSize = new System.Drawing.Size(0, 0);
            this.txb_CinemaPosition.Location = new System.Drawing.Point(117, 92);
            this.txb_CinemaPosition.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txb_CinemaPosition.Name = "txb_CinemaPosition";
            this.txb_CinemaPosition.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txb_CinemaPosition.PasswordChar = '\0';
            this.txb_CinemaPosition.Required = false;
            this.txb_CinemaPosition.Size = new System.Drawing.Size(327, 28);
            this.txb_CinemaPosition.TabIndex = 6;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(20, 101);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(67, 15);
            this.label11.TabIndex = 5;
            this.label11.Text = "影院位置";
            // 
            // txb_CinemaName
            // 
            this.txb_CinemaName.BackColor = System.Drawing.Color.Transparent;
            this.txb_CinemaName.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(168)))), ((int)(((byte)(192)))));
            this.txb_CinemaName.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txb_CinemaName.ForeColor = System.Drawing.SystemColors.WindowText;
            this.txb_CinemaName.HeightLightBolorColor = System.Drawing.Color.FromArgb(((int)(((byte)(140)))), ((int)(((byte)(67)))), ((int)(((byte)(165)))), ((int)(((byte)(220)))));
            this.txb_CinemaName.Image = null;
            this.txb_CinemaName.ImageSize = new System.Drawing.Size(0, 0);
            this.txb_CinemaName.Location = new System.Drawing.Point(117, 58);
            this.txb_CinemaName.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txb_CinemaName.Name = "txb_CinemaName";
            this.txb_CinemaName.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txb_CinemaName.PasswordChar = '\0';
            this.txb_CinemaName.Required = false;
            this.txb_CinemaName.Size = new System.Drawing.Size(327, 28);
            this.txb_CinemaName.TabIndex = 6;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(20, 66);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(52, 15);
            this.label10.TabIndex = 5;
            this.label10.Text = "影院名";
            // 
            // txBtnCinema4
            // 
            this.txBtnCinema4.Image = null;
            this.txBtnCinema4.Location = new System.Drawing.Point(429, 4);
            this.txBtnCinema4.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txBtnCinema4.Name = "txBtnCinema4";
            this.txBtnCinema4.Size = new System.Drawing.Size(133, 35);
            this.txBtnCinema4.TabIndex = 0;
            this.txBtnCinema4.Text = "查询";
            this.txBtnCinema4.UseVisualStyleBackColor = true;
            this.txBtnCinema4.Click += new System.EventHandler(this.txBtnCinema4_Click);
            // 
            // txBtnCinema3
            // 
            this.txBtnCinema3.Image = null;
            this.txBtnCinema3.Location = new System.Drawing.Point(288, 4);
            this.txBtnCinema3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txBtnCinema3.Name = "txBtnCinema3";
            this.txBtnCinema3.Size = new System.Drawing.Size(133, 35);
            this.txBtnCinema3.TabIndex = 0;
            this.txBtnCinema3.Text = "删除";
            this.txBtnCinema3.UseVisualStyleBackColor = true;
            this.txBtnCinema3.Click += new System.EventHandler(this.txBtnCinema3_Click);
            // 
            // txBtnCinema2
            // 
            this.txBtnCinema2.Image = null;
            this.txBtnCinema2.Location = new System.Drawing.Point(147, 4);
            this.txBtnCinema2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txBtnCinema2.Name = "txBtnCinema2";
            this.txBtnCinema2.Size = new System.Drawing.Size(133, 35);
            this.txBtnCinema2.TabIndex = 0;
            this.txBtnCinema2.Text = "修改";
            this.txBtnCinema2.UseVisualStyleBackColor = true;
            this.txBtnCinema2.Click += new System.EventHandler(this.txBtnCinema2_Click);
            // 
            // txBtnCinema1
            // 
            this.txBtnCinema1.Image = null;
            this.txBtnCinema1.Location = new System.Drawing.Point(5, 4);
            this.txBtnCinema1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txBtnCinema1.Name = "txBtnCinema1";
            this.txBtnCinema1.Size = new System.Drawing.Size(133, 35);
            this.txBtnCinema1.TabIndex = 0;
            this.txBtnCinema1.Text = "新增";
            this.txBtnCinema1.UseVisualStyleBackColor = true;
            this.txBtnCinema1.Click += new System.EventHandler(this.txBtnCinema1_Click);
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.panel5);
            this.tabPage3.Controls.Add(this.panel6);
            this.tabPage3.Location = new System.Drawing.Point(4, 33);
            this.tabPage3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(1464, 744);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "放映厅";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // panel5
            // 
            this.panel5.AssociatedSplitter = null;
            this.panel5.BackColor = System.Drawing.Color.Transparent;
            this.panel5.CaptionFont = new System.Drawing.Font("宋体", 9.5F);
            this.panel5.CaptionHeight = 22;
            this.panel5.ColorScheme = TX.Framework.WindowUI.Controls.ColorScheme.Custom;
            this.panel5.Controls.Add(this.dgv_FilmHall);
            this.panel5.CustomColors.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(168)))), ((int)(((byte)(192)))));
            this.panel5.CustomColors.CaptionCloseIcon = System.Drawing.Color.Red;
            this.panel5.CustomColors.CaptionExpandIcon = System.Drawing.SystemColors.ControlText;
            this.panel5.CustomColors.CaptionGradientBegin = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(250)))));
            this.panel5.CustomColors.CaptionGradientEnd = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(250)))));
            this.panel5.CustomColors.CaptionGradientMiddle = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(214)))), ((int)(((byte)(223)))));
            this.panel5.CustomColors.CaptionSelectedGradientBegin = System.Drawing.Color.FromArgb(((int)(((byte)(140)))), ((int)(((byte)(67)))), ((int)(((byte)(165)))), ((int)(((byte)(220)))));
            this.panel5.CustomColors.CaptionSelectedGradientEnd = System.Drawing.Color.FromArgb(((int)(((byte)(67)))), ((int)(((byte)(165)))), ((int)(((byte)(220)))));
            this.panel5.CustomColors.CaptionText = System.Drawing.SystemColors.ControlText;
            this.panel5.CustomColors.CollapsedCaptionText = System.Drawing.SystemColors.ControlText;
            this.panel5.CustomColors.ContentGradientBegin = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(247)))), ((int)(((byte)(252)))));
            this.panel5.CustomColors.ContentGradientEnd = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(247)))), ((int)(((byte)(252)))));
            this.panel5.CustomColors.InnerBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(218)))), ((int)(((byte)(222)))));
            this.panel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel5.ForeColor = System.Drawing.SystemColors.ControlText;
            this.panel5.Image = null;
            this.panel5.Location = new System.Drawing.Point(0, 181);
            this.panel5.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel5.MinimumSize = new System.Drawing.Size(29, 28);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(1464, 563);
            this.panel5.TabIndex = 5;
            this.panel5.Text = "数据";
            this.panel5.ToolTipTextCloseIcon = null;
            this.panel5.ToolTipTextExpandIconPanelCollapsed = null;
            this.panel5.ToolTipTextExpandIconPanelExpanded = null;
            // 
            // dgv_FilmHall
            // 
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv_FilmHall.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle5;
            this.dgv_FilmHall.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgv_FilmHall.DefaultCellStyle = dataGridViewCellStyle6;
            this.dgv_FilmHall.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgv_FilmHall.Location = new System.Drawing.Point(1, 23);
            this.dgv_FilmHall.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dgv_FilmHall.Name = "dgv_FilmHall";
            this.dgv_FilmHall.RowTemplate.Height = 23;
            this.dgv_FilmHall.Size = new System.Drawing.Size(1462, 539);
            this.dgv_FilmHall.TabIndex = 0;
            // 
            // panel6
            // 
            this.panel6.AssociatedSplitter = null;
            this.panel6.BackColor = System.Drawing.Color.Transparent;
            this.panel6.CaptionFont = new System.Drawing.Font("宋体", 9.5F);
            this.panel6.CaptionHeight = 30;
            this.panel6.ColorScheme = TX.Framework.WindowUI.Controls.ColorScheme.Custom;
            this.panel6.Controls.Add(this.txb_SeatCnt);
            this.panel6.Controls.Add(this.label13);
            this.panel6.Controls.Add(this.txb_FilmHallName);
            this.panel6.Controls.Add(this.label14);
            this.panel6.Controls.Add(this.txb_FilmHallID);
            this.panel6.Controls.Add(this.label15);
            this.panel6.Controls.Add(this.txBtnFilmHall4);
            this.panel6.Controls.Add(this.txBtnFilmHall3);
            this.panel6.Controls.Add(this.txBtnFilmHall2);
            this.panel6.Controls.Add(this.txBtnFilmHall1);
            this.panel6.CustomColors.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(168)))), ((int)(((byte)(192)))));
            this.panel6.CustomColors.CaptionCloseIcon = System.Drawing.Color.Red;
            this.panel6.CustomColors.CaptionExpandIcon = System.Drawing.SystemColors.ControlText;
            this.panel6.CustomColors.CaptionGradientBegin = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(250)))));
            this.panel6.CustomColors.CaptionGradientEnd = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(250)))));
            this.panel6.CustomColors.CaptionGradientMiddle = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(214)))), ((int)(((byte)(223)))));
            this.panel6.CustomColors.CaptionSelectedGradientBegin = System.Drawing.Color.FromArgb(((int)(((byte)(140)))), ((int)(((byte)(67)))), ((int)(((byte)(165)))), ((int)(((byte)(220)))));
            this.panel6.CustomColors.CaptionSelectedGradientEnd = System.Drawing.Color.FromArgb(((int)(((byte)(67)))), ((int)(((byte)(165)))), ((int)(((byte)(220)))));
            this.panel6.CustomColors.CaptionText = System.Drawing.SystemColors.ControlText;
            this.panel6.CustomColors.CollapsedCaptionText = System.Drawing.SystemColors.ControlText;
            this.panel6.CustomColors.ContentGradientBegin = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(247)))), ((int)(((byte)(252)))));
            this.panel6.CustomColors.ContentGradientEnd = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(247)))), ((int)(((byte)(252)))));
            this.panel6.CustomColors.InnerBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(218)))), ((int)(((byte)(222)))));
            this.panel6.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel6.ForeColor = System.Drawing.SystemColors.ControlText;
            this.panel6.Image = null;
            this.panel6.Location = new System.Drawing.Point(0, 0);
            this.panel6.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel6.MinimumSize = new System.Drawing.Size(40, 38);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(1464, 181);
            this.panel6.TabIndex = 4;
            this.panel6.ToolTipTextCloseIcon = null;
            this.panel6.ToolTipTextExpandIconPanelCollapsed = null;
            this.panel6.ToolTipTextExpandIconPanelExpanded = null;
            // 
            // txb_SeatCnt
            // 
            this.txb_SeatCnt.BackColor = System.Drawing.Color.Transparent;
            this.txb_SeatCnt.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(168)))), ((int)(((byte)(192)))));
            this.txb_SeatCnt.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txb_SeatCnt.ForeColor = System.Drawing.SystemColors.WindowText;
            this.txb_SeatCnt.HeightLightBolorColor = System.Drawing.Color.FromArgb(((int)(((byte)(140)))), ((int)(((byte)(67)))), ((int)(((byte)(165)))), ((int)(((byte)(220)))));
            this.txb_SeatCnt.Image = null;
            this.txb_SeatCnt.ImageSize = new System.Drawing.Size(0, 0);
            this.txb_SeatCnt.Location = new System.Drawing.Point(135, 128);
            this.txb_SeatCnt.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txb_SeatCnt.Name = "txb_SeatCnt";
            this.txb_SeatCnt.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txb_SeatCnt.PasswordChar = '\0';
            this.txb_SeatCnt.Required = false;
            this.txb_SeatCnt.Size = new System.Drawing.Size(327, 28);
            this.txb_SeatCnt.TabIndex = 10;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(37, 136);
            this.label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(52, 15);
            this.label13.TabIndex = 8;
            this.label13.Text = "座位数";
            // 
            // txb_FilmHallName
            // 
            this.txb_FilmHallName.BackColor = System.Drawing.Color.Transparent;
            this.txb_FilmHallName.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(168)))), ((int)(((byte)(192)))));
            this.txb_FilmHallName.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txb_FilmHallName.ForeColor = System.Drawing.SystemColors.WindowText;
            this.txb_FilmHallName.HeightLightBolorColor = System.Drawing.Color.FromArgb(((int)(((byte)(140)))), ((int)(((byte)(67)))), ((int)(((byte)(165)))), ((int)(((byte)(220)))));
            this.txb_FilmHallName.Image = null;
            this.txb_FilmHallName.ImageSize = new System.Drawing.Size(0, 0);
            this.txb_FilmHallName.Location = new System.Drawing.Point(135, 92);
            this.txb_FilmHallName.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txb_FilmHallName.Name = "txb_FilmHallName";
            this.txb_FilmHallName.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txb_FilmHallName.PasswordChar = '\0';
            this.txb_FilmHallName.Required = false;
            this.txb_FilmHallName.Size = new System.Drawing.Size(327, 28);
            this.txb_FilmHallName.TabIndex = 12;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(37, 101);
            this.label14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(82, 15);
            this.label14.TabIndex = 7;
            this.label14.Text = "放映厅名称";
            // 
            // txb_FilmHallID
            // 
            this.txb_FilmHallID.BackColor = System.Drawing.Color.Transparent;
            this.txb_FilmHallID.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(168)))), ((int)(((byte)(192)))));
            this.txb_FilmHallID.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txb_FilmHallID.ForeColor = System.Drawing.SystemColors.WindowText;
            this.txb_FilmHallID.HeightLightBolorColor = System.Drawing.Color.FromArgb(((int)(((byte)(140)))), ((int)(((byte)(67)))), ((int)(((byte)(165)))), ((int)(((byte)(220)))));
            this.txb_FilmHallID.Image = null;
            this.txb_FilmHallID.ImageSize = new System.Drawing.Size(0, 0);
            this.txb_FilmHallID.Location = new System.Drawing.Point(135, 58);
            this.txb_FilmHallID.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txb_FilmHallID.Name = "txb_FilmHallID";
            this.txb_FilmHallID.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txb_FilmHallID.PasswordChar = '\0';
            this.txb_FilmHallID.Required = false;
            this.txb_FilmHallID.Size = new System.Drawing.Size(327, 28);
            this.txb_FilmHallID.TabIndex = 11;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(37, 66);
            this.label15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(82, 15);
            this.label15.TabIndex = 9;
            this.label15.Text = "放映厅编号";
            // 
            // txBtnFilmHall4
            // 
            this.txBtnFilmHall4.Image = null;
            this.txBtnFilmHall4.Location = new System.Drawing.Point(429, 4);
            this.txBtnFilmHall4.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txBtnFilmHall4.Name = "txBtnFilmHall4";
            this.txBtnFilmHall4.Size = new System.Drawing.Size(133, 35);
            this.txBtnFilmHall4.TabIndex = 0;
            this.txBtnFilmHall4.Text = "查询";
            this.txBtnFilmHall4.UseVisualStyleBackColor = true;
            this.txBtnFilmHall4.Click += new System.EventHandler(this.txBtnFilmHall4_Click);
            // 
            // txBtnFilmHall3
            // 
            this.txBtnFilmHall3.Image = null;
            this.txBtnFilmHall3.Location = new System.Drawing.Point(288, 4);
            this.txBtnFilmHall3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txBtnFilmHall3.Name = "txBtnFilmHall3";
            this.txBtnFilmHall3.Size = new System.Drawing.Size(133, 35);
            this.txBtnFilmHall3.TabIndex = 0;
            this.txBtnFilmHall3.Text = "删除";
            this.txBtnFilmHall3.UseVisualStyleBackColor = true;
            this.txBtnFilmHall3.Click += new System.EventHandler(this.txBtnFilmHall3_Click);
            // 
            // txBtnFilmHall2
            // 
            this.txBtnFilmHall2.Image = null;
            this.txBtnFilmHall2.Location = new System.Drawing.Point(147, 4);
            this.txBtnFilmHall2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txBtnFilmHall2.Name = "txBtnFilmHall2";
            this.txBtnFilmHall2.Size = new System.Drawing.Size(133, 35);
            this.txBtnFilmHall2.TabIndex = 0;
            this.txBtnFilmHall2.Text = "修改";
            this.txBtnFilmHall2.UseVisualStyleBackColor = true;
            this.txBtnFilmHall2.Click += new System.EventHandler(this.txBtnFilmHall2_Click);
            // 
            // txBtnFilmHall1
            // 
            this.txBtnFilmHall1.Image = null;
            this.txBtnFilmHall1.Location = new System.Drawing.Point(5, 4);
            this.txBtnFilmHall1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txBtnFilmHall1.Name = "txBtnFilmHall1";
            this.txBtnFilmHall1.Size = new System.Drawing.Size(133, 35);
            this.txBtnFilmHall1.TabIndex = 0;
            this.txBtnFilmHall1.Text = "新增";
            this.txBtnFilmHall1.UseVisualStyleBackColor = true;
            this.txBtnFilmHall1.Click += new System.EventHandler(this.txBtnFilmHall1_Click);
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.panel7);
            this.tabPage4.Controls.Add(this.panel8);
            this.tabPage4.Location = new System.Drawing.Point(4, 33);
            this.tabPage4.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(1464, 744);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "会员";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // panel7
            // 
            this.panel7.AssociatedSplitter = null;
            this.panel7.BackColor = System.Drawing.Color.Transparent;
            this.panel7.CaptionFont = new System.Drawing.Font("宋体", 9.5F);
            this.panel7.CaptionHeight = 22;
            this.panel7.ColorScheme = TX.Framework.WindowUI.Controls.ColorScheme.Custom;
            this.panel7.Controls.Add(this.dgv_MemberTB);
            this.panel7.CustomColors.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(168)))), ((int)(((byte)(192)))));
            this.panel7.CustomColors.CaptionCloseIcon = System.Drawing.Color.Red;
            this.panel7.CustomColors.CaptionExpandIcon = System.Drawing.SystemColors.ControlText;
            this.panel7.CustomColors.CaptionGradientBegin = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(250)))));
            this.panel7.CustomColors.CaptionGradientEnd = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(250)))));
            this.panel7.CustomColors.CaptionGradientMiddle = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(214)))), ((int)(((byte)(223)))));
            this.panel7.CustomColors.CaptionSelectedGradientBegin = System.Drawing.Color.FromArgb(((int)(((byte)(140)))), ((int)(((byte)(67)))), ((int)(((byte)(165)))), ((int)(((byte)(220)))));
            this.panel7.CustomColors.CaptionSelectedGradientEnd = System.Drawing.Color.FromArgb(((int)(((byte)(67)))), ((int)(((byte)(165)))), ((int)(((byte)(220)))));
            this.panel7.CustomColors.CaptionText = System.Drawing.SystemColors.ControlText;
            this.panel7.CustomColors.CollapsedCaptionText = System.Drawing.SystemColors.ControlText;
            this.panel7.CustomColors.ContentGradientBegin = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(247)))), ((int)(((byte)(252)))));
            this.panel7.CustomColors.ContentGradientEnd = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(247)))), ((int)(((byte)(252)))));
            this.panel7.CustomColors.InnerBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(218)))), ((int)(((byte)(222)))));
            this.panel7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel7.ForeColor = System.Drawing.SystemColors.ControlText;
            this.panel7.Image = null;
            this.panel7.Location = new System.Drawing.Point(0, 181);
            this.panel7.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel7.MinimumSize = new System.Drawing.Size(29, 28);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(1464, 563);
            this.panel7.TabIndex = 3;
            this.panel7.Text = "数量列表";
            this.panel7.ToolTipTextCloseIcon = null;
            this.panel7.ToolTipTextExpandIconPanelCollapsed = null;
            this.panel7.ToolTipTextExpandIconPanelExpanded = null;
            // 
            // dgv_MemberTB
            // 
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle7.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv_MemberTB.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle7;
            this.dgv_MemberTB.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgv_MemberTB.DefaultCellStyle = dataGridViewCellStyle8;
            this.dgv_MemberTB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgv_MemberTB.Location = new System.Drawing.Point(1, 23);
            this.dgv_MemberTB.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dgv_MemberTB.Name = "dgv_MemberTB";
            this.dgv_MemberTB.RowTemplate.Height = 23;
            this.dgv_MemberTB.Size = new System.Drawing.Size(1462, 539);
            this.dgv_MemberTB.TabIndex = 0;
            // 
            // panel8
            // 
            this.panel8.AssociatedSplitter = null;
            this.panel8.BackColor = System.Drawing.Color.Transparent;
            this.panel8.CaptionFont = new System.Drawing.Font("宋体", 9.5F);
            this.panel8.CaptionHeight = 30;
            this.panel8.ColorScheme = TX.Framework.WindowUI.Controls.ColorScheme.Custom;
            this.panel8.Controls.Add(this.txb_MemberPsw);
            this.panel8.Controls.Add(this.txb_Phone);
            this.panel8.Controls.Add(this.label4);
            this.panel8.Controls.Add(this.label3);
            this.panel8.Controls.Add(this.txBtn_Member4);
            this.panel8.Controls.Add(this.txBtn_Member3);
            this.panel8.Controls.Add(this.txBtn_Member2);
            this.panel8.Controls.Add(this.txBtn_Member1);
            this.panel8.CustomColors.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(168)))), ((int)(((byte)(192)))));
            this.panel8.CustomColors.CaptionCloseIcon = System.Drawing.Color.Red;
            this.panel8.CustomColors.CaptionExpandIcon = System.Drawing.SystemColors.ControlText;
            this.panel8.CustomColors.CaptionGradientBegin = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(250)))));
            this.panel8.CustomColors.CaptionGradientEnd = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(250)))));
            this.panel8.CustomColors.CaptionGradientMiddle = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(214)))), ((int)(((byte)(223)))));
            this.panel8.CustomColors.CaptionSelectedGradientBegin = System.Drawing.Color.FromArgb(((int)(((byte)(140)))), ((int)(((byte)(67)))), ((int)(((byte)(165)))), ((int)(((byte)(220)))));
            this.panel8.CustomColors.CaptionSelectedGradientEnd = System.Drawing.Color.FromArgb(((int)(((byte)(67)))), ((int)(((byte)(165)))), ((int)(((byte)(220)))));
            this.panel8.CustomColors.CaptionText = System.Drawing.SystemColors.ControlText;
            this.panel8.CustomColors.CollapsedCaptionText = System.Drawing.SystemColors.ControlText;
            this.panel8.CustomColors.ContentGradientBegin = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(247)))), ((int)(((byte)(252)))));
            this.panel8.CustomColors.ContentGradientEnd = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(247)))), ((int)(((byte)(252)))));
            this.panel8.CustomColors.InnerBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(218)))), ((int)(((byte)(222)))));
            this.panel8.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel8.ForeColor = System.Drawing.SystemColors.ControlText;
            this.panel8.Image = null;
            this.panel8.Location = new System.Drawing.Point(0, 0);
            this.panel8.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel8.MinimumSize = new System.Drawing.Size(40, 38);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(1464, 181);
            this.panel8.TabIndex = 2;
            this.panel8.ToolTipTextCloseIcon = null;
            this.panel8.ToolTipTextExpandIconPanelCollapsed = null;
            this.panel8.ToolTipTextExpandIconPanelExpanded = null;
            // 
            // txb_MemberPsw
            // 
            this.txb_MemberPsw.BackColor = System.Drawing.Color.Transparent;
            this.txb_MemberPsw.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(168)))), ((int)(((byte)(192)))));
            this.txb_MemberPsw.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txb_MemberPsw.ForeColor = System.Drawing.SystemColors.WindowText;
            this.txb_MemberPsw.HeightLightBolorColor = System.Drawing.Color.FromArgb(((int)(((byte)(140)))), ((int)(((byte)(67)))), ((int)(((byte)(165)))), ((int)(((byte)(220)))));
            this.txb_MemberPsw.Image = null;
            this.txb_MemberPsw.ImageSize = new System.Drawing.Size(0, 0);
            this.txb_MemberPsw.Location = new System.Drawing.Point(147, 102);
            this.txb_MemberPsw.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txb_MemberPsw.Name = "txb_MemberPsw";
            this.txb_MemberPsw.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txb_MemberPsw.PasswordChar = '\0';
            this.txb_MemberPsw.Required = false;
            this.txb_MemberPsw.Size = new System.Drawing.Size(240, 28);
            this.txb_MemberPsw.TabIndex = 2;
            // 
            // txb_Phone
            // 
            this.txb_Phone.BackColor = System.Drawing.Color.Transparent;
            this.txb_Phone.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(168)))), ((int)(((byte)(192)))));
            this.txb_Phone.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txb_Phone.ForeColor = System.Drawing.SystemColors.WindowText;
            this.txb_Phone.HeightLightBolorColor = System.Drawing.Color.FromArgb(((int)(((byte)(140)))), ((int)(((byte)(67)))), ((int)(((byte)(165)))), ((int)(((byte)(220)))));
            this.txb_Phone.Image = null;
            this.txb_Phone.ImageSize = new System.Drawing.Size(0, 0);
            this.txb_Phone.Location = new System.Drawing.Point(147, 69);
            this.txb_Phone.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txb_Phone.Name = "txb_Phone";
            this.txb_Phone.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txb_Phone.PasswordChar = '\0';
            this.txb_Phone.Required = false;
            this.txb_Phone.Size = new System.Drawing.Size(240, 28);
            this.txb_Phone.TabIndex = 2;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(49, 111);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(37, 15);
            this.label4.TabIndex = 1;
            this.label4.Text = "密码";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(49, 78);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(37, 15);
            this.label3.TabIndex = 1;
            this.label3.Text = "手机";
            // 
            // txBtn_Member4
            // 
            this.txBtn_Member4.Image = null;
            this.txBtn_Member4.Location = new System.Drawing.Point(429, 4);
            this.txBtn_Member4.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txBtn_Member4.Name = "txBtn_Member4";
            this.txBtn_Member4.Size = new System.Drawing.Size(133, 35);
            this.txBtn_Member4.TabIndex = 0;
            this.txBtn_Member4.Text = "查询";
            this.txBtn_Member4.UseVisualStyleBackColor = true;
            this.txBtn_Member4.Click += new System.EventHandler(this.txBtn_Member4_Click);
            // 
            // txBtn_Member3
            // 
            this.txBtn_Member3.Image = null;
            this.txBtn_Member3.Location = new System.Drawing.Point(288, 4);
            this.txBtn_Member3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txBtn_Member3.Name = "txBtn_Member3";
            this.txBtn_Member3.Size = new System.Drawing.Size(133, 35);
            this.txBtn_Member3.TabIndex = 0;
            this.txBtn_Member3.Text = "删除";
            this.txBtn_Member3.UseVisualStyleBackColor = true;
            this.txBtn_Member3.Click += new System.EventHandler(this.txBtn_Member3_Click);
            // 
            // txBtn_Member2
            // 
            this.txBtn_Member2.Image = null;
            this.txBtn_Member2.Location = new System.Drawing.Point(147, 4);
            this.txBtn_Member2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txBtn_Member2.Name = "txBtn_Member2";
            this.txBtn_Member2.Size = new System.Drawing.Size(133, 35);
            this.txBtn_Member2.TabIndex = 0;
            this.txBtn_Member2.Text = "修改";
            this.txBtn_Member2.UseVisualStyleBackColor = true;
            this.txBtn_Member2.Click += new System.EventHandler(this.txBtn_Member2_Click);
            // 
            // txBtn_Member1
            // 
            this.txBtn_Member1.Image = null;
            this.txBtn_Member1.Location = new System.Drawing.Point(5, 4);
            this.txBtn_Member1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txBtn_Member1.Name = "txBtn_Member1";
            this.txBtn_Member1.Size = new System.Drawing.Size(133, 35);
            this.txBtn_Member1.TabIndex = 0;
            this.txBtn_Member1.Text = "新增";
            this.txBtn_Member1.UseVisualStyleBackColor = true;
            this.txBtn_Member1.Click += new System.EventHandler(this.txBtn_Member1_Click);
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.panel9);
            this.tabPage5.Controls.Add(this.panel10);
            this.tabPage5.Location = new System.Drawing.Point(4, 33);
            this.tabPage5.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Size = new System.Drawing.Size(1464, 744);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "管理员";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // panel9
            // 
            this.panel9.AssociatedSplitter = null;
            this.panel9.BackColor = System.Drawing.Color.Transparent;
            this.panel9.CaptionFont = new System.Drawing.Font("宋体", 9.5F);
            this.panel9.CaptionHeight = 22;
            this.panel9.ColorScheme = TX.Framework.WindowUI.Controls.ColorScheme.Custom;
            this.panel9.Controls.Add(this.dgv_AdminTB);
            this.panel9.CustomColors.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(168)))), ((int)(((byte)(192)))));
            this.panel9.CustomColors.CaptionCloseIcon = System.Drawing.Color.Red;
            this.panel9.CustomColors.CaptionExpandIcon = System.Drawing.SystemColors.ControlText;
            this.panel9.CustomColors.CaptionGradientBegin = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(250)))));
            this.panel9.CustomColors.CaptionGradientEnd = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(250)))));
            this.panel9.CustomColors.CaptionGradientMiddle = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(214)))), ((int)(((byte)(223)))));
            this.panel9.CustomColors.CaptionSelectedGradientBegin = System.Drawing.Color.FromArgb(((int)(((byte)(140)))), ((int)(((byte)(67)))), ((int)(((byte)(165)))), ((int)(((byte)(220)))));
            this.panel9.CustomColors.CaptionSelectedGradientEnd = System.Drawing.Color.FromArgb(((int)(((byte)(67)))), ((int)(((byte)(165)))), ((int)(((byte)(220)))));
            this.panel9.CustomColors.CaptionText = System.Drawing.SystemColors.ControlText;
            this.panel9.CustomColors.CollapsedCaptionText = System.Drawing.SystemColors.ControlText;
            this.panel9.CustomColors.ContentGradientBegin = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(247)))), ((int)(((byte)(252)))));
            this.panel9.CustomColors.ContentGradientEnd = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(247)))), ((int)(((byte)(252)))));
            this.panel9.CustomColors.InnerBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(218)))), ((int)(((byte)(222)))));
            this.panel9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel9.ForeColor = System.Drawing.SystemColors.ControlText;
            this.panel9.Image = null;
            this.panel9.Location = new System.Drawing.Point(0, 154);
            this.panel9.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel9.MinimumSize = new System.Drawing.Size(29, 28);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(1464, 590);
            this.panel9.TabIndex = 3;
            this.panel9.Text = "数量列表";
            this.panel9.ToolTipTextCloseIcon = null;
            this.panel9.ToolTipTextExpandIconPanelCollapsed = null;
            this.panel9.ToolTipTextExpandIconPanelExpanded = null;
            // 
            // dgv_AdminTB
            // 
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle9.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle9.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle9.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv_AdminTB.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle9;
            this.dgv_AdminTB.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle10.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle10.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle10.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle10.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle10.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgv_AdminTB.DefaultCellStyle = dataGridViewCellStyle10;
            this.dgv_AdminTB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgv_AdminTB.Location = new System.Drawing.Point(1, 23);
            this.dgv_AdminTB.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dgv_AdminTB.Name = "dgv_AdminTB";
            this.dgv_AdminTB.RowTemplate.Height = 23;
            this.dgv_AdminTB.Size = new System.Drawing.Size(1462, 566);
            this.dgv_AdminTB.TabIndex = 0;
            // 
            // panel10
            // 
            this.panel10.AssociatedSplitter = null;
            this.panel10.BackColor = System.Drawing.Color.Transparent;
            this.panel10.CaptionFont = new System.Drawing.Font("宋体", 9.5F);
            this.panel10.CaptionHeight = 30;
            this.panel10.ColorScheme = TX.Framework.WindowUI.Controls.ColorScheme.Custom;
            this.panel10.Controls.Add(this.label2);
            this.panel10.Controls.Add(this.label1);
            this.panel10.Controls.Add(this.txb_Psw);
            this.panel10.Controls.Add(this.txb_UserName);
            this.panel10.Controls.Add(this.txBtnAdmin4);
            this.panel10.Controls.Add(this.txBtnAdmin3);
            this.panel10.Controls.Add(this.txBtnAdmin2);
            this.panel10.Controls.Add(this.txBtnAdmin1);
            this.panel10.CustomColors.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(168)))), ((int)(((byte)(192)))));
            this.panel10.CustomColors.CaptionCloseIcon = System.Drawing.Color.Red;
            this.panel10.CustomColors.CaptionExpandIcon = System.Drawing.SystemColors.ControlText;
            this.panel10.CustomColors.CaptionGradientBegin = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(250)))));
            this.panel10.CustomColors.CaptionGradientEnd = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(250)))));
            this.panel10.CustomColors.CaptionGradientMiddle = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(214)))), ((int)(((byte)(223)))));
            this.panel10.CustomColors.CaptionSelectedGradientBegin = System.Drawing.Color.FromArgb(((int)(((byte)(140)))), ((int)(((byte)(67)))), ((int)(((byte)(165)))), ((int)(((byte)(220)))));
            this.panel10.CustomColors.CaptionSelectedGradientEnd = System.Drawing.Color.FromArgb(((int)(((byte)(67)))), ((int)(((byte)(165)))), ((int)(((byte)(220)))));
            this.panel10.CustomColors.CaptionText = System.Drawing.SystemColors.ControlText;
            this.panel10.CustomColors.CollapsedCaptionText = System.Drawing.SystemColors.ControlText;
            this.panel10.CustomColors.ContentGradientBegin = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(247)))), ((int)(((byte)(252)))));
            this.panel10.CustomColors.ContentGradientEnd = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(247)))), ((int)(((byte)(252)))));
            this.panel10.CustomColors.InnerBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(218)))), ((int)(((byte)(222)))));
            this.panel10.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel10.ForeColor = System.Drawing.SystemColors.ControlText;
            this.panel10.Image = null;
            this.panel10.Location = new System.Drawing.Point(0, 0);
            this.panel10.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel10.MinimumSize = new System.Drawing.Size(40, 38);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(1464, 154);
            this.panel10.TabIndex = 2;
            this.panel10.ToolTipTextCloseIcon = null;
            this.panel10.ToolTipTextExpandIconPanelCollapsed = null;
            this.panel10.ToolTipTextExpandIconPanelExpanded = null;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(52, 108);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(37, 15);
            this.label2.TabIndex = 2;
            this.label2.Text = "密码";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(52, 72);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(52, 15);
            this.label1.TabIndex = 2;
            this.label1.Text = "用户名";
            // 
            // txb_Psw
            // 
            this.txb_Psw.BackColor = System.Drawing.Color.Transparent;
            this.txb_Psw.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(168)))), ((int)(((byte)(192)))));
            this.txb_Psw.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txb_Psw.ForeColor = System.Drawing.SystemColors.WindowText;
            this.txb_Psw.HeightLightBolorColor = System.Drawing.Color.FromArgb(((int)(((byte)(140)))), ((int)(((byte)(67)))), ((int)(((byte)(165)))), ((int)(((byte)(220)))));
            this.txb_Psw.Image = null;
            this.txb_Psw.ImageSize = new System.Drawing.Size(0, 0);
            this.txb_Psw.Location = new System.Drawing.Point(147, 96);
            this.txb_Psw.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txb_Psw.Name = "txb_Psw";
            this.txb_Psw.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txb_Psw.PasswordChar = '\0';
            this.txb_Psw.Required = false;
            this.txb_Psw.Size = new System.Drawing.Size(240, 28);
            this.txb_Psw.TabIndex = 1;
            // 
            // txb_UserName
            // 
            this.txb_UserName.BackColor = System.Drawing.Color.Transparent;
            this.txb_UserName.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(168)))), ((int)(((byte)(192)))));
            this.txb_UserName.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txb_UserName.ForeColor = System.Drawing.SystemColors.WindowText;
            this.txb_UserName.HeightLightBolorColor = System.Drawing.Color.FromArgb(((int)(((byte)(140)))), ((int)(((byte)(67)))), ((int)(((byte)(165)))), ((int)(((byte)(220)))));
            this.txb_UserName.Image = null;
            this.txb_UserName.ImageSize = new System.Drawing.Size(0, 0);
            this.txb_UserName.Location = new System.Drawing.Point(147, 61);
            this.txb_UserName.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txb_UserName.Name = "txb_UserName";
            this.txb_UserName.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txb_UserName.PasswordChar = '\0';
            this.txb_UserName.Required = false;
            this.txb_UserName.Size = new System.Drawing.Size(240, 28);
            this.txb_UserName.TabIndex = 1;
            // 
            // txBtnAdmin4
            // 
            this.txBtnAdmin4.Image = null;
            this.txBtnAdmin4.Location = new System.Drawing.Point(429, 4);
            this.txBtnAdmin4.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txBtnAdmin4.Name = "txBtnAdmin4";
            this.txBtnAdmin4.Size = new System.Drawing.Size(133, 35);
            this.txBtnAdmin4.TabIndex = 0;
            this.txBtnAdmin4.Text = "查询";
            this.txBtnAdmin4.UseVisualStyleBackColor = true;
            this.txBtnAdmin4.Click += new System.EventHandler(this.txBtnAdmin4_Click);
            // 
            // txBtnAdmin3
            // 
            this.txBtnAdmin3.Image = null;
            this.txBtnAdmin3.Location = new System.Drawing.Point(288, 4);
            this.txBtnAdmin3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txBtnAdmin3.Name = "txBtnAdmin3";
            this.txBtnAdmin3.Size = new System.Drawing.Size(133, 35);
            this.txBtnAdmin3.TabIndex = 0;
            this.txBtnAdmin3.Text = "删除";
            this.txBtnAdmin3.UseVisualStyleBackColor = true;
            this.txBtnAdmin3.Click += new System.EventHandler(this.txBtnAdmin3_Click);
            // 
            // txBtnAdmin2
            // 
            this.txBtnAdmin2.Image = null;
            this.txBtnAdmin2.Location = new System.Drawing.Point(147, 4);
            this.txBtnAdmin2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txBtnAdmin2.Name = "txBtnAdmin2";
            this.txBtnAdmin2.Size = new System.Drawing.Size(133, 35);
            this.txBtnAdmin2.TabIndex = 0;
            this.txBtnAdmin2.Text = "修改";
            this.txBtnAdmin2.UseVisualStyleBackColor = true;
            this.txBtnAdmin2.Click += new System.EventHandler(this.txBtnAdmin2_Click);
            // 
            // txBtnAdmin1
            // 
            this.txBtnAdmin1.Image = null;
            this.txBtnAdmin1.Location = new System.Drawing.Point(5, 4);
            this.txBtnAdmin1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txBtnAdmin1.Name = "txBtnAdmin1";
            this.txBtnAdmin1.Size = new System.Drawing.Size(133, 35);
            this.txBtnAdmin1.TabIndex = 0;
            this.txBtnAdmin1.Text = "新增";
            this.txBtnAdmin1.UseVisualStyleBackColor = true;
            this.txBtnAdmin1.Click += new System.EventHandler(this.txBtnAdmin1_Click);
            // 
            // tabPage6
            // 
            this.tabPage6.Controls.Add(this.panel12);
            this.tabPage6.Controls.Add(this.panel11);
            this.tabPage6.Location = new System.Drawing.Point(4, 33);
            this.tabPage6.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Size = new System.Drawing.Size(1464, 744);
            this.tabPage6.TabIndex = 5;
            this.tabPage6.Text = "放映电影集合";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // panel12
            // 
            this.panel12.AssociatedSplitter = null;
            this.panel12.BackColor = System.Drawing.Color.Transparent;
            this.panel12.CaptionFont = new System.Drawing.Font("宋体", 9.5F);
            this.panel12.CaptionHeight = 22;
            this.panel12.ColorScheme = TX.Framework.WindowUI.Controls.ColorScheme.Custom;
            this.panel12.CustomColors.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(168)))), ((int)(((byte)(192)))));
            this.panel12.CustomColors.CaptionCloseIcon = System.Drawing.Color.Red;
            this.panel12.CustomColors.CaptionExpandIcon = System.Drawing.SystemColors.ControlText;
            this.panel12.CustomColors.CaptionGradientBegin = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(250)))));
            this.panel12.CustomColors.CaptionGradientEnd = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(250)))));
            this.panel12.CustomColors.CaptionGradientMiddle = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(214)))), ((int)(((byte)(223)))));
            this.panel12.CustomColors.CaptionSelectedGradientBegin = System.Drawing.Color.FromArgb(((int)(((byte)(140)))), ((int)(((byte)(67)))), ((int)(((byte)(165)))), ((int)(((byte)(220)))));
            this.panel12.CustomColors.CaptionSelectedGradientEnd = System.Drawing.Color.FromArgb(((int)(((byte)(67)))), ((int)(((byte)(165)))), ((int)(((byte)(220)))));
            this.panel12.CustomColors.CaptionText = System.Drawing.SystemColors.ControlText;
            this.panel12.CustomColors.CollapsedCaptionText = System.Drawing.SystemColors.ControlText;
            this.panel12.CustomColors.ContentGradientBegin = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(247)))), ((int)(((byte)(252)))));
            this.panel12.CustomColors.ContentGradientEnd = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(247)))), ((int)(((byte)(252)))));
            this.panel12.CustomColors.InnerBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(218)))), ((int)(((byte)(222)))));
            this.panel12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel12.ForeColor = System.Drawing.SystemColors.ControlText;
            this.panel12.Image = null;
            this.panel12.Location = new System.Drawing.Point(0, 231);
            this.panel12.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel12.MinimumSize = new System.Drawing.Size(29, 28);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(1464, 513);
            this.panel12.TabIndex = 1;
            this.panel12.ToolTipTextCloseIcon = null;
            this.panel12.ToolTipTextExpandIconPanelCollapsed = null;
            this.panel12.ToolTipTextExpandIconPanelExpanded = null;
            // 
            // panel11
            // 
            this.panel11.AssociatedSplitter = null;
            this.panel11.BackColor = System.Drawing.Color.Transparent;
            this.panel11.CaptionFont = new System.Drawing.Font("宋体", 9.5F);
            this.panel11.CaptionHeight = 22;
            this.panel11.ColorScheme = TX.Framework.WindowUI.Controls.ColorScheme.Custom;
            this.panel11.Controls.Add(this.pictureBox1);
            this.panel11.Controls.Add(this.btn删除影片);
            this.panel11.Controls.Add(this.btn录入影片);
            this.panel11.Controls.Add(this.textBox1);
            this.panel11.Controls.Add(this.label21);
            this.panel11.Controls.Add(this.label20);
            this.panel11.Controls.Add(this.dateTimePicker1);
            this.panel11.Controls.Add(this.label19);
            this.panel11.Controls.Add(this.comboBox3);
            this.panel11.Controls.Add(this.comboBox2);
            this.panel11.Controls.Add(this.comboBox1);
            this.panel11.Controls.Add(this.txTextBox1);
            this.panel11.Controls.Add(this.label18);
            this.panel11.Controls.Add(this.label17);
            this.panel11.Controls.Add(this.label16);
            this.panel11.CustomColors.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(168)))), ((int)(((byte)(192)))));
            this.panel11.CustomColors.CaptionCloseIcon = System.Drawing.Color.Red;
            this.panel11.CustomColors.CaptionExpandIcon = System.Drawing.SystemColors.ControlText;
            this.panel11.CustomColors.CaptionGradientBegin = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(250)))));
            this.panel11.CustomColors.CaptionGradientEnd = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(250)))));
            this.panel11.CustomColors.CaptionGradientMiddle = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(214)))), ((int)(((byte)(223)))));
            this.panel11.CustomColors.CaptionSelectedGradientBegin = System.Drawing.Color.FromArgb(((int)(((byte)(140)))), ((int)(((byte)(67)))), ((int)(((byte)(165)))), ((int)(((byte)(220)))));
            this.panel11.CustomColors.CaptionSelectedGradientEnd = System.Drawing.Color.FromArgb(((int)(((byte)(67)))), ((int)(((byte)(165)))), ((int)(((byte)(220)))));
            this.panel11.CustomColors.CaptionText = System.Drawing.SystemColors.ControlText;
            this.panel11.CustomColors.CollapsedCaptionText = System.Drawing.SystemColors.ControlText;
            this.panel11.CustomColors.ContentGradientBegin = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(247)))), ((int)(((byte)(252)))));
            this.panel11.CustomColors.ContentGradientEnd = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(247)))), ((int)(((byte)(252)))));
            this.panel11.CustomColors.InnerBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(218)))), ((int)(((byte)(222)))));
            this.panel11.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel11.ForeColor = System.Drawing.SystemColors.ControlText;
            this.panel11.Image = null;
            this.panel11.Location = new System.Drawing.Point(0, 0);
            this.panel11.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel11.MinimumSize = new System.Drawing.Size(29, 28);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(1464, 231);
            this.panel11.TabIndex = 0;
            this.panel11.ToolTipTextCloseIcon = null;
            this.panel11.ToolTipTextExpandIconPanelCollapsed = null;
            this.panel11.ToolTipTextExpandIconPanelExpanded = null;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(741, 32);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(285, 191);
            this.pictureBox1.TabIndex = 8;
            this.pictureBox1.TabStop = false;
            // 
            // btn删除影片
            // 
            this.btn删除影片.Location = new System.Drawing.Point(123, 0);
            this.btn删除影片.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn删除影片.Name = "btn删除影片";
            this.btn删除影片.Size = new System.Drawing.Size(100, 29);
            this.btn删除影片.TabIndex = 7;
            this.btn删除影片.Text = "删除";
            this.btn删除影片.UseVisualStyleBackColor = true;
            // 
            // btn录入影片
            // 
            this.btn录入影片.Location = new System.Drawing.Point(15, 0);
            this.btn录入影片.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn录入影片.Name = "btn录入影片";
            this.btn录入影片.Size = new System.Drawing.Size(100, 29);
            this.btn录入影片.TabIndex = 7;
            this.btn录入影片.Text = "录入";
            this.btn录入影片.UseVisualStyleBackColor = true;
            this.btn录入影片.Click += new System.EventHandler(this.btn录入影片_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(467, 80);
            this.textBox1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(265, 25);
            this.textBox1.TabIndex = 6;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(375, 119);
            this.label21.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(67, 15);
            this.label21.TabIndex = 5;
            this.label21.Text = "影院编号";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(375, 79);
            this.label20.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(37, 15);
            this.label20.TabIndex = 5;
            this.label20.Text = "票价";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(467, 36);
            this.dateTimePicker1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(265, 25);
            this.dateTimePicker1.TabIndex = 4;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(372, 48);
            this.label19.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(67, 15);
            this.label19.TabIndex = 3;
            this.label19.Text = "放映时间";
            // 
            // comboBox3
            // 
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Location = new System.Drawing.Point(467, 114);
            this.comboBox3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(265, 23);
            this.comboBox3.TabIndex = 2;
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(100, 109);
            this.comboBox2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(239, 23);
            this.comboBox2.TabIndex = 2;
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(100, 70);
            this.comboBox1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(239, 23);
            this.comboBox1.TabIndex = 2;
            // 
            // txTextBox1
            // 
            this.txTextBox1.BackColor = System.Drawing.Color.Transparent;
            this.txTextBox1.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(168)))), ((int)(((byte)(192)))));
            this.txTextBox1.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txTextBox1.ForeColor = System.Drawing.SystemColors.WindowText;
            this.txTextBox1.HeightLightBolorColor = System.Drawing.Color.FromArgb(((int)(((byte)(140)))), ((int)(((byte)(67)))), ((int)(((byte)(165)))), ((int)(((byte)(220)))));
            this.txTextBox1.Image = null;
            this.txTextBox1.ImageSize = new System.Drawing.Size(0, 0);
            this.txTextBox1.Location = new System.Drawing.Point(99, 34);
            this.txTextBox1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txTextBox1.Name = "txTextBox1";
            this.txTextBox1.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txTextBox1.PasswordChar = '\0';
            this.txTextBox1.Required = false;
            this.txTextBox1.Size = new System.Drawing.Size(240, 28);
            this.txTextBox1.TabIndex = 1;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(12, 109);
            this.label18.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(67, 15);
            this.label18.TabIndex = 0;
            this.label18.Text = "电影名称";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(12, 80);
            this.label17.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(67, 15);
            this.label17.TabIndex = 0;
            this.label17.Text = "影院名称";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(12, 48);
            this.label16.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(52, 15);
            this.label16.TabIndex = 0;
            this.label16.Text = "放映号";
            // 
            // FrmBaseData
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1472, 781);
            this.Controls.Add(this.txTabControl1);
            this.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "FrmBaseData";
            this.Text = "基本信息管理";
            this.txTabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_MovieTB)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picFilme)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Cinema)).EndInit();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_FilmHall)).EndInit();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_MemberTB)).EndInit();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.tabPage5.ResumeLayout(false);
            this.panel9.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_AdminTB)).EndInit();
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            this.tabPage6.ResumeLayout(false);
            this.panel11.ResumeLayout(false);
            this.panel11.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private TX.Framework.WindowUI.Controls.TXTabControl txTabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private TX.Framework.WindowUI.Controls.Panel panel2;
        private System.Windows.Forms.DataGridView dgv_MovieTB;
        private TX.Framework.WindowUI.Controls.Panel panel1;
        private TX.Framework.WindowUI.Controls.TXButton txbMovie4;
        private TX.Framework.WindowUI.Controls.TXButton txbMovie3;
        private TX.Framework.WindowUI.Controls.TXButton txbMovie2;
        private TX.Framework.WindowUI.Controls.TXButton txbMovie1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TabPage tabPage5;
        private TX.Framework.WindowUI.Controls.Panel panel7;
        private System.Windows.Forms.DataGridView dgv_MemberTB;
        private TX.Framework.WindowUI.Controls.Panel panel8;
        private TX.Framework.WindowUI.Controls.TXButton txBtn_Member4;
        private TX.Framework.WindowUI.Controls.TXButton txBtn_Member3;
        private TX.Framework.WindowUI.Controls.TXButton txBtn_Member2;
        private TX.Framework.WindowUI.Controls.TXButton txBtn_Member1;
        private TX.Framework.WindowUI.Controls.Panel panel9;
        private System.Windows.Forms.DataGridView dgv_AdminTB;
        private TX.Framework.WindowUI.Controls.Panel panel10;
        private TX.Framework.WindowUI.Controls.TXButton txBtnAdmin4;
        private TX.Framework.WindowUI.Controls.TXButton txBtnAdmin3;
        private TX.Framework.WindowUI.Controls.TXButton txBtnAdmin2;
        private TX.Framework.WindowUI.Controls.TXButton txBtnAdmin1;
        private TX.Framework.WindowUI.Controls.Panel panel5;
        private System.Windows.Forms.DataGridView dgv_FilmHall;
        private TX.Framework.WindowUI.Controls.Panel panel6;
        private TX.Framework.WindowUI.Controls.TXButton txBtnFilmHall4;
        private TX.Framework.WindowUI.Controls.TXButton txBtnFilmHall3;
        private TX.Framework.WindowUI.Controls.TXButton txBtnFilmHall2;
        private TX.Framework.WindowUI.Controls.TXButton txBtnFilmHall1;
        private TX.Framework.WindowUI.Controls.Panel panel3;
        private System.Windows.Forms.DataGridView dgv_Cinema;
        private TX.Framework.WindowUI.Controls.Panel panel4;
        private TX.Framework.WindowUI.Controls.TXButton txBtnCinema4;
        private TX.Framework.WindowUI.Controls.TXButton txBtnCinema3;
        private TX.Framework.WindowUI.Controls.TXButton txBtnCinema2;
        private TX.Framework.WindowUI.Controls.TXButton txBtnCinema1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private TX.Framework.WindowUI.Controls.TXTextBox txb_Psw;
        private TX.Framework.WindowUI.Controls.TXTextBox txb_UserName;
        private TX.Framework.WindowUI.Controls.TXTextBox txb_MemberPsw;
        private TX.Framework.WindowUI.Controls.TXTextBox txb_Phone;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private TX.Framework.WindowUI.Controls.TXTextBox txb_FilmType;
        private System.Windows.Forms.Label label7;
        private TX.Framework.WindowUI.Controls.TXTextBox txb_Score;
        private System.Windows.Forms.Label label8;
        private TX.Framework.WindowUI.Controls.TXTextBox txb_Director;
        private System.Windows.Forms.Label label6;
        private TX.Framework.WindowUI.Controls.TXTextBox txb_FilmName;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.PictureBox picFilme;
        private System.Windows.Forms.Label label9;
        private TX.Framework.WindowUI.Controls.TXTextBox txb_CinemaPhone;
        private System.Windows.Forms.Label label12;
        private TX.Framework.WindowUI.Controls.TXTextBox txb_CinemaPosition;
        private System.Windows.Forms.Label label11;
        private TX.Framework.WindowUI.Controls.TXTextBox txb_CinemaName;
        private System.Windows.Forms.Label label10;
        private TX.Framework.WindowUI.Controls.TXTextBox txb_SeatCnt;
        private System.Windows.Forms.Label label13;
        private TX.Framework.WindowUI.Controls.TXTextBox txb_FilmHallName;
        private System.Windows.Forms.Label label14;
        private TX.Framework.WindowUI.Controls.TXTextBox txb_FilmHallID;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TabPage tabPage6;
        private TX.Framework.WindowUI.Controls.Panel panel11;
        private System.Windows.Forms.Label label16;
        private TX.Framework.WindowUI.Controls.TXTextBox txTextBox1;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.Button btn删除影片;
        private System.Windows.Forms.Button btn录入影片;
        private TX.Framework.WindowUI.Controls.Panel panel12;
        private System.Windows.Forms.PictureBox pictureBox1;

    }
}