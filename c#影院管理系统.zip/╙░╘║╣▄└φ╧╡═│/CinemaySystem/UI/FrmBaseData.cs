﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using TX.Framework.WindowUI.Forms;
using TX.Framework.WindowUI.Controls;
using CinemaySystem.Model;
using CinemaySystem.BLL;

namespace CinemaySystem.UI
{
    public partial class FrmBaseData : Form
    {
        public string AdminTB = "AdminTB";
        public string MemberTB = "MemberTB";
        public string MovieTB = "MovieTB";
        public string CinemaTB = "CinemaTB";
        public string FilmHallTB = "FilmHallTB";


        public FrmBaseData()
        {
            InitializeComponent();
        }

        private void txBtnAdmin1_Click(object sender, EventArgs e)
        {
            try
            {
                MAdmin mo = new MAdmin();

                mo.UserName = txb_UserName.Text;
                mo.Psw = txb_Psw.Text;
                BLLSql.AddMAdmin(mo);

                dgv_AdminTB.DataSource = BLLSql.QueryByTbName(AdminTB);

            }
            catch (System.Exception ex)
            {
                MessageBox.Show(ex.Message);
                

            }
        }

        private void txBtnAdmin2_Click(object sender, EventArgs e)
        {
            try
            {
                MAdmin mo = new MAdmin();

                mo.UserName = txb_UserName.Text;
                mo.Psw = txb_Psw.Text;
                BLLSql.AlterMAdmin(mo);

                dgv_AdminTB.DataSource = BLLSql.QueryByTbName(AdminTB);
            }
            catch (System.Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void txBtnAdmin3_Click(object sender, EventArgs e)
        {
            try
            {
                MAdmin mo = new MAdmin();

                mo.UserName = txb_UserName.Text;
                mo.Psw = txb_Psw.Text;
                BLLSql.DeleteMAdmin(mo);

                dgv_AdminTB.DataSource = BLLSql.QueryByTbName(AdminTB);
            }
            catch (System.Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void txBtnAdmin4_Click(object sender, EventArgs e)
        {
            try
            {
                dgv_AdminTB.DataSource = BLLSql.QueryByTbName(AdminTB);
            }
            catch (System.Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void txBtn_Member1_Click(object sender, EventArgs e)
        {
            try
            {
                MMember mo = new MMember();
                mo.Phone = txb_Phone.Text;
                mo.Psw = txb_MemberPsw.Text;

                BLLSql.AddMMember(mo);

                dgv_MemberTB.DataSource = BLLSql.QueryByTbName(MemberTB);
            }
            catch (System.Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void txBtn_Member2_Click(object sender, EventArgs e)
        {
            try
            {
                MMember mo = new MMember();
                mo.Phone = txb_Phone.Text;
                mo.Psw = txb_MemberPsw.Text;

                BLLSql.AlterMMember(mo);
                dgv_MemberTB.DataSource = BLLSql.QueryByTbName(MemberTB);
            }
            catch (System.Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void txBtn_Member3_Click(object sender, EventArgs e)
        {
            try
            {
                MMember mo = new MMember();
                mo.Phone = txb_Phone.Text;
                mo.Psw = txb_MemberPsw.Text;

                BLLSql.DeleteMMember(mo);
                dgv_MemberTB.DataSource = BLLSql.QueryByTbName(MemberTB);
            }
            catch (System.Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void txBtn_Member4_Click(object sender, EventArgs e)
        {
            try
            {
                dgv_MemberTB.DataSource = BLLSql.QueryByTbName(MemberTB);
            }
            catch (System.Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void txbMovie1_Click(object sender, EventArgs e)
        {
            try
            {
                MMovie mo = new MMovie();
                mo.FilmName = txb_FilmName.Text;
                mo.FilmType = txb_FilmType.Text;
                mo.Director = txb_Director.Text;
                mo.Score = Convert.ToDecimal(txb_Score.Text);

                BLLSql.AddMMovie(mo);
                dgv_MovieTB.DataSource = BLLSql.QueryByTbName(MovieTB);
            }
            catch (System.Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void txbMovie2_Click(object sender, EventArgs e)
        {
            try
            {
                MMovie mo = new MMovie();
                mo.FilmName = txb_FilmName.Text;
                mo.FilmType = txb_FilmType.Text;
                mo.Director = txb_Director.Text;
                mo.Score = Convert.ToDecimal(txb_Score.Text);

                BLLSql.AlterMMovie(mo);
                dgv_MovieTB.DataSource = BLLSql.QueryByTbName(MovieTB);
            }
            catch (System.Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void txbMovie3_Click(object sender, EventArgs e)
        {
            try
            {
                MMovie mo = new MMovie();
                mo.FilmName = txb_FilmName.Text;
                mo.FilmType = txb_FilmType.Text;
                mo.Director = txb_Director.Text;
                mo.Score = Convert.ToDecimal(txb_Score.Text);

                BLLSql.DeleteMMovie(mo);
                dgv_MovieTB.DataSource = BLLSql.QueryByTbName(MovieTB);
            }
            catch (System.Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void txbMovie4_Click(object sender, EventArgs e)
        {
            try
            {
                dgv_MovieTB.DataSource = BLLSql.QueryByTbName(MovieTB);
            }
            catch (System.Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void txBtnCinema1_Click(object sender, EventArgs e)
        {
            try
            {
                MCinema mo = new MCinema();

                mo.CinemaName = txb_CinemaName.Text;
                mo.CinemaPosition = txb_CinemaPosition.Text;
                mo.Phone = txb_CinemaPhone.Text;

                BLLSql.AddMCinema(mo);

                dgv_Cinema.DataSource = BLLSql.QueryByTbName(CinemaTB);
            }
            catch (System.Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void txBtnCinema2_Click(object sender, EventArgs e)
        {
            try
            {
                MCinema mo = new MCinema();

                mo.CinemaName = txb_CinemaName.Text;
                mo.CinemaPosition = txb_CinemaPosition.Text;
                mo.Phone = txb_CinemaPhone.Text;

                BLLSql.AlterMCinema(mo);

                dgv_Cinema.DataSource = BLLSql.QueryByTbName(CinemaTB);
            }
            catch (System.Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void txBtnCinema3_Click(object sender, EventArgs e)
        {
            try
            {
                MCinema mo = new MCinema();

                mo.CinemaName = txb_CinemaName.Text;
                mo.CinemaPosition = txb_CinemaPosition.Text;
                mo.Phone = txb_CinemaPhone.Text;

                BLLSql.DeleteMCinema(mo);

                dgv_Cinema.DataSource = BLLSql.QueryByTbName(CinemaTB);
            }
            catch (System.Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void txBtnCinema4_Click(object sender, EventArgs e)
        {
            try
            {
                dgv_Cinema.DataSource = BLLSql.QueryByTbName(CinemaTB);
            }
            catch (System.Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void txBtnFilmHall1_Click(object sender, EventArgs e)
        {
            try
            {
                MFilmHall mo = new MFilmHall();
                mo.FilmHallID = txb_FilmHallID.Text;
                mo.FilmHallName = txb_FilmHallName.Text;
                mo.SeatCnt=Convert.ToInt32(txb_SeatCnt.Text);

                BLLSql.AddMFilmHall(mo);
                dgv_FilmHall.DataSource = BLLSql.QueryByTbName(FilmHallTB);
            }
            catch (System.Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void txBtnFilmHall2_Click(object sender, EventArgs e)
        {
            try
            {
                MFilmHall mo = new MFilmHall();
                mo.FilmHallID = txb_FilmHallID.Text;
                mo.FilmHallName = txb_FilmHallName.Text;
                mo.SeatCnt = Convert.ToInt32(txb_SeatCnt.Text);

                BLLSql.AlterMFilmHall(mo);
                dgv_FilmHall.DataSource = BLLSql.QueryByTbName(FilmHallTB);
            }
            catch (System.Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void txBtnFilmHall3_Click(object sender, EventArgs e)
        {
            try
            {
                MFilmHall mo = new MFilmHall();
                mo.FilmHallID = txb_FilmHallID.Text;
                mo.FilmHallName = txb_FilmHallName.Text;
                mo.SeatCnt = Convert.ToInt32(txb_SeatCnt.Text);

                BLLSql.DeleteMFilmHall(mo);
                dgv_FilmHall.DataSource = BLLSql.QueryByTbName(FilmHallTB);
            }
            catch (System.Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void txBtnFilmHall4_Click(object sender, EventArgs e)
        {
            try
            {
                dgv_FilmHall.DataSource = BLLSql.QueryByTbName(FilmHallTB);
            }
            catch (System.Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btn录入影片_Click(object sender, EventArgs e)
        {
            try
            {
                dgv_FilmHall.DataSource = BLLSql.QueryByTbName(FilmHallTB);
            }
            catch (System.Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
