﻿namespace CinemaySystem.UI
{
    partial class FrmLogin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmLogin));
            this.txB退出 = new TX.Framework.WindowUI.Controls.TXButton();
            this.txB登录 = new TX.Framework.WindowUI.Controls.TXButton();
            this.txTB密码 = new TX.Framework.WindowUI.Controls.TXTextBox();
            this.txTB用户名 = new TX.Framework.WindowUI.Controls.TXTextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // txB退出
            // 
            this.txB退出.Image = null;
            this.txB退出.Location = new System.Drawing.Point(228, 166);
            this.txB退出.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txB退出.Name = "txB退出";
            this.txB退出.Size = new System.Drawing.Size(150, 46);
            this.txB退出.TabIndex = 7;
            this.txB退出.Text = "退出";
            this.txB退出.UseVisualStyleBackColor = true;
            this.txB退出.Click += new System.EventHandler(this.txB退出_Click);
            // 
            // txB登录
            // 
            this.txB登录.Image = null;
            this.txB登录.Location = new System.Drawing.Point(20, 171);
            this.txB登录.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txB登录.Name = "txB登录";
            this.txB登录.Size = new System.Drawing.Size(150, 46);
            this.txB登录.TabIndex = 8;
            this.txB登录.Text = "登录";
            this.txB登录.UseVisualStyleBackColor = true;
            this.txB登录.Click += new System.EventHandler(this.txB登录_Click);
            // 
            // txTB密码
            // 
            this.txTB密码.BackColor = System.Drawing.Color.Transparent;
            this.txTB密码.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(168)))), ((int)(((byte)(192)))));
            this.txTB密码.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txTB密码.ForeColor = System.Drawing.SystemColors.WindowText;
            this.txTB密码.HeightLightBolorColor = System.Drawing.Color.FromArgb(((int)(((byte)(140)))), ((int)(((byte)(67)))), ((int)(((byte)(165)))), ((int)(((byte)(220)))));
            this.txTB密码.Image = null;
            this.txTB密码.ImageSize = new System.Drawing.Size(0, 0);
            this.txTB密码.Location = new System.Drawing.Point(130, 106);
            this.txTB密码.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txTB密码.Name = "txTB密码";
            this.txTB密码.Padding = new System.Windows.Forms.Padding(3, 3, 3, 3);
            this.txTB密码.PasswordChar = '*';
            this.txTB密码.Required = false;
            this.txTB密码.Size = new System.Drawing.Size(270, 38);
            this.txTB密码.TabIndex = 6;
            // 
            // txTB用户名
            // 
            this.txTB用户名.BackColor = System.Drawing.Color.Transparent;
            this.txTB用户名.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(168)))), ((int)(((byte)(192)))));
            this.txTB用户名.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txTB用户名.ForeColor = System.Drawing.SystemColors.WindowText;
            this.txTB用户名.HeightLightBolorColor = System.Drawing.Color.FromArgb(((int)(((byte)(140)))), ((int)(((byte)(67)))), ((int)(((byte)(165)))), ((int)(((byte)(220)))));
            this.txTB用户名.Image = null;
            this.txTB用户名.ImageSize = new System.Drawing.Size(0, 0);
            this.txTB用户名.Location = new System.Drawing.Point(130, 69);
            this.txTB用户名.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txTB用户名.Name = "txTB用户名";
            this.txTB用户名.Padding = new System.Windows.Forms.Padding(3, 3, 3, 3);
            this.txTB用户名.PasswordChar = '\0';
            this.txTB用户名.Required = false;
            this.txTB用户名.Size = new System.Drawing.Size(270, 38);
            this.txTB用户名.TabIndex = 5;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(16, 122);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(44, 18);
            this.label2.TabIndex = 3;
            this.label2.Text = "密码";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(16, 69);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(62, 18);
            this.label1.TabIndex = 4;
            this.label1.Text = "用户名";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(20, 33);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(80, 18);
            this.label3.TabIndex = 9;
            this.label3.Text = "用户类型";
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "管理员",
            "用户"});
            this.comboBox1.Location = new System.Drawing.Point(130, 30);
            this.comboBox1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(268, 26);
            this.comboBox1.TabIndex = 10;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.textBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(992, 111);
            this.panel1.TabIndex = 11;
            // 
            // textBox1
            // 
            this.textBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox1.Font = new System.Drawing.Font("宋体", 42F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox1.ForeColor = System.Drawing.Color.DarkTurquoise;
            this.textBox1.Location = new System.Drawing.Point(0, 0);
            this.textBox1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(992, 103);
            this.textBox1.TabIndex = 0;
            this.textBox1.Text = "ursula电影购票系统";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.txB退出);
            this.panel2.Controls.Add(this.txB登录);
            this.panel2.Controls.Add(this.comboBox1);
            this.panel2.Controls.Add(this.txTB密码);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.txTB用户名);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel2.Location = new System.Drawing.Point(580, 111);
            this.panel2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(412, 305);
            this.panel2.TabIndex = 12;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.pictureBox1);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(0, 111);
            this.panel3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(580, 305);
            this.panel3.TabIndex = 13;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Left;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(256, 305);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // FrmLogin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(992, 416);
            this.ControlBox = false;
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "FrmLogin";
            this.Text = "登录";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private TX.Framework.WindowUI.Controls.TXButton txB退出;
        private TX.Framework.WindowUI.Controls.TXButton txB登录;
        private TX.Framework.WindowUI.Controls.TXTextBox txTB密码;
        private TX.Framework.WindowUI.Controls.TXTextBox txTB用户名;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}