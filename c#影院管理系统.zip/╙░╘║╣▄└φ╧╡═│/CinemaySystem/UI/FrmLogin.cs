﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using TX.Framework.WindowUI.Forms;
using TX.Framework.WindowUI.Controls;
using CinemaySystem.Model;
using CinemaySystem.BLL;

namespace CinemaySystem.UI
{
    public partial class FrmLogin : Form
    {
        public FrmLogin()
        {
            InitializeComponent();
            comboBox1.Text = "会员";
            txTB用户名.Text = "18700000001";
            txTB密码.Text = "123";

        }

        private void txB退出_Click(object sender, EventArgs e)
        {
            Application.Exit();       
        }

        private void txB登录_Click(object sender, EventArgs e)
        {
            try
            {
                if (comboBox1.Text == "管理员")
                {
                    MAdmin md = new MAdmin();
                    md.UserName = txTB用户名.Text;
                    md.Psw = txTB密码.Text;


                    BLLSql.LoginAdmin(md);
                    this.Dispose();
                    MessageBox.Show("管理员登录成功");
                }
                else
                {
                    MMember mb = new MMember();
                    mb.Phone = txTB用户名.Text;
                    mb.Psw = txTB密码.Text;
                    BLLSql.LoginMember(mb);

                    FrmMain.Phone = txTB用户名.Text;
                    this.Dispose();
                    MessageBox.Show("会员登录成功");
                }

            }
            catch (System.Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
