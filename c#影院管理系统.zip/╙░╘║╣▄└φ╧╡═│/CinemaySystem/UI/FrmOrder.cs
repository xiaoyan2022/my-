﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using CinemaySystem.Model;

namespace CinemaySystem.UI
{
    public partial class FrmOrder : Form
    {
        public static bool BuyFLag = false;

        public MShowSheet ms = null;
        public FrmOrder()
        {
            InitializeComponent();
            BuyFLag = false;
        }

        public FrmOrder(MShowSheet msh,string seats)
        {
            InitializeComponent();
            BuyFLag = false;
            ms = msh;

            txb_FilmName.Text = ms.FilmName;
            txb_CinemaName.Text = ms.CinemaName;
            txb_STime.Text = ms.STime;
            txb_TicketPrice.Text = ms.TicketPrice.ToString();
            txb_FilmHallID.Text = ms.FilmHallID;
            txb_ShowSheetName.Text = ms.ShowSheetName;
            txb_Seat.Text = seats;

            this.pictureBox1.Load("Image\\" + txb_FilmName.Text + ".png");

            decimal p = ms.TicketPrice * seats.Split(',').Length;
            groupBox1.Text = p.ToString() + "元,请确认订单";

        }


        private void button1_Click(object sender, EventArgs e)
        {
            BuyFLag = true;
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            BuyFLag = false;
            this.Close();
        }
    }
}
