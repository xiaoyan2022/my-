﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using CinemaySystem.BLL;

namespace CinemaySystem.UI
{
    public partial class FrmPerOrder : Form
    {
        public FrmPerOrder()
        {
            InitializeComponent();

        }

        public FrmPerOrder(string phone)
        {
            InitializeComponent();

            dataGridView1.DataSource = BLLSql.GetDtByPhone(phone);
        }

        private void dataGridView1_SelectionChanged(object sender, EventArgs e)
        {
//             try
//             {
//                 int a = dataGridView1.CurrentRow.Index;
//                 string ShowSheetName = dataGridView1.Rows[a].Cells["ShowSheetName"].Value.ToString();
// 
//                 FrmShowSheet frm = new FrmShowSheet(ShowSheetName);
//                 frm.ShowDialog();
//             }
//             catch (System.Exception ex)
//             {
//             	
//             }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                int a = dataGridView1.CurrentRow.Index;
                string ShowSheetName = dataGridView1.Rows[a].Cells["ShowSheetName"].Value.ToString();

                FrmShowSheet frm = new FrmShowSheet(ShowSheetName);
                frm.ShowDialog();
            }
            catch (System.Exception ex)
            {

            }
        }
    }
}
