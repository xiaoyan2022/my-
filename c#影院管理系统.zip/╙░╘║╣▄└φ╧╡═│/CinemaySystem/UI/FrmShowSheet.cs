﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using CinemaySystem.BLL;

namespace CinemaySystem.UI
{
    public partial class FrmShowSheet : Form
    {
        public FrmShowSheet()
        {
            InitializeComponent();
        }

        public FrmShowSheet(string fillID)
        {
            InitializeComponent();

            dataGridView1.DataSource = BLLSql.GetShowSheeDtByShowSheetName(fillID);
        }
    }
}
