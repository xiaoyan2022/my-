﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data;
using TX.Framework.WindowUI.Controls;
using System.Reflection;

namespace CinemaySystem.UI
{
    class UIComm
    {
        public static void BindListView(ref DataTable dt, ref TXListView tlv)
        {
            tlv.Clear();
            tlv.Columns.Add("序号", 120, HorizontalAlignment.Left);

            string tbName = dt.TableName;
            for (int i = 0; i < dt.Columns.Count; i++)
            {
                ColumnHeader ch = new ColumnHeader();
                ch.Tag = dt.Columns[i].ToString();
                ch.Text = dt.Columns[i].ToString();   //设置列标题  
                ch.Width = 120;    //设置列宽度  
                if (ch.Text == "ID")
                {
                    ch.Tag = "ID";
                    ch.Width = 1;    //设置列宽度  
                    ch.Text = "";
                }

                ch.TextAlign = HorizontalAlignment.Left;   //设置列的对齐方式  
                tlv.Columns.Add(ch);
            }


            int cnt = dt.Columns.Count;
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                ListViewItem lvi = new ListViewItem();
                lvi.Text = (i + 1).ToString();

                for (int j = 0; j < cnt; j++)
                {
                    string txt = dt.Rows[i][j].ToString();
                    lvi.SubItems.Add(txt);

                    Type dataType = dt.Columns[j].DataType;
                }
                //lvi.BackColor = Color.White;
                tlv.Items.Add(lvi);
            }
        }

        public static bool TabControlCheckHave(ref System.Windows.Forms.TabControl tab, string tabName)
        {
            for (int i = 0; i < tab.TabCount; i++)
            {
                if (tab.TabPages[i].Text == tabName)
                {
                    tab.SelectedIndex = i;
                    return true;
                }
            }
            return false;
        }

        //在选项卡中生成窗体
        public static void GenerateForm(ref System.Windows.Forms.TabControl tab, string form, string formTxt, object sender)
        {
            if (TabControlCheckHave(ref  tab, formTxt))
            {
                return;
            }
            else
            {
                Form fm = (Form)Assembly.GetExecutingAssembly().CreateInstance(form);

                //设置窗体没有边框 加入到选项卡中
                fm.FormBorderStyle = FormBorderStyle.None;
                fm.TopLevel = false;
                fm.Parent = ((TabControl)sender).SelectedTab;
                fm.ControlBox = false;
                fm.Dock = DockStyle.Fill;
                fm.Show();

                TabPage tb = new TabPage();
                tb.Text = formTxt;
                tb.Name = formTxt;
                tb.Controls.Add(fm); //将窗体添加到form中
                tab.TabPages.Add(tb);
                tab.SelectedTab = tab.TabPages[fm.Name];
                tab.SelectedIndex = tab.TabCount - 1;
            }
        }
    }
}
