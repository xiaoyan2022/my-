﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 法律查询系统
{
    public partial class LoginForm : Form
    {
        public LoginForm()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            if ((string.IsNullOrEmpty(logintxt.Text)))
            {
                MessageBox.Show("请输入账号", "登陆提示");
                return;
            }
            if ((string.IsNullOrEmpty(pwdtxt.Text)))
            {
                MessageBox.Show("请输入密码", "登陆提示");
                return;
            }

            //string sql = string.Format("select * from User where username='{0}' and pwd='{1}'", logintxt.Text,pwdtxt.Text);
            string sql = string.Format("select * from Admin where Uid='{0}' and Pwd='{1}'", logintxt.Text, pwdtxt.Text);
            DataTable dt = DBHelper.ExecuteTable(sql);
            if (dt.Rows.Count > 0)
            {
                MessageBox.Show("登陆成功", "Tip");
                this.Hide();
                ManagerForm ma = new ManagerForm();
                ma.Show();
            }
            else
            {
                MessageBox.Show("登陆失败", "Tip", MessageBoxButtons.OK);
            }
        }
    }
}
