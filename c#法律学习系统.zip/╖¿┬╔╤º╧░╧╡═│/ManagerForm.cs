﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 法律查询系统
{
    public partial class ManagerForm : Form
    {
        public ManagerForm()
        {
            InitializeComponent();
        }

        private void toolStripLabel1_Click(object sender, EventArgs e)
        {
            this.Hide();
            mainForm ma = new mainForm();
            ma.Show();
        }

        private void 选择ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var sql = "select * from Type";
            DataTable table = new DataTable();
            table = DBHelper.ExecuteTable(sql);
            cbx1.DataSource = table;
            cbx1.DisplayMember = "Type";
            cbx1.ValueMember = "TypeID";   //comboBox数据绑定

            tbxname.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            cbx1.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            tbxdescription.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
            tbxID.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if ((string.IsNullOrEmpty(tbxname.Text)   || string.IsNullOrEmpty(tbxdescription.Text)))
            {
                MessageBox.Show("请选择后修改", "提示");
                tbxname.Focus();
                return;
            }
            string sql = string.Format("update book Set name='{0}',TypeID='{1}',description='{2}' where ID='{3}'", tbxname.Text, cbx1.SelectedIndex + 1,   tbxdescription.Text, tbxID.Text);




            if (DBHelper.ExecuteNonQuery(sql))

            {
                MessageBox.Show("修改成功", "提示", MessageBoxButtons.OK);
                //刷新
                string sql1 = "select name 法律,t.Type 类型 ,description 内容 from book g,Type t where t.TypeID=g.TypeID";
                dataGridView1.DataSource = DBHelper.ExecuteTable(sql1);

            }
            else
            {
                //DBHelper.ExecuteNonquery(sql);
                MessageBox.Show("修改不成功", "提示", MessageBoxButtons.OK);

            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("确定删除吗？", "tip", MessageBoxButtons.OKCancel) == DialogResult.OK)
            {
                var sql = string.Format("delete from book where name='{0}'", dataGridView1.CurrentRow.Cells[0].Value);
                if (DBHelper.ExecuteNonQuery(sql)
                    )
                {
                    MessageBox.Show("删除信息成功！");
                    //刷新
                    string sql1 = "select name 法律,t.Type 类型, description 内容,ID 编号 from book g,Type t where t.TypeID=g.TypeID";
                    dataGridView1.DataSource = DBHelper.ExecuteTable(sql1);
                }
                else
                {
                    MessageBox.Show("删除信息失败！");
                }
            }
            else
            {
                MessageBox.Show("删除信息失败！");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            adForm add = new adForm();

            if (add.ShowDialog() == DialogResult.OK)
            {
                string sql1 = "select name 法律,t.Type 类型, description 内容,ID 编号 from book g,Type t where t.TypeID=g.TypeID";
                dataGridView1.DataSource = DBHelper.ExecuteTable(sql1);
            }

        }

        private void ManagerForm_Load(object sender, EventArgs e)
        {
            string sql = "select name 法律,t.Type 类型, description 内容,ID 编号 from book g,Type t where t.TypeID=g.TypeID";
            dataGridView1.DataSource = DBHelper.ExecuteTable(sql);
        }
    }
}
