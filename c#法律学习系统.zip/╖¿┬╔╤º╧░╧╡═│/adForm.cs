﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 法律查询系统
{
    public partial class adForm : Form
    {
        public adForm()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if ((string.IsNullOrEmpty(tbxname.Text)  || string.IsNullOrEmpty(tbxdescription.Text)))
            {
                MessageBox.Show("请输入信息", "提示"); 
                return;
            }

            string sql = string.Format("insert into book(name,TypeID,description) values('{0}','{1}','{2}')", tbxname.Text, cbx1.SelectedIndex + 1,   tbxdescription.Text);
            if (DBHelper.ExecuteNonQuery(sql))
            {
                MessageBox.Show("添加成功", "tip", MessageBoxButtons.OK);
                DialogResult = DialogResult.OK;

                this.Hide();
            }
            else
            {
                MessageBox.Show("添加失败", "tip");
            }
        }

        private void adForm_Load(object sender, EventArgs e)
        {

            string sqll = "select * from Type";
            cbx1.DataSource = DBHelper.ExecuteTable(sqll);
            cbx1.DisplayMember = "Type";
            cbx1.ValueMember = "TypeID";
        }
    }
}
