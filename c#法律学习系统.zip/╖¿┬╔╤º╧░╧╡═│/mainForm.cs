﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 法律查询系统
{
    public partial class mainForm : Form
    {
        public mainForm()
        {
            InitializeComponent();
        }

        private void toolStripLabel1_Click(object sender, EventArgs e)
        {
            LoginForm login = new LoginForm();
            login.Show();
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            registerForm reg = new registerForm();
            reg.Show();
        }

        private void mainForm_Load(object sender, EventArgs e)
        {
            string sql = "select name 法律,t.Type 类型,description 内容 from book g,Type t where t.TypeID=g.TypeID";
            dataGridView1.DataSource = DBHelper.ExecuteTable(sql);
            string sqll = "select * from Type";
            cbx1.DataSource = DBHelper.ExecuteTable(sqll);
            cbx1.DisplayMember = "Type";
            cbx1.ValueMember = "TypeID";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string sql = string.Format("select name 法律,t.Type 类型,description 内容 from book g join Type t on t.TypeID=g.TypeID where t.Type='{0}'", cbx1.Text);
            dataGridView1.DataSource = DBHelper.ExecuteTable(sql);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string key = textBox1.Text;
            string sql = "select name 法律,t.Type 类型,description 内容 from book g ,Type t where t.TypeID=g.TypeID";
            var table = DBHelper.ExecuteTable(sql);
            DataView dv = table.DefaultView;
            dv.RowFilter = string.Format("法律 like '%{0}%' or 内容 like '%{1}%'", key, key);
            dataGridView1.DataSource = dv;
        }
    }
}
