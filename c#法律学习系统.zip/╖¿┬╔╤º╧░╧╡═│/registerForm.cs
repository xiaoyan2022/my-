﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 法律查询系统
{
    public partial class registerForm : Form
    {
        public registerForm()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if ((string.IsNullOrEmpty(tbxUid.Text)))
            {
                MessageBox.Show("请输入账号", "提示");
                return;
            }
            if ((string.IsNullOrEmpty(tbxPwd.Text)))
            {
                MessageBox.Show("请输入密码", "提示");
                return;
            }
            string sql = string.Format("insert into Admin values('{0}','{1}')", tbxUid.Text, tbxPwd.Text);
            if (DBHelper.ExecuteNonQuery(sql))
            {
                MessageBox.Show("注册成功", "tip");
                this.Hide();
            }
            else
            {
                MessageBox.Show("注册失败", "tip");
            }
        }
    }
}
