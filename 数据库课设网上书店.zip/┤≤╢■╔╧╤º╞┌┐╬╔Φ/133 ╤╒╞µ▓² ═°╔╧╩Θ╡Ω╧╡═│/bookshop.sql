/*
Navicat MySQL Data Transfer

Source Server         : yqc
Source Server Version : 50726
Source Host           : localhost:3306
Source Database       : bookshop

Target Server Type    : MYSQL
Target Server Version : 50726
File Encoding         : 65001

Date: 2021-12-03 18:36:48
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for 出版社信息表
-- ----------------------------
DROP TABLE IF EXISTS `出版社信息表`;
CREATE TABLE `出版社信息表` (
  `出版社` char(20) NOT NULL,
  `出版社地址` char(20) DEFAULT NULL,
  `电话` char(20) DEFAULT NULL,
  `联系人` char(20) DEFAULT NULL,
  PRIMARY KEY (`出版社`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of 出版社信息表
-- ----------------------------
INSERT INTO `出版社信息表` VALUES ('中国科学出版社', '福建', '44444444', '漆');
INSERT INTO `出版社信息表` VALUES ('工业出版社', '北京市百万庄大街', '01088361066', '王');
INSERT INTO `出版社信息表` VALUES ('电子大学出版社', '广西', '22222222', '李');
INSERT INTO `出版社信息表` VALUES ('蓝天出版社', '浙江', '3333333', '张');

-- ----------------------------
-- Table structure for 图书信息表
-- ----------------------------
DROP TABLE IF EXISTS `图书信息表`;
CREATE TABLE `图书信息表` (
  `BOOK_ID` int(11) NOT NULL,
  `SELLER_ID` varchar(20) DEFAULT NULL,
  `BOOK_NAME` varchar(50) DEFAULT NULL,
  `PRICE` int(11) DEFAULT NULL,
  `COUNT` int(11) DEFAULT NULL,
  `CLASS` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`BOOK_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of 图书信息表
-- ----------------------------
INSERT INTO `图书信息表` VALUES ('1', '11', '概率论', '12', '34', '科学类');
INSERT INTO `图书信息表` VALUES ('2', '22', '中国娱乐', '13', '56', '娱乐类');
INSERT INTO `图书信息表` VALUES ('3', '33', '艺术人生', '14', '322', '人文类');
INSERT INTO `图书信息表` VALUES ('4', '44', '计算机网络', '15', '555', '计算机类');
INSERT INTO `图书信息表` VALUES ('5', '55', '数据库原理', '16', '678', '计算机类');

-- ----------------------------
-- Table structure for 图书类别表
-- ----------------------------
DROP TABLE IF EXISTS `图书类别表`;
CREATE TABLE `图书类别表` (
  `类别号` char(20) NOT NULL,
  `类别` char(20) DEFAULT NULL,
  `类别信息` char(20) DEFAULT NULL,
  `备注` char(20) DEFAULT NULL,
  PRIMARY KEY (`类别号`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of 图书类别表
-- ----------------------------
INSERT INTO `图书类别表` VALUES ('', null, null, null);
INSERT INTO `图书类别表` VALUES ('1', '', null, null);
INSERT INTO `图书类别表` VALUES ('2', 'A', '自然科学类', '66');
INSERT INTO `图书类别表` VALUES ('3', 'A', '人文科学类', '556');
INSERT INTO `图书类别表` VALUES ('4', 'C', '计算机类', '44');
INSERT INTO `图书类别表` VALUES ('5', 'B', '计算机类', '455');
INSERT INTO `图书类别表` VALUES ('6', 'E', '娱乐类', '20');
INSERT INTO `图书类别表` VALUES ('7', '7', '文学类', '27');
INSERT INTO `图书类别表` VALUES ('·1', 'A', '教育类', '89');

-- ----------------------------
-- Table structure for 管理员
-- ----------------------------
DROP TABLE IF EXISTS `管理员`;
CREATE TABLE `管理员` (
  `SELLER_ID` varchar(20) NOT NULL,
  `SELLER_NAME` varchar(20) DEFAULT NULL,
  `PWD` varchar(20) DEFAULT NULL,
  `ADDRESS` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`SELLER_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of 管理员
-- ----------------------------
INSERT INTO `管理员` VALUES ('001', '小颜', '12345', '沈阳市');

-- ----------------------------
-- Table structure for 进货订单
-- ----------------------------
DROP TABLE IF EXISTS `进货订单`;
CREATE TABLE `进货订单` (
  `进货单号` char(20) NOT NULL,
  `进货者` char(20) DEFAULT NULL,
  `备注` char(20) DEFAULT NULL,
  PRIMARY KEY (`进货单号`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of 进货订单
-- ----------------------------
INSERT INTO `进货订单` VALUES ('446', '小张', '2344');
INSERT INTO `进货订单` VALUES ('67', '小超', '899');
INSERT INTO `进货订单` VALUES ('78', '小李', '200');
INSERT INTO `进货订单` VALUES ('79', '小张', '300');
INSERT INTO `进货订单` VALUES ('80', '小颜', '400');
INSERT INTO `进货订单` VALUES ('90', '小名', '500');
INSERT INTO `进货订单` VALUES ('92', '小许', '600');

-- ----------------------------
-- Table structure for 销售订单
-- ----------------------------
DROP TABLE IF EXISTS `销售订单`;
CREATE TABLE `销售订单` (
  `销售单号` char(20) NOT NULL,
  `购买者` char(20) DEFAULT NULL,
  PRIMARY KEY (`销售单号`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of 销售订单
-- ----------------------------
INSERT INTO `销售订单` VALUES ('22', 'yan');
INSERT INTO `销售订单` VALUES ('23', '颜');
INSERT INTO `销售订单` VALUES ('24', '李');
INSERT INTO `销售订单` VALUES ('25', '赵');
INSERT INTO `销售订单` VALUES ('26', '章');
INSERT INTO `销售订单` VALUES ('27', '张');
INSERT INTO `销售订单` VALUES ('28', '许');
